import { describe, expect, it } from "vitest";
import { buildClientRenderPrompt, type ClientRenderSpec } from "./clientRenderPrompt";

const spec: ClientRenderSpec = {
  blueprintName: "Late Summer Study",
  emotionalIntent: "quiet remembrance",
  sourceFingerprint: "abc123",
  base: { diameterIn: 24, ringWidthIn: 5, depthIn: 4 },
  anchor: { startClock: "7:00", endClock: "9:00", depthRatio: 1, visualWeight: 1 },
  sweep: { startClock: "9:00", endClock: "1:30", curvature: 0.25, taper: 0.45, widthIn: 1.5 },
  echo: { clock: "5:00", arcDegrees: 34, depthRatio: 0.7, visualWeight: 0.45 },
  clearance: { clock: "8:00", purpose: "bow", arcDegrees: 22 },
  greeneryArchitecture: [
    { behavior: "arching", startClock: "1:30", endClock: "4:15", depthBand: "receding", widthIn: 0.8 },
    { behavior: "bridging", startClock: "4:15", endClock: "5:30", depthBand: "middle", widthIn: 0.5 },
  ],
  floralPockets: [
    { type: "support", clock: "3:15", arcDegrees: 23, depthRatio: 0.62, visualWeight: 0.24, relationship: "nested into the canopy arch" },
  ],
  floralRoles: [
    { pocket: "Primary anchor", role: "focal", material: "garden rose", palette: "warm ivory", quantity: 5, note: "nested into the anchor-side greenery" },
  ],
};

describe("buildClientRenderPrompt", () => {
  it("compiles the current composition details into a client-safe floral render brief", () => {
    const prompt = buildClientRenderPrompt(spec);
    expect(prompt).toContain("Late Summer Study");
    expect(prompt).toContain("7:00 to 9:00");
    expect(prompt).toContain("9:00 to 1:30");
    expect(prompt).toContain("22 degree opening at 8:00 for the bow");
    expect(prompt).toContain("arching greenery gesture runs from 1:30 to 4:15");
    expect(prompt).toContain("support floral pocket at 3:15 spans 23 degrees");
    expect(prompt).toContain("focal material in Primary anchor: garden rose, warm ivory, 5 stems, nested into the anchor-side greenery");
    expect(prompt).toContain("no text, no labels, no measurements");
  });
});

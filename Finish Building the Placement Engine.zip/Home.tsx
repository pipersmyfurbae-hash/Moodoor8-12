/**
 * Botanical Drafting Atelier: the application shell stays intentionally quiet so
 * the imported SVG composition canvas remains the designer's primary work surface.
 */
import { useEffect } from "react";
import "../engine.css";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const { mutate: generateClientRender } = trpc.clientRender.generate.useMutation({
    onSuccess: (result) => {
      window.dispatchEvent(new CustomEvent("evercrafted:client-render-success", { detail: result }));
    },
    onError: (error) => {
      window.dispatchEvent(new CustomEvent("evercrafted:client-render-error", {
        detail: { message: error.message || "The floral presentation render could not be generated." },
      }));
    },
  });

  useEffect(() => {
    // The supplied, tested engine owns the canvas and all stateful DOM panels.
    // @ts-expect-error The engine is deliberately dependency-free JavaScript.
    void import("../engine/main.js");
  }, []);

  useEffect(() => {
    const handleRequest = (event: Event) => {
      const request = event as CustomEvent;
      if (request.detail) generateClientRender(request.detail);
    };
    window.addEventListener("evercrafted:client-render-request", handleRequest);
    return () => window.removeEventListener("evercrafted:client-render-request", handleRequest);
  }, [generateClientRender]);

  return (
    <div className="evercrafted-root">
      <div className="app" aria-label="Evercrafted Placement Engine workspace">
        <header className="toolbar" id="toolbar-mount" />

        <aside className="panel panel-left" aria-label="Layers and structure">
          <h2 className="panel-heading">Layers &amp; structure</h2>
          <div className="panel-body" id="layers-mount" />
        </aside>

        <main className="stage" aria-label="Wreath placement canvas">
          <div className="canvas-mount" id="canvas-mount" />
          <p className="canvas-hint">
            Drag to move · handles to resize · scroll to zoom · drag empty space to pan ·{" "}
            <kbd>shift</kbd> snaps to half-hours · <kbd>0</kbd> resets · <kbd>l</kbd> locks
          </p>
        </main>

        <aside className="panel panel-right" aria-label="Blueprint inspector">
          <div className="panel-body" id="inspector-mount" />
        </aside>

        <section className="panel panel-bottom" id="report-mount" aria-label="Composition review" />
      </div>
    </div>
  );
}

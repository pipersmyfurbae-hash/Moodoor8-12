import assert from 'node:assert/strict';
import { createBlueprint, migrate } from '../client/src/engine/core/schema.js';
import { previewFingerprint } from '../client/src/engine/ui/render-preview.js';

const blueprint = createBlueprint({ now: '2026-08-12T00:00:00.000Z' });
const initialFingerprint = previewFingerprint(blueprint);

assert.ok(blueprint.render_preview, 'new blueprints should include render-preview provenance');
assert.equal(blueprint.render_preview.generated_at, null);
assert.equal(initialFingerprint, previewFingerprint(blueprint), 'unchanged blueprints need stable fingerprints');

const moved = structuredClone(blueprint);
moved.objects.find((object) => object.id === 'anchor-1').start_deg += 15;
assert.notEqual(initialFingerprint, previewFingerprint(moved), 'placement edits must invalidate a prior study');

const legacy = structuredClone(blueprint);
delete legacy.render_preview;
assert.deepEqual(migrate(legacy).render_preview, {
  generated_at: null,
  source_revision: null,
  source_fingerprint: null,
}, 'older blueprints should receive an empty render-preview record during migration');

console.log('Render-preview provenance checks passed.');

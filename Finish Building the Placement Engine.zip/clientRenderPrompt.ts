/**
 * Botanical Drafting Atelier — prompt compiler for client-facing floral renders.
 * The blueprint provides composition facts; this compiler never treats a render
 * as a substitute for the editable placement source of truth.
 */

export type ClientRenderSpec = {
  blueprintName: string;
  emotionalIntent: string;
  sourceFingerprint: string;
  base: { diameterIn: number; ringWidthIn: number; depthIn: number };
  anchor: { startClock: string; endClock: string; depthRatio: number; visualWeight: number };
  sweep: { startClock: string; endClock: string; curvature: number; taper: number; widthIn: number };
  echo: { clock: string; arcDegrees: number; depthRatio: number; visualWeight: number };
  clearance: { clock: string; purpose: string; arcDegrees: number } | null;
  greeneryArchitecture?: Array<{ behavior: string; startClock: string; endClock: string; depthBand: string; widthIn: number }>;
  floralPockets?: Array<{ type: string; clock: string; arcDegrees: number; depthRatio: number; visualWeight: number; relationship: string }>;
  floralRoles?: Array<{ pocket: string; role: string; material: string; palette: string; quantity: number; note: string }>;
};

export function buildClientRenderPrompt(spec: ClientRenderSpec) {
  const emotionalIntent = spec.emotionalIntent.trim() || "quiet, grounded, and deeply considered";
  const clearance = spec.clearance
    ? `Reserve a clean, intentional ${spec.clearance.arcDegrees} degree opening at ${spec.clearance.clock} for the ${spec.clearance.purpose}; do not cover this opening with foliage or flowers.`
    : "Leave a restrained, intentional breathing space where the hardware opening would sit.";
  const greenery = (spec.greeneryArchitecture ?? []).length
    ? (spec.greeneryArchitecture ?? []).map((path) => `A ${path.behavior} greenery gesture runs from ${path.startClock} to ${path.endClock} in the ${path.depthBand} depth, with a restrained ${path.widthIn.toFixed(1)}-inch band.`).join(' ')
    : 'Use the primary sweep as the sole greenery gesture.';
  const pockets = (spec.floralPockets ?? []).length
    ? (spec.floralPockets ?? []).map((pocket) => `A ${pocket.type} floral pocket at ${pocket.clock} spans ${pocket.arcDegrees} degrees, carries weight ${pocket.visualWeight.toFixed(2)}, and is ${pocket.relationship}`).join(' ')
    : 'Keep secondary blooms limited to the anchor and echo relationship.';
  const floralRoles = (spec.floralRoles ?? []).length
    ? (spec.floralRoles ?? []).map((assignment) => `${assignment.role} material in ${assignment.pocket}: ${[assignment.material, assignment.palette, assignment.quantity ? `${assignment.quantity} stems` : '', assignment.note].filter(Boolean).join(', ')}`).join(' ')
    : 'No specific materials are assigned yet; keep the focal, supporting, and accent hierarchy restrained and botanically coherent.';

  return `Create a high-fidelity, client-facing floral design presentation of a handcrafted asymmetrical wreath, viewed directly overhead on a warm ivory atelier surface. The image must look like a real, premium florist-made object photographed in soft natural daylight, not a diagram, mood board, or generic stock photo.

Composition blueprint for “${spec.blueprintName}”:
- Base: ${spec.base.diameterIn}-inch circular wreath with a ${spec.base.ringWidthIn}-inch working ring and ${spec.base.depthIn}-inch depth.
- Primary floral anchor: a substantial but artfully interwoven focal cluster from ${spec.anchor.startClock} to ${spec.anchor.endClock}, with visual weight ${spec.anchor.visualWeight.toFixed(2)} and depth ratio ${spec.anchor.depthRatio.toFixed(2)}. Place it in the lower-left quadrant, held securely within greenery rather than sitting on top.
- Primary sweep: a refined moss-green foliage gesture that travels clockwise from ${spec.sweep.startClock} to ${spec.sweep.endClock}; use a ${spec.sweep.widthIn.toFixed(1)}-inch narrow band, curvature ${spec.sweep.curvature.toFixed(2)}, and taper ${spec.sweep.taper.toFixed(2)}. The sweep should lead the eye around the form without becoming a hedge.
- Greenery architecture: ${greenery}
- Floral pockets: ${pockets}
- Floral roles: ${floralRoles}
- Secondary echo: a smaller, quieter floral response near ${spec.echo.clock}, spanning about ${spec.echo.arcDegrees} degrees, at visual weight ${spec.echo.visualWeight.toFixed(2)} and depth ratio ${spec.echo.depthRatio.toFixed(2)}. It repeats the anchor’s tonal family without mirroring it.
- ${clearance}
- Preserve generous, deliberate negative space across the remaining form so the wreath breathes and the eye has places to rest.

Material direction: intertwined olive and eucalyptus-like greenery, soft muted cream blooms, restrained terracotta and dusty burgundy accents, naturally varied stem direction, believable floral depth, and visible handcrafted construction. Mood: ${emotionalIntent}.

Presentation rules: composition centered with generous ivory margin, square 1:1 crop, no hands, no people, no tools, no packaging, no vase, no text, no labels, no measurements, no bow unless it is clearly outside the reserved opening. Avoid dense full-circle florals, perfect symmetry, funeral-wreath clichés, artificial petals, and overly saturated colours.`;
}

import assert from 'node:assert/strict';
import { createBlueprint } from '../client/src/engine/core/schema.js';
import { approveFloralSubstitution, revertFloralSubstitution, updateFloralRole } from '../client/src/engine/core/actions.js';
import { inventoryPresentationStatus, matchBlueprintInventory, parseInventorySnapshot, suggestInventorySubstitutions } from '../client/src/engine/core/inventory.js';

const persistenceMemory = new Map();
globalThis.localStorage = {
  getItem: (key) => persistenceMemory.get(key) ?? null,
  setItem: (key, value) => persistenceMemory.set(key, String(value)),
  removeItem: (key) => persistenceMemory.delete(key),
};
const { saveBlueprint, loadBlueprint } = await import('../client/src/engine/io/persistence.js');

const snapshotResult = parseInventorySnapshot(JSON.stringify({
  schema_version: 'evercrafted.inventory.v1',
  source_name: 'Substitution regression fixture',
  exported_at: new Date().toISOString(),
  materials: [
    { id: 'rose', name: 'Garden Rose', available_qty: 2, unit: 'stems', palette: ['warm ivory'] },
    { id: 'ranunculus', name: 'Ranunculus', available_qty: 9, unit: 'stems', palette: ['warm ivory', 'apricot'] },
    { id: 'lisianthus', name: 'Lisianthus', available_qty: 7, unit: 'stems', palette: ['cool lavender'] },
  ],
}));
assert.equal(snapshotResult.ok, true);

let blueprint = createBlueprint();
blueprint = updateFloralRole(blueprint, 'anchor-1', 'role-1', 'material', 'Garden Rose');
blueprint = updateFloralRole(blueprint, 'anchor-1', 'role-1', 'palette', 'warm ivory');
blueprint = updateFloralRole(blueprint, 'anchor-1', 'role-1', 'quantity', 5);
const blocked = matchBlueprintInventory(blueprint, snapshotResult.snapshot).matches[0];
assert.equal(blocked.status, 'limited');
const suggestions = suggestInventorySubstitutions(blueprint, snapshotResult.snapshot, blocked);
assert.equal(suggestions[0].name, 'Ranunculus', 'palette-compatible sufficient alternative should rank first');
assert.equal(blueprint.objects.find((obj) => obj.id === 'anchor-1').floral_roles[0].material, 'Garden Rose', 'suggestions must not mutate the assignment');

let allocatedBlueprint = updateFloralRole(blueprint, 'anchor-1', 'role-2', 'material', 'Ranunculus');
allocatedBlueprint = updateFloralRole(allocatedBlueprint, 'anchor-1', 'role-2', 'quantity', 6);
const allocatedBlocked = matchBlueprintInventory(allocatedBlueprint, snapshotResult.snapshot).matches.find((entry) => entry.assignmentId === 'role-1');
assert.equal(suggestInventorySubstitutions(allocatedBlueprint, snapshotResult.snapshot, allocatedBlocked).some((suggestion) => suggestion.name === 'Ranunculus'), false, 'already allocated material must not be suggested beyond its remaining stock');

const substituted = approveFloralSubstitution(blueprint, 'anchor-1', 'role-1', suggestions[0]);
const approved = substituted.objects.find((obj) => obj.id === 'anchor-1').floral_roles[0];
assert.equal(approved.material, 'Ranunculus');
assert.equal(approved.substitution.status, 'approved');
assert.equal(approved.substitution.original_material, 'Garden Rose');
assert.equal(inventoryPresentationStatus(substituted, snapshotResult.snapshot).ok, true, 'approved sufficient substitute should restore presentation readiness');
const saved = saveBlueprint(substituted, 'Approved substitute persistence check', new Date().toISOString());
assert.equal(saved.ok, true);
const reopened = loadBlueprint(saved.blueprint.id);
assert.equal(reopened.ok, true);
const reopenedRole = reopened.blueprint.objects.find((obj) => obj.id === 'anchor-1').floral_roles[0];
assert.equal(reopenedRole.substitution.status, 'approved');
assert.equal(reopenedRole.substitution.original_material, 'Garden Rose');
assert.equal(reopenedRole.substitution.substitute_material, 'Ranunculus');
assert.match(reopenedRole.substitution.rationale, /available/);

const reverted = revertFloralSubstitution(substituted, 'anchor-1', 'role-1');
const revertedRole = reverted.objects.find((obj) => obj.id === 'anchor-1').floral_roles[0];
assert.equal(revertedRole.material, 'Garden Rose');
assert.equal(revertedRole.substitution.status, 'reverted');
assert.equal(inventoryPresentationStatus(reverted, snapshotResult.snapshot).ok, false, 'reverting should recheck the original limited material');
console.log('Approved substitution proposal, application, provenance, and revert verification passed.');

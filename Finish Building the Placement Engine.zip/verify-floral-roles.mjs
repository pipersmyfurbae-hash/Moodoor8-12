import assert from 'node:assert/strict';
import { createBlueprint } from '../client/src/engine/core/schema.js';
import { activateStudioLayer, updateFloralRole } from '../client/src/engine/core/actions.js';
import { buildClientRenderInput, buildMidjourneyPrompt, floralRoleAssignments } from '../client/src/engine/ui/render-preview.js';

const entries = new Map();
globalThis.localStorage = {
  getItem: (key) => entries.get(key) ?? null,
  setItem: (key, value) => entries.set(key, String(value)),
  removeItem: (key) => entries.delete(key),
};
const downloads = [];
globalThis.document = {
  body: { appendChild: () => {}, },
  createElement: () => ({ click() { downloads.push(this); }, remove() {} }),
};
globalThis.URL = { createObjectURL: () => 'blob:role-export', revokeObjectURL: () => {} };
globalThis.requestAnimationFrame = (callback) => callback();
const { saveBlueprint, loadBlueprint, exportPromptText } = await import('../client/src/engine/io/persistence.js');

const base = createBlueprint({ now: '2026-08-12T00:00:00.000Z' });
const rolesOpened = activateStudioLayer(base, 'roles');
const anchor = rolesOpened.objects.find((obj) => obj.role === 'primary_anchor');
assert.equal(anchor.floral_roles.length, 3, 'role studio should add focal, supporting, and accent guidance');

let edited = updateFloralRole(rolesOpened, anchor.id, 'role-1', 'material', 'garden rose');
edited = updateFloralRole(edited, anchor.id, 'role-1', 'palette', 'warm ivory and soft apricot');
edited = updateFloralRole(edited, anchor.id, 'role-1', 'quantity', 5);
edited = updateFloralRole(edited, anchor.id, 'role-1', 'note', 'nest deeply into the anchor-side greenery');

const input = buildClientRenderInput(edited);
assert.equal(input.floralRoles.length, 1, 'only materially described roles should reach presentation prompts');
assert.equal(input.floralRoles[0].material, 'garden rose');
assert.equal(floralRoleAssignments(edited)[0].material, 'garden rose', 'deterministic study should read the same completed role assignment');
const prompt = buildMidjourneyPrompt(edited);
assert.match(prompt, /garden rose/);
assert.match(prompt, /--ar 1:1/);
assert.match(prompt, /--no text/);
const saved = saveBlueprint(edited, 'Floral Roles persistence check', '2026-08-12T00:00:01.000Z');
assert.equal(saved.ok, true);
const reopened = loadBlueprint(saved.blueprint.id);
assert.equal(reopened.ok, true);
assert.equal(reopened.blueprint.objects.find((obj) => obj.role === 'primary_anchor').floral_roles[0].material, 'garden rose');
const exported = exportPromptText(reopened.blueprint, prompt);
assert.match(exported.filename, /midjourney-prompt\.txt$/);
assert.equal(downloads.length, 1, 'prompt export should trigger a downloadable text artifact');
console.log('Floral Roles and Midjourney prompt verification passed.');

# Evercrafted Placement Engine: Operating Guide

## Purpose and working principle

The **Evercrafted Placement Engine** is a design-planning workspace for asymmetrical wreaths. It separates the editable **blueprint** from every downstream image: the blueprint records the placement logic, visual hierarchy, greenery structure, floral pockets, material assignments, and intentional negative space. The formal study, client-facing render, and Midjourney prompt are all derived outputs. They help communicate the design, but they do not replace the source blueprint.

> **Recommended operating order:** Intent → Composition → Greenery Architecture → Floral Pockets → Floral Roles → Formal Study → Client Render or Midjourney Prompt → Review → Preserve.

| Workspace area | What it is for | Typical action |
|---|---|---|
| **Left rail** | Opens studio levels and selects individual layers. | Open Greenery Architecture, Floral Pockets, or Floral Roles when you are ready for that stage. |
| **Center canvas** | Places and checks the wreath geometry. | Drag objects to reposition them, use handles to resize, and use the clock/radial guides to check hierarchy. |
| **Right inspector** | Explains and edits the selected object. | Set geometry, breathing reserves, material roles, palette guidance, and notes. |
| **Composition Review** | Reports essential checks and design advisories. | Resolve blocking checks before creating a formal study or client-facing render. |
| **Downstream Preview** | Holds the deterministic study and optional high-fidelity render. | Refresh the formal study after major edits, or generate a client render when the brief is ready. |

## 1. Start a blueprint and establish the composition

Select **New study** to start from the canonical 7–9 o’clock composition. The **Primary anchor** is the dominant emotional mass. The **Hardware clearance** is an intentional void inside that anchor zone; preserve it if the final wreath needs a bow, ribbon, or hanging treatment. The **Primary sweep** takes the eye away from the anchor, while the **Secondary echo** provides a smaller, quieter response around five o’clock.

Use the canvas before touching material detail. Drag an object to move it, drag its handles to alter its arc, and use the right inspector for exact values. The **Clock**, **Rest**, and **Gravity** controls in the header can be toggled as needed. Keep the anchor clearly heavier than the echo and leave resting space around the form. The review panel distinguishes essential placement checks from exploratory composition cues.

## 2. Build Greenery Architecture

In the left rail, choose **Open** beside **Greenery architecture**. This adds a linked **Canopy arch** and **Greenery bridge** to the blueprint. Both are editable behaviour paths, rather than decorative objects. Their role is to create a readable botanical route through the wreath before the floral material is assigned.

The inspector exposes travel, canopy or bridge width, curvature, taper, strength, radial position, depth band, and a **Breathing reserve**. Treat the reserve as protected visual rest after that gesture. The canvas shows this reserve as a subtle outlined sector. The bridge should stitch movements together rather than become a focal band.

| Greenery layer | Intended use | Review question |
|---|---|---|
| **Primary sweep** | The principal eye path from the anchor. | Does it guide the eye without becoming a hedge? |
| **Canopy arch** | A receding structural gesture that holds later floral material. | Does it establish a canopy while preserving visible air? |
| **Greenery bridge** | A restrained stitch between structural areas. | Does it connect movement without competing with the anchor? |

## 3. Create and edit Floral Pockets

After opening Greenery Architecture, choose **Open** beside **Floral pockets**. The engine adds a **Support pocket** linked to the canopy and a **Transition pocket** linked to the bridge. The existing anchor and echo are also floral pockets: together, these four pockets establish focal, supporting, balancing, and transitional locations.

For each selected pocket, specify its **Architecture relationship** and **Breathing reserve** in the inspector. The anchor and echo controls make the relationship between floral mass and greenery explicit; the support and transition pockets stay linked to the paths that hold them. The review panel confirms that active pockets retain a positive reserve and that derived pockets continue to follow a greenery parent.

## 4. Assign Floral Roles and materials

Choose **Open** beside **Floral roles** in the left rail. Then select any floral pocket in the canvas or layer list. The inspector displays three editable role cards: **focal**, **supporting**, and **accent**. Each card accepts a material name, palette note, quantity guide, and placement note. These are planning instructions only; they do not reserve real inventory.

Use the roles to describe the visual job of a material rather than merely listing flowers. A focal assignment establishes the strongest floral read in a pocket. Supporting material adds body and tonal continuity. Accent material adds small punctuation, texture, or a repeated color without stealing the hierarchy.

| Role | Best used for | Material entry example | Quantity guidance |
|---|---|---|---|
| **Focal** | The primary visual draw, normally strongest in the anchor. | `garden rose` | Enter the intended stem count or leave at `0` while testing ideas. |
| **Supporting** | Body, scale transition, and tonal continuity. | `ranunculus` | Use a guide count, not an inventory commitment. |
| **Accent** | Small punctuation, buds, berries, texture, or echo color. | `scabiosa pod` | Keep the count restrained so it remains an accent. |

When creating a client render or Midjourney prompt, only Floral Roles that include a material, palette, quantity, or note are carried into the prompt. Empty placeholder cards do not clutter the presentation brief.

## 5. Review, preserve, and export the editable blueprint

Use **Preserve** regularly. This stores a new revision in the browser library, retaining the editable blueprint and any linked deterministic or client-render provenance. Use the library selector to reopen an earlier preserved study. Use **Send JSON** to download a portable `.ecbp.json` file, and **Bring JSON** to restore one later. The JSON is the appropriate artifact for moving the editable blueprint between workstations or keeping an archival copy.

Before sharing an image, inspect **Composition Review**. Essential placement checks should be clear. Advisory notes are not hard failures, but they identify possible hierarchy, resting-space, or geometry concerns. Revisit the canvas and inspector when an advisory reveals an unintended outcome.

## 6. Create the formal study and client-facing render

The **Formal wreath study** is a deterministic, geometric reading of the blueprint. Select **Capture study** or **Refresh study** after any placement change. It is useful for design review because it is stable, immediate, and clearly tied to the blueprint.

Select **Generate client render** only when the composition checks are clear and the material guidance is sufficiently complete. This creates a high-fidelity floral presentation based on the same blueprint. The output is marked stale when placement or material assignments change, which protects reviewers from sharing a render that no longer reflects the current plan.

## 7. Export and use the Midjourney prompt

Select **MJ prompt** in the header. The app downloads a text file containing an `/imagine prompt:` string derived from the active blueprint. It includes the base size, anchor and echo relationship, greenery architecture, floral-pocket guidance, completed Floral Roles, negative-space direction, and a square presentation instruction. Open the downloaded `.txt` file, copy the full prompt, and paste it into Midjourney’s Imagine bar.

The export uses `--ar 1:1`, which requests a square composition. Midjourney’s documentation states that images begin square by default and that aspect ratio can be set with `--ar` or `--aspect`; its documentation also notes that aspect ratio is not the same as final pixel dimensions.[1] Use `--ar 4:5` for a portrait client presentation or `--ar 16:9` for a wide moodboard-style concept when needed.[1]

For the most compositionally faithful result, pair the exported text with an image of the **Formal wreath study** or the latest high-fidelity client render. On the Midjourney website, add the image through the image control in the Imagine bar; in Discord, place a valid online image URL at the beginning of the prompt. Midjourney treats image prompts as inspiration rather than an exact copy, so retain the text prompt’s composition and material language.[2]

> **Practical Midjourney workflow:** First run the exported 1:1 prompt. Choose the closest composition. Then use that output or the Evercrafted formal study as an image prompt and rerun the same text, adjusting only one variable at a time—material names, palette, crop, or stylization.

| Goal | Edit the exported prompt by | Reason |
|---|---|---|
| Cleaner composition | Keep the text unchanged and reduce only the material list. | Fewer competing floral instructions often preserve the blueprint’s hierarchy. |
| Stronger botanical identity | Add precise material names in the Floral Roles cards before exporting again. | The exported prompt carries completed role assignments verbatim. |
| Portrait presentation | Replace `--ar 1:1` with `--ar 4:5`. | The subject remains legible in a tall client presentation. [1] |
| Wider editorial scene | Replace `--ar 1:1` with `--ar 16:9` and request more surrounding atelier surface. | A wide crop creates room for presentation context. [1] |
| Closer adherence to the study | Add the formal study or current client render as an image prompt. | Image prompts can guide composition and color direction while the text supplies the required detail. [2] |

## 8. Recommended session checklist

Begin with composition rather than species. Establish the anchor, clearance, sweep, and echo. Add canopy and bridge gestures. Create support and transition pockets. Then assign Floral Roles, materials, palettes, quantities, and notes. Review the blueprint, preserve it, refresh the deterministic study, and choose either the built-in client render or the Midjourney export according to the presentation need. If an image differs from the intended design, change the blueprint first and regenerate; do not treat the image as the new source of truth.

## Troubleshooting

If the **MJ prompt** download is not visible, check your browser’s download shelf or downloads folder. If the Midjourney result feels generic, add specific material names and a palette note to the appropriate Floral Roles cards, then export a new prompt. If a generated image no longer matches the plan, look for the stale label in Downstream Preview, refresh the formal study, and regenerate the client render or export a new prompt. If a pocket has stopped reading as part of the greenery architecture, select it and confirm its Architecture relationship and Breathing reserve before adjusting its visual weight.

## References

[1] [Midjourney Documentation: Aspect Ratio](https://docs.midjourney.com/hc/en-us/articles/31894244298125-Aspect-Ratio)

[2] [Midjourney Documentation: Image Prompts](https://docs.midjourney.com/hc/en-us/articles/32040250122381-Image-Prompts)

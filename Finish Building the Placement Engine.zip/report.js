/**
 * Botanical Drafting Atelier — composition review and formal render study.
 * The blueprint remains the editable source of truth; the study only visualizes
 * its current placement relationships as a downstream design review artifact.
 */

import { h, replace } from './dom.js';
import { validateBlueprint } from '../core/validate.js';
import { getRules } from '../core/canon.js';
import { renderPreviewStudy } from './render-preview.js';

export function createReportPanel({ mount, getState, onSelect, onRender, onClientRender }) {
  function render() {
    const { blueprint, clientRender } = getState();
    const report = validateBlueprint(blueprint);

    const summary = h('div', { class: 'report-summary' },
      h('span', {
        class: `verdict ${report.ok ? 'is-ok' : 'is-blocked'}`,
        text: report.ok ? 'Ready' : `${report.counts.blocking} to resolve`,
      }),
      h('span', { class: 'report-counts' },
        `${report.counts.passed} checks clear`,
        report.counts.advisories
          ? h('span', { class: 'advisory-count', text: ` · ${report.counts.advisories} notes` })
          : null,
        report.counts.metrics
          ? h('span', { class: 'metric-count', text: ` · ${report.counts.metrics} measured` })
          : null,
        report.counts.provisional
          ? h('span', { class: 'provisional-count', text: ` · ${report.counts.provisional} exploratory` })
          : null));

    replace(mount,
      h('div', { class: 'report-head' },
        h('h3', { class: 'panel-heading', text: 'Composition review' }),
        summary),
      h('div', { class: 'report-columns' },
        column('Essential placement checks', report.blocking, 'blocking', onSelect),
        column('Balance & composition notes', [...report.advisory, ...report.metrics], 'advisory', onSelect),
        h('div', { class: 'report-column report-render' },
          renderPreviewStudy(blueprint, { ready: report.ok, onRender, onClientRender, clientRenderState: clientRender }))));
  }

  return { render };
}

const MARKS = { pass: '✓', fail: '!', measured: '·' };

function column(title, results, level, onSelect) {
  const failures = results.filter((result) => result.status === 'fail');
  return h('div', { class: `report-column report-${level}` },
    h('h4', { class: 'report-column-title' }, title,
      h('span', {
        class: `column-badge ${failures.length ? 'has-issues' : 'is-clear'}`,
        text: failures.length ? String(failures.length) : '✓',
      })),
    h('ul', { class: 'result-list' },
      ...results.map((result) => h('li', { class: `result result-${result.status}` },
        h('div', { class: 'result-head' },
          h('span', { class: `result-mark ${result.status}`, text: MARKS[result.status] ?? '·' }),
          h('span', { class: 'result-title', text: result.title }),
          result.enforcement === 'metric'
            ? h('span', {
                class: 'authority-tag is-metric',
                title: result.enforcement_reason,
                text: 'measured',
              })
            : null,
          result.confidence === 'provisional'
            ? h('span', {
                class: 'authority-tag is-provisional',
                title: `${result.enforcement_reason} EC-GEO-001 / EC-CAL own the calibrated replacement.`,
                text: 'exploratory',
              })
            : null),
        h('p', { class: 'result-detail', text: result.detail }),
        result.objects?.length
          ? h('div', { class: 'result-objects' }, ...result.objects.map((id) =>
              h('button', { class: 'result-object', type: 'button', onClick: () => onSelect(id) }, id)))
          : null,
        result.canon?.length
          ? h('details', { class: 'result-canon' },
              h('summary', { text: `Canon · ${result.canon.join(', ')}` }),
              ...getRules(result.canon).map((rule) =>
                h('p', { class: 'canon-text' },
                  h('span', { class: 'canon-rule-id', text: rule.label }),
                  ` "${rule.text}"`)))
          : null))));
}

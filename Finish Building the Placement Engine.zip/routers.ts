import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { buildClientRenderPrompt, type ClientRenderSpec } from "./clientRenderPrompt";
import { getSessionCookieOptions } from "./_core/cookies";
import { generateImage } from "./_core/imageGeneration";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

const clientRenderInput = z.object({
  blueprintName: z.string().min(1).max(120),
  emotionalIntent: z.string().max(600),
  sourceFingerprint: z.string().min(1).max(20_000),
  base: z.object({ diameterIn: z.number().min(6).max(72), ringWidthIn: z.number().min(1).max(24), depthIn: z.number().min(0.5).max(18) }),
  anchor: z.object({ startClock: z.string().max(12), endClock: z.string().max(12), depthRatio: z.number().min(0.2).max(1.8), visualWeight: z.number().min(0).max(1) }),
  sweep: z.object({ startClock: z.string().max(12), endClock: z.string().max(12), curvature: z.number().min(-1).max(1), taper: z.number().min(0).max(1), widthIn: z.number().min(0.1).max(24) }),
  echo: z.object({ clock: z.string().max(12), arcDegrees: z.number().min(4).max(180), depthRatio: z.number().min(0.2).max(1.8), visualWeight: z.number().min(0).max(1) }),
  clearance: z.object({ clock: z.string().max(12), purpose: z.string().min(1).max(32), arcDegrees: z.number().min(4).max(90) }).nullable(),
  greeneryArchitecture: z.array(z.object({ behavior: z.string().min(1).max(24), startClock: z.string().max(12), endClock: z.string().max(12), depthBand: z.string().min(1).max(16), widthIn: z.number().min(0.05).max(24) })).max(6).optional().default([]),
  floralPockets: z.array(z.object({ type: z.string().min(1).max(24), clock: z.string().max(12), arcDegrees: z.number().min(4).max(180), depthRatio: z.number().min(0.2).max(1.8), visualWeight: z.number().min(0).max(1), relationship: z.string().max(500) })).max(8).optional().default([]),
  floralRoles: z.array(z.object({ pocket: z.string().min(1).max(80), role: z.enum(['focal', 'supporting', 'accent']), material: z.string().max(120), palette: z.string().max(120), quantity: z.number().int().min(0).max(99), note: z.string().max(280) })).max(24).optional().default([]),
});

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  clientRender: router({
    generate: protectedProcedure.input(clientRenderInput).mutation(async ({ input }) => {
      try {
        const prompt = buildClientRenderPrompt(input as ClientRenderSpec);
        const { url } = await generateImage({
          prompt,
          model: "MODEL_GPT_IMAGE_2",
          quality: "high",
        });
        if (!url) throw new Error("Image generation returned no presentation URL.");

        return {
          url,
          generatedAt: Date.now(),
          sourceFingerprint: input.sourceFingerprint,
          blueprintName: input.blueprintName,
        };
      } catch (error) {
        console.error("[clientRender.generate]", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "The floral presentation render could not be generated. Please try again.",
        });
      }
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;

import assert from 'node:assert/strict';
import { createBlueprint } from '../client/src/engine/core/schema.js';
import { updateFloralRole } from '../client/src/engine/core/actions.js';
import { importInventoryFile, inventoryFreshness, inventoryPresentationStatus, loadInventorySnapshot, matchBlueprintInventory, parseInventorySnapshot, saveInventorySnapshot } from '../client/src/engine/core/inventory.js';

const memory = new Map();
globalThis.localStorage = {
  getItem: (key) => memory.get(key) ?? null,
  setItem: (key, value) => memory.set(key, String(value)),
  removeItem: (key) => memory.delete(key),
};

const importedAt = '2026-08-12T12:00:00.000Z';
const validation = parseInventorySnapshot(JSON.stringify({
  schema_version: 'evercrafted.inventory.v1',
  source_name: 'Regression fixture',
  exported_at: importedAt,
  materials: [{ id: 'r-01', name: 'Garden Rose', available_qty: 4, unit: 'stems', palette: ['warm ivory'] }],
}), importedAt);
assert.equal(validation.ok, true);
assert.equal(saveInventorySnapshot(validation.snapshot).ok, true);
assert.equal(loadInventorySnapshot().materials[0].name, 'Garden Rose');
const upload = await importInventoryFile({ size: 241, text: async () => JSON.stringify({ schema_version: 'evercrafted.inventory.v1', source_name: 'Upload flow fixture', exported_at: importedAt, materials: [{ id: 'r-01', name: 'Garden Rose', available_qty: 4, unit: 'stems' }] }) }, importedAt);
assert.equal(upload.ok, true, 'Stock JSON upload boundary should parse, retain, and return the snapshot');

let blueprint = createBlueprint({ now: importedAt });
blueprint = updateFloralRole(blueprint, 'anchor-1', 'role-1', 'material', 'garden rose');
blueprint = updateFloralRole(blueprint, 'anchor-1', 'role-1', 'quantity', 5);
let match = matchBlueprintInventory(blueprint, validation.snapshot);
assert.equal(match.matches[0].status, 'limited');
assert.equal(match.matches[0].shortfall, 1);
assert.equal(inventoryPresentationStatus(blueprint, validation.snapshot).ok, false, 'limited stock should hold presentation output');

const currentSnapshot = { ...validation.snapshot, materials: [{ ...validation.snapshot.materials[0], available_qty: 7 }] };
match = matchBlueprintInventory(blueprint, currentSnapshot);
assert.equal(match.matches[0].status, 'available');
assert.equal(inventoryFreshness(currentSnapshot, new Date(importedAt).getTime()).state, 'current');
assert.equal(inventoryPresentationStatus(blueprint, currentSnapshot).ok, true, 'matched sufficient stock should allow presentation output');

const staleSnapshot = { ...currentSnapshot, exported_at: '2026-08-09T12:00:00.000Z' };
assert.equal(inventoryFreshness(staleSnapshot, new Date(importedAt).getTime()).state, 'stale');
assert.equal(inventoryPresentationStatus(blueprint, staleSnapshot).ok, false, 'stale stock should hold presentation output');
const undatedSnapshot = { ...currentSnapshot, exported_at: null };
assert.equal(inventoryFreshness(undatedSnapshot).state, 'undated');
assert.equal(inventoryPresentationStatus(blueprint, undatedSnapshot).ok, false, 'undated stock should hold presentation output');

const malformed = parseInventorySnapshot('{"materials":[{"name":"Garden Rose","available_qty":-2}]}');
assert.equal(malformed.ok, false);
console.log('Inventory JSON import, persistence, freshness, and role matching verification passed.');

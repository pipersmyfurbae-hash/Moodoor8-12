/**
 * In-app inventory snapshot boundary.
 * A snapshot is supplied by the studio as JSON, never fabricated by the engine.
 */
const INVENTORY_KEY = 'evercrafted.placement-engine.inventory.v1';
const MAX_MATERIALS = 2000;

export function inventoryTemplate() {
  return {
    schema_version: 'evercrafted.inventory.v1',
    exported_at: 'YYYY-MM-DDTHH:MM:SSZ',
    materials: [
      {
        id: 'supplier-or-studio-sku',
        name: 'Exact material name used in Floral Roles',
        available_qty: 0,
        unit: 'stems',
        palette: ['optional palette note'],
      },
    ],
  };
}

export function normalizeMaterial(value) {
  return String(value ?? '').trim().toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

export function parseInventorySnapshot(text, importedAt = new Date().toISOString()) {
  let raw;
  try {
    raw = JSON.parse(text);
  } catch (error) {
    return { ok: false, errors: [`The inventory file is not valid JSON: ${error.message}`], snapshot: null };
  }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { ok: false, errors: ['The inventory file must contain a single JSON object.'], snapshot: null };
  if (!Array.isArray(raw.materials)) return { ok: false, errors: ['The inventory file must contain a materials array.'], snapshot: null };
  if (raw.materials.length > MAX_MATERIALS) return { ok: false, errors: [`The inventory file exceeds the ${MAX_MATERIALS}-material safety limit.`], snapshot: null };

  const errors = [];
  const seenNames = new Set();
  const materials = raw.materials.map((entry, index) => {
    const path = `materials[${index}]`;
    const name = String(entry?.name ?? '').trim();
    const availableQty = Number(entry?.available_qty);
    const key = normalizeMaterial(name);
    if (!name) errors.push(`${path}.name is required.`);
    if (!key) errors.push(`${path}.name must include searchable characters.`);
    if (key && seenNames.has(key)) errors.push(`${path}.name duplicates another material after normalization.`);
    seenNames.add(key);
    if (!Number.isFinite(availableQty) || availableQty < 0) errors.push(`${path}.available_qty must be a non-negative number.`);
    const palette = Array.isArray(entry?.palette)
      ? entry.palette.map((value) => String(value).trim()).filter(Boolean).slice(0, 12)
      : [];
    return {
      id: String(entry?.id ?? name).trim().slice(0, 120),
      name: name.slice(0, 160),
      key,
      available_qty: Math.floor(availableQty || 0),
      unit: String(entry?.unit ?? 'stems').trim().slice(0, 32) || 'stems',
      palette,
    };
  });
  if (errors.length) return { ok: false, errors, snapshot: null };

  const exportedAt = raw.exported_at ? new Date(raw.exported_at) : null;
  return {
    ok: true,
    errors: [],
    snapshot: {
      schema_version: 'evercrafted.inventory.v1',
      source_name: String(raw.source_name ?? 'Uploaded inventory JSON').trim().slice(0, 120),
      exported_at: exportedAt && !Number.isNaN(exportedAt.getTime()) ? exportedAt.toISOString() : null,
      imported_at: importedAt,
      materials,
    },
  };
}

function localStorageSafe() {
  try {
    if (typeof localStorage === 'undefined') return null;
    return localStorage;
  } catch {
    return null;
  }
}

export function saveInventorySnapshot(snapshot) {
  const store = localStorageSafe();
  if (!store) return { ok: false, error: 'Browser storage is unavailable, so this inventory snapshot cannot be retained.' };
  try {
    store.setItem(INVENTORY_KEY, JSON.stringify(snapshot));
    return { ok: true };
  } catch (error) {
    return { ok: false, error: `Could not retain the inventory snapshot: ${error.message}` };
  }
}

export async function importInventoryFile(file, importedAt = new Date().toISOString()) {
  if (!file || typeof file.text !== 'function') return { ok: false, errors: ['Choose a JSON inventory file to import.'], snapshot: null };
  if (Number(file.size) > 2_000_000) return { ok: false, errors: ['Use a JSON file smaller than 2 MB.'], snapshot: null };
  try {
    const parsed = parseInventorySnapshot(await file.text(), importedAt);
    if (!parsed.ok) return parsed;
    const saved = saveInventorySnapshot(parsed.snapshot);
    if (!saved.ok) return { ok: false, errors: [saved.error], snapshot: null };
    return parsed;
  } catch (error) {
    return { ok: false, errors: [`Could not read the inventory file: ${error.message}`], snapshot: null };
  }
}

export function loadInventorySnapshot() {
  const store = localStorageSafe();
  try {
    const raw = store?.getItem(INVENTORY_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed?.schema_version === 'evercrafted.inventory.v1' && Array.isArray(parsed.materials) ? parsed : null;
  } catch {
    return null;
  }
}

export function inventoryFreshness(snapshot, now = Date.now()) {
  if (!snapshot) return { state: 'missing', label: 'No inventory snapshot uploaded.' };
  if (!snapshot.exported_at) return { state: 'undated', label: `Imported ${formatTime(snapshot.imported_at)}; source file has no exported_at timestamp.` };
  const exported = new Date(snapshot.exported_at).getTime();
  const hours = Number.isFinite(exported) ? Math.max(0, (now - exported) / 3_600_000) : null;
  if (hours === null) return { state: 'undated', label: 'Source timestamp could not be read.' };
  if (hours > 48) return { state: 'stale', label: `Source snapshot is ${Math.floor(hours)} hours old; upload a newer file before approval.` };
  return { state: 'current', label: `Source snapshot exported ${formatTime(snapshot.exported_at)}.` };
}

export function matchBlueprintInventory(blueprint, snapshot) {
  const assignments = blueprint.objects
    .filter((obj) => obj.kind === 'pocket')
    .flatMap((obj) => (obj.floral_roles ?? [])
      .filter((role) => String(role.material ?? '').trim())
      .map((role) => ({ pocketId: obj.id, pocket: obj.label, assignmentId: role.id, role: role.role, material: String(role.material).trim(), requested: Math.max(0, Math.floor(Number(role.quantity) || 0)) })));
  const materials = new Map((snapshot?.materials ?? []).map((material) => [material.key ?? normalizeMaterial(material.name), material]));
  const requestedByMaterial = new Map();
  for (const assignment of assignments) {
    const key = normalizeMaterial(assignment.material);
    requestedByMaterial.set(key, (requestedByMaterial.get(key) ?? 0) + assignment.requested);
  }
  const matches = assignments.map((assignment) => {
    const key = normalizeMaterial(assignment.material);
    const material = materials.get(key);
    const totalRequested = requestedByMaterial.get(key) ?? assignment.requested;
    const available = material?.available_qty ?? 0;
    const status = !snapshot ? 'missing_snapshot'
      : !material ? 'unmatched'
        : assignment.requested === 0 ? 'unquantified'
          : available >= totalRequested ? 'available'
            : available > 0 ? 'limited' : 'unavailable';
    return { ...assignment, materialRecord: material ?? null, available, totalRequested, status, shortfall: Math.max(0, totalRequested - available) };
  });
  const counts = matches.reduce((result, match) => ({ ...result, [match.status]: (result[match.status] ?? 0) + 1 }), {});
  const blocking = matches.filter((match) => ['missing_snapshot', 'unmatched', 'limited', 'unavailable'].includes(match.status));
  return { matches, counts, blocking, freshness: inventoryFreshness(snapshot) };
}

export function inventoryPresentationStatus(blueprint, snapshot) {
  const result = matchBlueprintInventory(blueprint, snapshot);
  if (!result.matches.length) return { ok: true, result };
  if (result.freshness.state === 'missing') return { ok: false, result, detail: 'Upload a current Stock JSON file before producing a presentation with assigned materials.' };
  if (result.freshness.state === 'stale' || result.freshness.state === 'undated') return { ok: false, result, detail: `${result.freshness.label} Upload a current, dated snapshot before approval.` };
  if (result.blocking.length) {
    const labels = result.blocking.slice(0, 2).map((match) => `${match.material} (${match.status.replace(/_/g, ' ')})`).join(', ');
    return { ok: false, result, detail: `Resolve inventory availability before presentation: ${labels}${result.blocking.length > 2 ? '…' : ''}.` };
  }
  return { ok: true, result };
}

/**
 * Return ranked, inventory-sufficient alternatives for a blocked Floral Role.
 * Suggestions are advisory only; applying one requires the designer's explicit approval.
 */
export function suggestInventorySubstitutions(blueprint, snapshot, roleMatch, limit = 3) {
  if (!snapshot || !roleMatch || !['limited', 'unavailable', 'unmatched'].includes(roleMatch.status)) return [];
  const pocket = blueprint.objects.find((obj) => obj.id === roleMatch.pocketId);
  const assignment = (pocket?.floral_roles ?? []).find((role) => role.id === roleMatch.assignmentId);
  if (!assignment) return [];
  const required = Math.max(1, Number(assignment.quantity) || 0);
  const originalKey = normalizeMaterial(assignment.material);
  const desiredPalette = tokenSet(assignment.palette);
  const allocated = new Map();
  for (const object of blueprint.objects.filter((item) => item.kind === 'pocket')) {
    for (const role of object.floral_roles ?? []) {
      if (object.id === roleMatch.pocketId && role.id === roleMatch.assignmentId) continue;
      const key = normalizeMaterial(role.material);
      if (key) allocated.set(key, (allocated.get(key) ?? 0) + Math.max(0, Number(role.quantity) || 0));
    }
  }
  return snapshot.materials
    .map((material) => ({ ...material, free_qty: Math.max(0, material.available_qty - (allocated.get(material.key) ?? 0)) }))
    .filter((material) => material.key !== originalKey && material.free_qty >= required)
    .map((material) => {
      const paletteTokens = tokenSet((material.palette ?? []).join(' '));
      const sharedPalette = [...desiredPalette].filter((token) => paletteTokens.has(token));
      return {
        id: material.id,
        name: material.name,
        available_qty: material.available_qty,
        unit: material.unit,
        palette: material.palette ?? [],
        score: sharedPalette.length * 10 + Math.min(5, material.free_qty / required),
        rationale: sharedPalette.length
          ? `Matches palette language: ${sharedPalette.join(', ')}; ${material.free_qty} unallocated ${material.unit} available.`
          : `${material.free_qty} unallocated ${material.unit} available for the requested quantity.`,
      };
    })
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
    .slice(0, limit);
}

function tokenSet(value) {
  return new Set(normalizeMaterial(value).split(' ').filter((token) => token.length > 2));
}

function formatTime(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? 'at an unknown time' : date.toLocaleString();
}

/**
 * Botanical Drafting Atelier — Layers / Structure.
 * Greenery Architecture and Floral Pockets remain optional studio levels until
 * opened, after which their linked objects become first-class editable layers.
 */

import { h, replace } from './dom.js';
import { formatClock } from '../core/geometry.js';
import { objectCenter, objectRange } from '../core/schema.js';
import { presenceOf } from '../core/analysis.js';
import { shortReason } from '../core/explain.js';

const FUTURE_LAYERS = [
  { label: 'Inventory assignments', note: 'Reserved for the inventory studio step' },
];

function iconButton(label, active, onClick, title, extraClass = '') {
  return h('button', {
    class: `layer-toggle ${extraClass} ${active ? 'is-on' : 'is-off'}`,
    type: 'button', title, 'aria-pressed': String(Boolean(active)),
    onClick: (event) => { event.stopPropagation(); onClick(); },
  }, label);
}

export function createLayersPanel({ mount, getState, onSelect, onToggleVisible, onToggleLock, onView, onActivateStudioLayer }) {
  function render() {
    const { blueprint, selectedId } = getState();
    const view = blueprint.view ?? {};
    const rows = [];

    rows.push(h('div', {
      class: 'layer-row is-base', onClick: () => onSelect('base'), 'data-selected': String(selectedId === 'base'),
    },
      h('div', { class: 'layer-main' },
        h('span', { class: 'layer-swatch swatch-base' }),
        h('div', { class: 'layer-text' },
          h('span', { class: 'layer-name', text: 'Base' }),
          h('span', { class: 'layer-meta', text: `${blueprint.base.diameter_in} in form · ${blueprint.base.ring_width_in} in ring` }))),
      h('div', { class: 'layer-actions' },
        iconButton('◉', blueprint.base.visible !== false, () => onToggleVisible('base'), 'Show or hide the base'))));

    const order = ['primary_anchor', 'hardware_clearance', 'primary_sweep', 'canopy_arch', 'greenery_bridge', 'support_pocket', 'transition_pocket', 'secondary_echo'];
    const objects = [...blueprint.objects].sort((a, b) => order.indexOf(a.role) - order.indexOf(b.role));

    for (const obj of objects) {
      if (obj.role === 'canopy_arch' && !rows.some((row) => row.dataset?.studioGroup === 'greenery')) {
        rows.push(h('div', { class: 'layer-group-label', dataset: { studioGroup: 'greenery' }, text: 'Greenery architecture' }));
      }
      if (obj.role === 'support_pocket' && !rows.some((row) => row.dataset?.studioGroup === 'pockets')) {
        rows.push(h('div', { class: 'layer-group-label', dataset: { studioGroup: 'pockets' }, text: 'Floral pockets' }));
      }

      const range = objectRange(obj);
      const presence = presenceOf(obj);
      const meta = obj.kind === 'behavior_path' || obj.role === 'primary_anchor'
        ? `${formatClock(range.start)} → ${formatClock(range.start + range.span)} · ${Math.round(range.span)}°`
        : `${formatClock(objectCenter(obj))} · ${Math.round(range.span)}° arc`;

      rows.push(h('div', {
        class: `layer-row layer-${obj.role}${obj.visible === false ? ' is-hidden' : ''}${obj.locked ? ' is-locked' : ''}`,
        'data-selected': String(selectedId === obj.id), onClick: () => onSelect(obj.id), title: shortReason(blueprint, obj),
      },
        h('div', { class: 'layer-main' },
          h('span', { class: `layer-swatch swatch-${obj.role}` }),
          h('div', { class: 'layer-text' },
            h('span', { class: 'layer-name', text: obj.label }),
            h('span', { class: 'layer-meta', text: meta }),
            presence > 0
              ? h('span', { class: 'layer-presence', text: `presence ${presence.toFixed(1)}` })
              : h('span', { class: 'layer-presence is-void', text: 'reserved void' }))),
        h('div', { class: 'layer-actions' },
          iconButton(obj.locked ? '🔒' : '🔓', obj.locked, () => onToggleLock(obj.id),
            obj.locked ? 'Unlock — let it follow its linked parent again' : 'Lock — hold it in place', 'is-lock'),
          iconButton('◉', obj.visible !== false, () => onToggleVisible(obj.id), 'Show or hide'))));
    }

    rows.push(h('div', { class: 'layer-group-label', text: 'Derived' }));
    rows.push(overlayRow('Negative space', 'rest_zones', view.rest_zones, 'Read from the resting spaces between placed forms.', onView));
    rows.push(overlayRow('Clock overlay', 'clock_overlay', view.clock_overlay, 'Hour positions and spokes.', onView));
    rows.push(overlayRow('Composition gravity', 'gravity_marker', view.gravity_marker, 'Measured centre of visual mass. Exploratory guide.', onView));

    rows.push(h('div', { class: 'layer-group-label', text: 'Next studio layers' }));
    const hasGreenery = blueprint.objects.some((obj) => obj.role === 'canopy_arch' || obj.role === 'greenery_bridge');
    const hasPockets = blueprint.objects.some((obj) => obj.role === 'support_pocket' || obj.role === 'transition_pocket');
    const hasRoles = blueprint.objects.some((obj) => Array.isArray(obj.floral_roles) && obj.floral_roles.length);
    if (!hasGreenery) rows.push(studioRow('Greenery architecture', 'Lay canopy and bridging gestures before florals.', () => onActivateStudioLayer('greenery')));
    if (!hasPockets) rows.push(studioRow('Floral pockets', 'Create supporting pockets from established greenery.', () => onActivateStudioLayer('floral')));
    if (!hasRoles) rows.push(studioRow('Floral roles', 'Assign focal, supporting, and accent material guidance to every pocket.', () => onActivateStudioLayer('roles')));
    if (hasRoles) rows.push(studioRow('Floral roles', 'Ready — select any floral pocket to assign focal, supporting, and accent materials.', () => onSelect('anchor-1')));
    for (const layer of FUTURE_LAYERS) {
      rows.push(h('div', { class: 'layer-row is-future', title: layer.note },
        h('div', { class: 'layer-main' },
          h('span', { class: 'layer-swatch swatch-future' }),
          h('div', { class: 'layer-text' }, h('span', { class: 'layer-name', text: layer.label }), h('span', { class: 'layer-meta', text: layer.note })))));
    }

    replace(mount, ...rows);
  }
  return { render };
}

function studioRow(label, note, onActivate) {
  return h('div', { class: 'layer-row is-studio', title: note, onClick: onActivate },
    h('div', { class: 'layer-main' },
      h('span', { class: 'layer-swatch swatch-studio' }),
      h('div', { class: 'layer-text' }, h('span', { class: 'layer-name', text: label }), h('span', { class: 'layer-meta', text: note }))),
    h('div', { class: 'layer-actions' },
      h('button', { class: 'layer-activate', type: 'button', onClick: (event) => { event.stopPropagation(); onActivate(); } }, 'Open')));
}

function overlayRow(label, key, active, note, onView) {
  return h('div', { class: `layer-row is-overlay${active ? '' : ' is-hidden'}`, onClick: () => onView({ [key]: !active }), title: note },
    h('div', { class: 'layer-main' },
      h('span', { class: `layer-swatch swatch-${key}` }),
      h('div', { class: 'layer-text' }, h('span', { class: 'layer-name', text: label }), h('span', { class: 'layer-meta', text: note }))),
    h('div', { class: 'layer-actions' },
      h('button', { class: `layer-toggle ${active ? 'is-on' : 'is-off'}`, type: 'button', 'aria-pressed': String(Boolean(active)), onClick: (event) => { event.stopPropagation(); onView({ [key]: !active }); } }, '◉')));
}

/**
 * Manual end-to-end verification for the client-render procedure.
 * It intentionally generates one premium floral image through the same protected
 * tRPC path used by the workspace, then reports the stored presentation URL.
 */
import assert from "node:assert/strict";
import { appRouter } from "../server/routers";
import type { TrpcContext } from "../server/_core/context";

const ctx: TrpcContext = {
  user: {
    id: 1,
    openId: "client-render-verifier",
    email: null,
    name: "Client Render Verifier",
    loginMethod: "manual-verification",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  },
  req: { protocol: "https", headers: {} } as TrpcContext["req"],
  res: { clearCookie: () => undefined } as TrpcContext["res"],
};

const result = await appRouter.createCaller(ctx).clientRender.generate({
  blueprintName: "Client render verification study",
  emotionalIntent: "quiet, grounded, and artfully composed",
  sourceFingerprint: "manual-verification-fingerprint",
  base: { diameterIn: 24, ringWidthIn: 5, depthIn: 4 },
  anchor: { startClock: "7:00", endClock: "9:00", depthRatio: 0.94, visualWeight: 0.6 },
  sweep: { startClock: "9:00", endClock: "1:30", curvature: 0.18, taper: 0.42, widthIn: 1.5 },
  echo: { clock: "5:00", arcDegrees: 34, depthRatio: 0.64, visualWeight: 0.18 },
  clearance: { clock: "8:00", purpose: "bow", arcDegrees: 22 },
});

assert.match(result.url, /^(https?:\/\/|\/manus-storage\/)/, "generation should return a storage URL");
assert.equal(result.sourceFingerprint, "manual-verification-fingerprint");
console.log(`Client render generated and stored: ${result.url}`);

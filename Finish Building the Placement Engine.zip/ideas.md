# Evercrafted Placement Engine — Design Exploration

## Three possible directions

### Botanical Drafting Atelier
**Very Brief Intro:** An elevated editorial workspace where wreath composition feels like working at a florist's drafting table: quiet, precise, and tactile. Natural paper, charcoal ink, and restrained botanical colour create an experience that is luxurious without feeling ornamental.

**Probability:** 0.07

### Conservatory Signals
**Very Brief Intro:** A luminous botanical laboratory that combines greenhouse light, airy glass surfaces, and technical controls. It emphasizes discovery and experimentation with a refined scientific undertone.

**Probability:** 0.04

### Verdant Gallery
**Very Brief Intro:** A gallery-like composition tool that treats every wreath as a collectible arrangement. Dramatic dark walls, spotlighting, and large-format imagery frame the work as design art.

**Probability:** 0.09

## Selected Direction: Botanical Drafting Atelier

### Design Movement
Contemporary editorial design informed by botanical field guides, archival herbarium sheets, and the measured precision of an architectural drawing studio.

### Core Principles
1. Make the wreath canvas the hero: every surrounding control should support the act of composing.
2. Balance the organic and the technical through paper-like neutrals, fine rules, and botanical marks.
3. Use hierarchy rather than decoration: labels, spacing, and line weight should communicate status and relationships instantly.
4. Keep luxury tactile and quiet: avoid glossy gradients, visual noise, and generic dashboard styling.

### Color Philosophy
Warm parchment creates the feeling of a working surface rather than a generic white interface. Charcoal provides authority and legibility, while moss is reserved for deliberate signals of growth, active placement, and confidence. A restrained terracotta highlight evokes dried botanical material and adds warmth without overtaking the composition.

### Layout Paradigm
An asymmetric atelier bench: a narrow utility rail holds the physical materials, a generous central drafting surface holds the wreath blueprint, and a compact right-side inspector provides the precise numerical and placement decisions. On small screens, these become focused, sequential workstations rather than a compressed desktop tableau.

### Signature Elements
* A faint radial drafting guide beneath the live wreath canvas.
* Botanical specimen cards with a clipped-paper corner and a coloured composition tab.
* Fine double-rule separators and numbered field-guide labels for zones and control groups.

### Interaction Philosophy
Direct manipulation should feel deliberate. Materials are selected and placed with clear active states, controls provide immediate visual feedback, and consequential actions are obvious and reversible. Hover states lift only slightly; the interface should never compete with the arrangement.

### Animation
Use brief, tactile transitions of 160–240ms with a strong ease-out curve. Item selection uses a subtle translate and border-color change; placements enter at 95% scale with opacity transition. The wreath preview may gently fade between arrangement states. Honour `prefers-reduced-motion` by eliminating decorative movement.

### Typography System
Use **Cormorant Garamond** for the expressive display hierarchy and **DM Sans** for precise controls, data labels, and body copy. Display titles should be compact and editorial; control typography should use measured tracking and small uppercase labels only where they improve scanning.

### Brand Essence
**Evercrafted turns a florist's inventory into composed, repeatable wreath blueprints for designers who want beauty without guesswork.**

Personality: **cultivated, precise, calm.**

### Brand Voice
Headlines should sound considered and craft-led; CTAs should use verbs that describe a designer’s next move rather than generic product language. Microcopy should clarify a decision without sounding mechanical.

Examples: “Compose the season, stem by stem.” and “Place with intention.”

### Wordmark & Logo
Use a compact circular rosette built from five offset leaf-shaped strokes, evoking both a wreath and a placement target. The wordmark pairs a high-contrast serif with disciplined sans-serif metadata.

### Signature Brand Color
**Canopy Moss — #496A4E**: a deep, botanically credible green used only for the most meaningful interactive and brand signals.

## Style Decisions

* The interface is parchment-first rather than dark-mode-first: warm paper neutrals define the working rails and review surfaces, while charcoal is reserved for ink-like structure and the framed wreath canvas.
* User-facing language should be botanical and craft-led, favouring placement, anchor, balance, composition, and blueprint over internal process terminology whenever a change in wording does not weaken the underlying engine contract.
* Every major surface should reference the atelier system through a fine double rule, a numbered field-guide label, or a specimen-card material treatment.
* Utility actions use atelier language where clarity allows: designers **preserve**, begin a **new study**, access a **library**, and **send** or **bring** blueprint JSON.
* Canopy Moss remains reserved for brand identity, confirmed actions, active controls, and primary composition signals; secondary editorial headings use ink and parchment tones instead.
* Composition-review surfaces use field-note labels, double-rule card tops, and deliberate breathing room so their critique reads as authored studio material rather than an audit table.

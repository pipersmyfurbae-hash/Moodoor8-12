# Render Preview Enhancement

- [x] Define the downstream render state, render eligibility, and provenance rules.
- [x] Build the blueprint-derived wreath composition preview and render controls.
- [x] Connect preview refresh, save-state messaging, and visual review feedback.
- [x] Verify production build, imported engine tests, preview provenance, and desktop/mobile presentation.
- [x] Save a delivery-ready checkpoint.

## Client-Facing High-Fidelity Rendering

- [x] Repair the upgrade-introduced Home component authentication-hook regression.
- [x] Upgrade the application to support secure server-side image generation.
- [x] Define a blueprint-to-render prompt and provenance contract for client presentation images.
- [x] Build an optional generation flow, loading state, and client-preview presentation.
- [x] Validate generated-render capture, fallback states, and project regression checks.
- [x] Save a delivery-ready checkpoint.

## Greenery Architecture and Floral Pockets

- [x] Define the editable geometry, hierarchy, and validation contracts for greenery architecture and floral pockets.
- [x] Build the Greenery Architecture studio level with canopy, gesture, and reserve controls.
- [x] Build the Floral Pockets studio level with anchor, echo, and negative-space composition controls.
- [x] Carry the two new studio layers into deterministic studies and client-render prompts.
- [x] Validate the expanded workspace, renderer contract, and regression suites.
- [x] Save a delivery-ready checkpoint.

## Floral Roles and Operating Guide

- [x] Define focal, supporting, and accent material assignments for every floral pocket.
- [x] Build the Floral Roles studio level with editable role, material, palette, and quantity guidance.
- [x] Include floral assignments in deterministic studies, client-render briefs, and a Midjourney-ready prompt export.
- [x] Write a complete guide for operating the app, producing presentations, and using Midjourney export.
- [x] Validate role persistence, deterministic study output, prompt export, and full regression suites.
- [x] Save a delivery-ready checkpoint.

## Live Inventory Matching

- [x] Add a local JSON file picker, documented inventory template, schema validation, and import summary.
- [x] Persist the imported source timestamp and inventory snapshot inside the app without fabricating stock data.
- [x] Define the real inventory source, material identity, quantity, and freshness contract.
- [x] Build secure inventory synchronization and availability matching for Floral Role assignments.
- [x] Surface available, limited, unavailable, and unmatched states with actionable role-level feedback.
- [x] Gate presentation exports with clear inventory status while preserving blueprint editing.
- [x] Validate inventory matching, freshness behavior, presentation safeguards, and regression suites with the imported JSON snapshot source.
- [x] Save a delivery-ready checkpoint.

## Approved Material Substitutions

- [x] Define inventory-backed alternative ranking, eligibility, and approval provenance rules.
- [x] Generate transparent substitute suggestions for limited or unavailable Floral Role materials.
- [x] Add approve, apply, and revert controls that preserve the original material assignment and reason.
- [x] Recheck inventory and presentation readiness after every applied substitution.
- [x] Validate substitution safety, persistence, and regression suites.
- [x] Save a delivery-ready checkpoint.

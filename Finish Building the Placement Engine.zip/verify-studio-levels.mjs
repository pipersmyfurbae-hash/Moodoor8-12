/** Verify optional Studio 2 objects, explainability, validation, and render propagation. */
import assert from 'node:assert/strict';
import { createBlueprint } from '../client/src/engine/core/schema.js';
import { activateStudioLayer } from '../client/src/engine/core/actions.js';
import { explainObject } from '../client/src/engine/core/explain.js';
import { validateBlueprint } from '../client/src/engine/core/validate.js';
import { buildClientRenderInput } from '../client/src/engine/ui/render-preview.js';

const base = createBlueprint({ now: '2026-08-12T00:00:00.000Z' });
assert.equal(base.objects.length, 4, 'the canonical base blueprint should remain unchanged');

const greenery = activateStudioLayer(base, 'greenery');
assert.deepEqual(greenery.objects.filter((obj) => obj.kind === 'behavior_path').map((obj) => obj.role), ['primary_sweep', 'canopy_arch', 'greenery_bridge']);
assert.equal(validateBlueprint(greenery).ok, true, 'greenery studio layer should stay saveable');

const floral = activateStudioLayer(greenery, 'floral');
assert.ok(floral.objects.some((obj) => obj.role === 'support_pocket'));
assert.ok(floral.objects.some((obj) => obj.role === 'transition_pocket'));
assert.equal(validateBlueprint(floral).ok, true, 'floral pockets should remain saveable');
for (const role of ['primary_anchor', 'secondary_echo', 'support_pocket', 'transition_pocket']) {
  const pocket = floral.objects.find((obj) => obj.role === role);
  assert.ok(pocket.greenery_relationship && pocket.negative_space_clearance > 0, `${role} should expose greenery and breathing-reserve controls`);
}
assert.deepEqual(
  validateBlueprint(floral).advisory
    .filter((result) => ['greenery_architecture_readable', 'floral_pockets_integrated'].includes(result.id))
    .map((result) => result.status),
  ['pass', 'pass'],
  'activated studio layers should surface their own passing composition checks',
);

for (const role of ['canopy_arch', 'greenery_bridge', 'support_pocket', 'transition_pocket']) {
  const object = floral.objects.find((item) => item.role === role);
  assert.ok(explainObject(floral, object).canonRules.length > 0, `${role} should have canon citations`);
}

const renderInput = buildClientRenderInput(floral);
assert.equal(renderInput.greeneryArchitecture.length, 2);
assert.equal(renderInput.floralPockets.length, 2);
console.log('Greenery Architecture and Floral Pockets verification passed.');

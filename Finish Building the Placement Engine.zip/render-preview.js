/**
 * Botanical Drafting Atelier — formal and client-facing render studies.
 * Both studies are derived from the editable blueprint; neither replaces it as
 * the source of truth for placement, explanation, or downstream revisioning.
 */
import { getAnchor, getClearance, getEcho, getSweep, objectRange, baseRadii } from '../core/schema.js';
import { annulusSectorPath, bandWidthToInches, formatClock, polar, subtractArc, sweepRibbonPath } from '../core/geometry.js';
import { h, s } from './dom.js';

const SIZE = 220;
const CENTER = SIZE / 2;

export function previewFingerprint(bp) {
  return JSON.stringify({
    base: [bp.base.diameter_in, bp.base.ring_width_in, bp.base.depth_in],
    intent: bp.emotional_profile?.intent ?? '',
    objects: [...bp.objects]
      .sort((a, b) => a.id.localeCompare(b.id))
      .map((obj) => ({
        id: obj.id,
        kind: obj.kind,
        role: obj.role,
        visible: obj.visible,
        locked: obj.locked,
        start_deg: obj.start_deg,
        center_deg: obj.center_deg,
        arc_deg: obj.arc_deg,
        depth_ratio: obj.depth_ratio,
        visual_weight: obj.visual_weight,
        radial_position: obj.radial_position,
        radial_extent: obj.radial_extent,
        band_width_norm: obj.band_width_norm,
        curvature: obj.curvature,
        taper: obj.taper,
      })),
  });
}

export function buildClientRenderInput(bp) {
  const { ringWidth } = baseRadii(bp.base);
  const anchor = getAnchor(bp);
  const sweep = getSweep(bp);
  const echo = getEcho(bp);
  const clearance = getClearance(bp);
  const anchorRange = objectRange(anchor);
  const sweepRange = objectRange(sweep);

  return {
    blueprintName: bp.name || 'Untitled blueprint',
    emotionalIntent: bp.emotional_profile?.intent ?? '',
    sourceFingerprint: previewFingerprint(bp),
    base: { diameterIn: bp.base.diameter_in, ringWidthIn: bp.base.ring_width_in, depthIn: bp.base.depth_in },
    anchor: {
      startClock: formatClock(anchorRange.start),
      endClock: formatClock(anchorRange.start + anchorRange.span),
      depthRatio: anchor.depth_ratio,
      visualWeight: anchor.visual_weight,
    },
    sweep: {
      startClock: formatClock(sweepRange.start),
      endClock: formatClock(sweepRange.start + sweepRange.span),
      curvature: sweep.curvature,
      taper: sweep.taper,
      widthIn: bandWidthToInches(sweep.band_width_norm, ringWidth),
    },
    echo: {
      clock: formatClock(echo.center_deg),
      arcDegrees: echo.arc_deg,
      depthRatio: echo.depth_ratio,
      visualWeight: echo.visual_weight,
    },
    clearance: clearance?.visible === false || !clearance
      ? null
      : { clock: formatClock(clearance.center_deg), purpose: clearance.purpose, arcDegrees: clearance.arc_deg },
    greeneryArchitecture: bp.objects
      .filter((obj) => obj.kind === 'behavior_path' && obj.role !== 'primary_sweep' && obj.visible !== false)
      .map((obj) => {
        const range = objectRange(obj);
        return {
          behavior: obj.behavior_type,
          startClock: formatClock(range.start),
          endClock: formatClock(range.start + range.span),
          depthBand: obj.depth_band ?? 'middle',
          widthIn: bandWidthToInches(obj.band_width_norm, ringWidth),
        };
      }),
    floralPockets: bp.objects
      .filter((obj) => ['support_pocket', 'transition_pocket'].includes(obj.role) && obj.visible !== false)
      .map((obj) => ({
        type: obj.pocket_type,
        clock: formatClock(obj.center_deg),
        arcDegrees: obj.arc_deg,
        depthRatio: obj.depth_ratio,
        visualWeight: obj.visual_weight,
        relationship: obj.greenery_relationship ?? 'integrated with the existing greenery architecture',
      })),
    floralRoles: floralRoleAssignments(bp),
  };
}

export function floralRoleAssignments(bp) {
  return bp.objects
    .filter((obj) => obj.kind === 'pocket')
    .flatMap((obj) => (obj.floral_roles ?? [])
      .filter((assignment) => assignment.material || assignment.palette || assignment.note || Number(assignment.quantity) > 0)
      .map((assignment) => ({
        pocket: obj.label,
        role: assignment.role,
        material: assignment.material ?? '',
        palette: assignment.palette ?? '',
        quantity: Number(assignment.quantity) || 0,
        note: assignment.note ?? '',
      })));
}

export function buildMidjourneyPrompt(bp) {
  const input = buildClientRenderInput(bp);
  const roleBrief = input.floralRoles.length
    ? input.floralRoles.map((assignment) => `${assignment.role} in ${assignment.pocket}: ${[assignment.material, assignment.palette, assignment.quantity ? `${assignment.quantity} stems` : '', assignment.note].filter(Boolean).join(', ')}`).join('; ')
    : 'no material assignments yet — interpret focal, supporting, and accent florals with botanical restraint';
  const greeneryBrief = input.greeneryArchitecture.length
    ? input.greeneryArchitecture.map((path) => `${path.behavior} greenery from ${path.startClock} to ${path.endClock} at ${path.depthBand} depth`).join('; ')
    : `a restrained sweeping greenery gesture from ${input.sweep.startClock} to ${input.sweep.endClock}`;

  return `/imagine prompt: premium editorial product photograph of a handcrafted botanical wreath, ${input.base.diameterIn}-inch circular grapevine form, ${input.emotionalIntent || 'quietly composed and naturally elegant'}; dominant floral anchor from ${input.anchor.startClock} to ${input.anchor.endClock}, balanced lighter echo near ${input.echo.clock}; ${greeneryBrief}; floral material direction: ${roleBrief}; intentional negative space and a clear ${input.clearance ? `${input.clearance.clock} ${input.clearance.purpose} opening` : 'hardware opening'}; warm parchment-toned studio background, natural side light, refined floristry, realistic botanical texture, visible depth, elevated still-life art direction --ar 1:1 --stylize 125 --no text --no labels --no measurements`;
}

export function renderPreviewStudy(bp, { ready, onRender, onClientRender, clientRenderState = { status: 'idle' } }) {
  const preview = bp.render_preview ?? {};
  const fresh = Boolean(preview.source_fingerprint && preview.source_fingerprint === previewFingerprint(bp));
  const clientRender = bp.client_render ?? {};
  const clientRenderFresh = Boolean(clientRender.url && clientRender.source_fingerprint === previewFingerprint(bp));
  const status = !ready
    ? 'Resolve the essential placement checks before capturing a formal study.'
    : fresh
      ? `Study current · captured ${formatTimestamp(preview.generated_at)}`
      : 'Placement has changed. Refresh the study when the composition feels ready.';

  const buttonLabel = fresh ? 'Refresh study' : 'Capture study';
  const clientLabel = clientRenderState.status === 'generating'
    ? 'Composing…'
    : clientRender.url
      ? 'Refresh client render'
      : 'Generate client render';
  const roleAssignments = floralRoleAssignments(bp);

  return h('section', { class: 'render-study' },
    h('div', { class: 'render-study-head' },
      h('div', {},
        h('span', { class: 'study-kicker', text: 'Downstream preview' }),
        h('h4', { class: 'study-title', text: 'Formal wreath study' })),
      h('span', { class: `study-status ${fresh ? 'is-fresh' : 'is-stale'}${ready ? '' : ' is-blocked'}`, text: fresh ? 'Current' : ready ? 'Needs refresh' : 'Held' })),
    clientRender.url
      ? h('div', { class: `client-render-frame${clientRenderFresh ? '' : ' is-stale'}` },
          h('img', { class: 'client-render-image', src: clientRender.url, alt: `Client-facing floral rendering for ${bp.name}` }),
          !clientRenderFresh ? h('span', { class: 'client-render-stale-note', text: 'Blueprint changed after this render — refresh before sharing.' }) : null)
      : wreathStudySvg(bp),
    h('p', { class: 'render-study-summary', text: clientRender.url
      ? 'High-fidelity presentation render generated from the current blueprint. The blueprint remains the editable source of truth.'
      : 'A deterministic visual interpretation of the anchor, sweep, echo, and open space currently defined in this blueprint.' }),
    roleAssignments.length
      ? h('section', { class: 'study-role-summary' },
          h('span', { class: 'study-kicker', text: 'Floral role notes' }),
          h('div', { class: 'study-role-list' }, ...roleAssignments.map((assignment) =>
            h('div', { class: `study-role-entry role-${assignment.role}` },
              h('span', { class: 'study-role-name', text: `${assignment.role} · ${assignment.pocket}` }),
              h('span', { class: 'study-role-material', text: [assignment.material, assignment.palette, assignment.quantity ? `${assignment.quantity} stems` : ''].filter(Boolean).join(' · ') || assignment.note })))))
      : null,
    clientRenderState.status === 'error'
      ? h('p', { class: 'client-render-feedback is-error', text: clientRenderState.error || 'The client render could not be generated. The formal study remains available.' })
      : clientRenderState.status === 'generating'
        ? h('p', { class: 'client-render-feedback', text: 'Composing the florist-made presentation image from the current placement study…' })
        : null,
    h('div', { class: 'render-study-footer' },
      h('span', { class: 'render-study-note', text: status }),
      h('div', { class: 'render-actions' },
        h('button', { class: 'btn btn-study', type: 'button', disabled: !ready, onClick: onRender }, buttonLabel),
        h('button', {
          class: 'btn btn-client-render',
          type: 'button',
          disabled: !ready || clientRenderState.status === 'generating',
          onClick: onClientRender,
        }, clientLabel))));
}

function wreathStudySvg(bp) {
  const { rInner, rOuter, ringWidth } = baseRadii(bp.base);
  const scale = 83 / rOuter;
  const inner = rInner * scale;
  const outer = rOuter * scale;
  const anchor = getAnchor(bp);
  const clearance = getClearance(bp);
  const sweep = getSweep(bp);
  const echo = getEcho(bp);
  const architecture = bp.objects.filter((obj) => obj.kind === 'behavior_path' && obj.role !== 'primary_sweep' && obj.visible !== false);
  const floralPockets = bp.objects.filter((obj) => ['support_pocket', 'transition_pocket'].includes(obj.role) && obj.visible !== false);
  const children = [];

  children.push(s('circle', { cx: CENTER, cy: CENTER, r: outer + 6, class: 'study-shadow-ring' }));
  children.push(s('circle', { cx: CENTER, cy: CENTER, r: outer, class: 'study-base-ring' }));
  children.push(s('circle', { cx: CENTER, cy: CENTER, r: inner, class: 'study-inner-hole' }));
  children.push(...greeneryStems(inner, outer));

  if (sweep?.visible !== false) {
    const path = sweepRibbonPath({
      startDeg: sweep.start_deg,
      arcDeg: sweep.arc_deg,
      rInner: inner,
      rOuter: outer,
      radialPosition: sweep.radial_position,
      curvature: sweep.curvature,
      thicknessIn: bandWidthToInches(sweep.band_width_norm, ringWidth) * scale,
      taper: sweep.taper,
      samples: 48,
    }, CENTER, CENTER);
    children.push(s('path', { d: path, class: 'study-sweep-band' }));
    children.push(...stemDots(sweep, inner, outer, 13, 'study-sweep-dot'));
  }

  for (const pathObject of architecture) {
    const path = sweepRibbonPath({
      startDeg: pathObject.start_deg,
      arcDeg: pathObject.arc_deg,
      rInner: inner,
      rOuter: outer,
      radialPosition: pathObject.radial_position,
      curvature: pathObject.curvature,
      thicknessIn: bandWidthToInches(pathObject.band_width_norm, ringWidth) * scale,
      taper: pathObject.taper,
      samples: 36,
    }, CENTER, CENTER);
    children.push(s('path', { d: path, class: `study-architecture-band study-${pathObject.behavior_type}` }));
  }

  if (anchor?.visible !== false) {
    const anchorRange = objectRange(anchor);
    const hole = clearance?.visible === false || !clearance ? null : objectRange(clearance);
    for (const segment of subtractArc(anchorRange, hole)) {
      children.push(s('path', { d: annulusSectorPath(inner + 4, outer - 3, segment, CENTER, CENTER), class: 'study-anchor-mass' }));
    }
    children.push(...floralHeads(anchor, inner, outer, 8, 'study-anchor-bloom'));
  }

  if (echo?.visible !== false) {
    children.push(s('path', { d: annulusSectorPath(inner + 8, outer - 8, objectRange(echo), CENTER, CENTER), class: 'study-echo-mass' }));
    children.push(...floralHeads(echo, inner, outer, 4, 'study-echo-bloom'));
  }

  for (const pocket of floralPockets) {
    const range = objectRange(pocket);
    children.push(s('path', { d: annulusSectorPath(inner + 7, outer - 8, range, CENTER, CENTER), class: `study-pocket-mass study-${pocket.pocket_type}` }));
    children.push(...floralHeads(pocket, inner, outer, pocket.role === 'support_pocket' ? 3 : 2, `study-${pocket.pocket_type}-bloom`));
  }

  if (clearance?.visible !== false) {
    const point = polar((inner + outer) / 2, clearance.center_deg, CENTER, CENTER);
    children.push(s('path', { d: bowPath(point.x, point.y), class: 'study-bow' }));
  }

  children.push(s('circle', { cx: CENTER, cy: CENTER, r: 2.8, class: 'study-core-dot' }));
  return s('svg', { class: 'render-study-visual', viewBox: `0 0 ${SIZE} ${SIZE}`, role: 'img', 'aria-label': 'Formal wreath preview derived from the current placement blueprint' }, children);
}

function greeneryStems(inner, outer) {
  return Array.from({ length: 38 }, (_, index) => {
    const angle = index * (360 / 38) + (index % 2 ? 2.5 : -2.5);
    const start = polar(inner + 2, angle, CENTER, CENTER);
    const end = polar(outer - 3, angle + (index % 3 - 1) * 4, CENTER, CENTER);
    return s('path', { d: `M ${start.x} ${start.y} Q ${(start.x + end.x) / 2} ${(start.y + end.y) / 2 - 4} ${end.x} ${end.y}`, class: 'study-greenery-stem' });
  });
}

function floralHeads(obj, inner, outer, count, className) {
  const range = objectRange(obj);
  return Array.from({ length: count }, (_, index) => {
    const angle = range.start + range.span * ((index + 0.5) / count);
    const radius = inner + (outer - inner) * (0.42 + (index % 3) * 0.1);
    const { x, y } = polar(radius, angle, CENTER, CENTER);
    const size = obj.role === 'primary_anchor' ? 7 + (index % 2) * 1.4 : 5 + (index % 2);
    return s('g', { transform: `rotate(${angle} ${x} ${y})` },
      s('ellipse', { cx: x - size * 0.38, cy: y, rx: size * 0.62, ry: size * 0.38, class: className }),
      s('ellipse', { cx: x + size * 0.38, cy: y, rx: size * 0.62, ry: size * 0.38, class: className }),
      s('ellipse', { cx: x, cy: y - size * 0.38, rx: size * 0.38, ry: size * 0.62, class: className }),
      s('ellipse', { cx: x, cy: y + size * 0.38, rx: size * 0.38, ry: size * 0.62, class: className }));
  });
}

function stemDots(obj, inner, outer, count, className) {
  const range = objectRange(obj);
  return Array.from({ length: count }, (_, index) => {
    const angle = range.start + range.span * ((index + 0.3) / count);
    const radius = inner + (outer - inner) * (0.42 + (index % 4) * 0.08);
    const { x, y } = polar(radius, angle, CENTER, CENTER);
    return s('circle', { cx: x, cy: y, r: index % 3 === 0 ? 2.1 : 1.4, class: className });
  });
}

function bowPath(x, y) {
  return `M ${x - 8} ${y} C ${x - 18} ${y - 10}, ${x - 21} ${y + 7}, ${x - 8} ${y + 5} C ${x - 3} ${y + 4}, ${x - 3} ${y + 2}, ${x} ${y} C ${x + 3} ${y + 2}, ${x + 3} ${y + 4}, ${x + 8} ${y + 5} C ${x + 21} ${y + 7}, ${x + 18} ${y - 10}, ${x + 8} ${y} Z`;
}

function formatTimestamp(value) {
  if (!value) return 'just now';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? 'just now' : date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

/** MOODOOR STORIES / LOOKBOOK — public publishing surfaces managed in the owner workspace. */
import { trpc } from "@/lib/trpc";
import { ArrowRight, BookOpenText, Loader2, Sparkles } from "lucide-react";
import { Link } from "wouter";

export default function Stories({ lookbook = false }: { lookbook?: boolean }) {
  const { data, isLoading } = trpc.workspace.publicStories.useQuery(undefined, { retry: false });
  const entries = (data ?? []).filter((story) => lookbook ? story.kind === "lookbook" : story.kind !== "lookbook");
  const heading = lookbook ? "The Moodoor lookbook." : "Moodoor Stories.";
  const lede = lookbook ? "A visual archive of finished forms, materials, and the places a wreath can hold." : "Field notes from the studio: the memories, material decisions, and seasonal rituals behind each Moodoor collection.";
  return <section className="stories-page"><div className="shell-width"><header className="stories-hero"><p className="eyebrow">Moodoor / {lookbook ? "Homepage lookbook" : "Lifestyle stories"}</p><h1>{heading}</h1><p>{lede}</p><div className="stories-switch"><Link href="/stories" className={!lookbook ? "active" : ""}>Stories</Link><Link href="/lookbook" className={lookbook ? "active" : ""}>Lookbook</Link></div></header>{isLoading ? <div className="stories-empty"><Loader2 className="animate-spin" /> Loading the archive…</div> : entries.length ? <div className="stories-grid">{entries.map((story, index) => <article className={index === 0 ? "story-card feature" : "story-card"} key={story.slug}>{story.imageUrl ? <img src={story.imageUrl} alt={story.title} /> : <div className="story-blank"><Sparkles /></div>}<div><span>{story.eyebrow || story.kind}</span><h2>{story.title}</h2><p>{story.excerpt || story.body || "A Moodoor story is being prepared."}</p>{story.linkedProductSlug && <Link href={`/wreath/${story.linkedProductSlug}`}>View the wreath <ArrowRight size={13} /></Link>}</div></article>)}</div> : <div className="stories-empty"><BookOpenText size={25} /><div><h2>The first field note is still being written.</h2><p>The owner can publish Moodoor Lifestyle Stories, Story Genesis pieces, studio notes, and Lookbook entries from the Moodoor OS workspace.</p><Link href="/how-it-works">Explore how Moodoor works <ArrowRight size={13} /></Link></div></div>}</div></section>;
}

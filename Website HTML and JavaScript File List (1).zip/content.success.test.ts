import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  getAdminContentOverview: vi.fn(), getPublicContentOverview: vi.fn(), removeBundle: vi.fn(), removeCatalogProduct: vi.fn(), removeDrop: vi.fn(), removeTerritory: vi.fn(), saveBundle: vi.fn(), saveCatalogProduct: vi.fn(), saveDrop: vi.fn(), saveSiteContent: vi.fn(), saveTerritory: vi.fn(), storagePut: vi.fn(),
}));

vi.mock("./db", () => mocks);
vi.mock("./storage", () => ({ storagePut: mocks.storagePut }));

import { appRouter } from "./routers";

function adminContext(): TrpcContext {
  return {
    user: { id: 7, openId: "moodoor-owner", email: "owner@example.com", name: "Owner", loginMethod: "manus", role: "admin", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("content administration success paths", () => {
  it("persists a stock-bearing product with its managed blueprint asset metadata", async () => {
    const caller = appRouter.createCaller(adminContext());
    mocks.saveCatalogProduct.mockResolvedValue(undefined);
    await expect(caller.content.saveProduct({ slug: "test-wreath", name: "Test Wreath", territory: "Comfort", lede: "A test", description: "A test description", price: 245, blueprintCode: "BP-TEST", listingImageUrl: null, listingImageKey: null, heroImageUrl: null, heroImageKey: null, inventoryQuantity: 2, runLimit: 5, blueprintPrice: 39, blueprintAssetUrl: "/manus-storage/test.pdf", blueprintAssetKey: "moodoor-blueprints/test.pdf", blueprintFilename: "test.pdf", blueprintMimeType: "application/pdf", isPublished: true, sortOrder: 3 })).resolves.toEqual({ success: true });
    expect(mocks.saveCatalogProduct).toHaveBeenCalledWith(expect.objectContaining({ updatedBy: 7, inventoryQuantity: 2, runLimit: 5, blueprintPrice: "39.00", blueprintFilename: "test.pdf" }));
  });

  it("persists bundle, territory, and seasonal-drop records through the owner API", async () => {
    const caller = appRouter.createCaller(adminContext());
    mocks.saveBundle.mockResolvedValue(undefined); mocks.saveTerritory.mockResolvedValue(undefined); mocks.saveDrop.mockResolvedValue(undefined);
    await expect(caller.content.saveBundle({ slug: "test-bundle", name: "Test Bundle", territory: "Comfort", price: 99, saving: "Save $10", lede: "A collection", productSlugs: ["test-wreath"], tone: "olive", imageUrl: null, imageKey: null, isPublished: true, sortOrder: 0 })).resolves.toEqual({ success: true });
    await expect(caller.content.saveTerritory({ slug: "test-territory", name: "Test Territory", description: "A place in the archive", designCount: 4, tone: "amber", imageUrl: null, imageKey: null, isPublished: true, sortOrder: 0 })).resolves.toEqual({ success: true });
    await expect(caller.content.saveDrop({ slug: "test-drop", title: "Test Drop", timingLabel: "Late autumn", status: "next", lede: "A small release", description: "A detailed release note", tagSlugs: ["test-territory"], finishedRunCount: 5, blueprintCount: 3, imageUrl: null, imageKey: null, launchAt: null, isPublished: true, sortOrder: 0 })).resolves.toEqual({ success: true });
    expect(mocks.saveBundle).toHaveBeenCalledWith(expect.objectContaining({ updatedBy: 7, price: "99.00", productSlugsJson: "[\"test-wreath\"]" }));
    expect(mocks.saveTerritory).toHaveBeenCalledWith(expect.objectContaining({ updatedBy: 7, designCount: 4 }));
    expect(mocks.saveDrop).toHaveBeenCalledWith(expect.objectContaining({ updatedBy: 7, status: "next", tagSlugsJson: "[\"test-territory\"]" }));
  });

  it("stores a validated PDF blueprint through managed storage for an authorized owner", async () => {
    const caller = appRouter.createCaller(adminContext());
    mocks.storagePut.mockResolvedValue({ key: "moodoor-blueprints/7/asset-test.pdf", url: "/manus-storage/asset-test.pdf" });
    const pdf = Buffer.from("%PDF-1.7\n% Moodoor").toString("base64");
    await expect(caller.content.uploadBlueprint({ dataUrl: `data:application/pdf;base64,${pdf}`, filename: "Moodoor blueprint.pdf" })).resolves.toMatchObject({ url: "/manus-storage/asset-test.pdf", filename: "Moodoor-blueprint.pdf", mimeType: "application/pdf" });
    expect(mocks.storagePut).toHaveBeenCalledWith(expect.stringContaining("moodoor-blueprints/7/"), expect.any(Buffer), "application/pdf");
  });
});

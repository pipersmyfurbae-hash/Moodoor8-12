/**
 * MOODOOR / THE MEMORY ARCHIVE
 * Global navigation, door-wreath identity, and calm paper cart drawer preserve a clear route back from every folio.
 */
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { money } from "@/lib/catalog";
import { CircleUserRound, LogOut, Menu, Minus, Plus, Settings, ShoppingBag, WandSparkles, X } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

const navItems = [
  ["Wreaths", "/wreaths"], ["Blueprints", "/blueprints"], ["Bundles", "/bundles"], ["Drops", "/drops"], ["Reveal", "/reveal"], ["Territories", "/territories"], ["Stories", "/stories"], ["How it works", "/how-it-works"],
];

export function SiteChrome({ children }: { children: React.ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [ownerMenuOpen, setOwnerMenuOpen] = useState(false);
  const [location] = useLocation();
  const [, setLocation] = useLocation();
  const { count, drawerOpen, setDrawerOpen } = useCart();
  const { user, logout, loading } = useAuth();
  const isOwner = user?.role === "admin";
  const signOut = async () => { try { await logout(); setOwnerMenuOpen(false); toast.success("Signed out of Moodoor"); setLocation("/"); } catch { toast.error("Unable to sign out. Please try again."); } };
  return <div className="site-shell">
    <header className="site-header">
      <div className="shell-width nav-row">
        <Link href="/" className="brand" aria-label="Moodoor home" onClick={() => setMenuOpen(false)}>
          <img src="/manus-storage/moodoor-symbol_912ef462.png" alt="" className="brand-mark" />
          <span>Mood<span>oor</span></span>
        </Link>
        <nav className="desktop-nav" aria-label="Primary navigation">
          {navItems.map(([label, href]) => <Link href={href} key={href} className={location === href ? "active" : ""}>{label}</Link>)}
        </nav>
        <div className="nav-actions">
          {isOwner && <div className="owner-profile"><button className="owner-profile-trigger" aria-label="Open owner profile menu" aria-expanded={ownerMenuOpen} onClick={() => setOwnerMenuOpen((open) => !open)}><span className="owner-avatar">{(user?.name || user?.email || "O").trim().charAt(0).toUpperCase()}</span><span className="owner-profile-label">Owner</span><CircleUserRound size={13} /></button>{ownerMenuOpen && <div className="owner-profile-popover"><div className="owner-profile-summary"><b>{user?.name || "Moodoor owner"}</b><span>{user?.email || "Owner account"}</span></div><Link href="/account" onClick={() => setOwnerMenuOpen(false)}><CircleUserRound size={14} /> Account settings</Link><Link href="/admin?tab=studio" onClick={() => setOwnerMenuOpen(false)}><WandSparkles size={14} /> Studio</Link><Link href="/admin" onClick={() => setOwnerMenuOpen(false)}><Settings size={14} /> Content Room</Link><button disabled={loading} onClick={() => void signOut()}><LogOut size={14} /> Sign out</button></div>}</div>}
          <Link href="/matching" className="button button-olive nav-match">Begin a memory</Link>
          <button className="cart-button" aria-label={`Open cart, ${count} items`} onClick={() => setDrawerOpen(true)}><ShoppingBag size={19} /><span className={count ? "cart-count visible" : "cart-count"}>{count}</span></button>
          <button className="mobile-menu" aria-label="Toggle navigation" onClick={() => setMenuOpen((open) => !open)}>{menuOpen ? <X /> : <Menu />}</button>
        </div>
      </div>
      {menuOpen && <nav className="mobile-nav" aria-label="Mobile navigation">
        {navItems.map(([label, href]) => <Link href={href} key={href} onClick={() => setMenuOpen(false)}>{label}</Link>)}
        {isOwner && <Link href="/admin" onClick={() => setMenuOpen(false)} className="admin-mobile-entry">Open Content Room</Link>}
        {isOwner && <Link href="/account" onClick={() => setMenuOpen(false)} className="admin-mobile-entry">Owner account settings</Link>}
        {isOwner && <button type="button" className="admin-mobile-signout" onClick={() => void signOut()}><LogOut size={14} /> Sign out</button>}
        <Link href="/matching" className="button button-olive" onClick={() => setMenuOpen(false)}>Begin a memory</Link>
      </nav>}
    </header>
    <main>{children}</main>
    <Footer isOwner={isOwner} />
    <CartDrawer open={drawerOpen} close={() => setDrawerOpen(false)} />
  </div>;
}

function CartDrawer({ open, close }: { open: boolean; close: () => void }) {
  const { items, total, updateQuantity, remove } = useCart();
  return <>
    {open && <button className="cart-backdrop" onClick={close} aria-label="Close cart" />}
    <aside className={open ? "cart-drawer open" : "cart-drawer"} aria-label="Shopping cart" aria-hidden={!open}>
      <div className="drawer-head"><div><p className="eyebrow">Your cart</p><h2>{items.length ? `${items.length} ${items.length === 1 ? "item" : "items"}` : "Empty"}</h2></div><button onClick={close} className="icon-button" aria-label="Close cart"><X /></button></div>
      <div className="drawer-body">
        {!items.length ? <div className="empty-cart"><ShoppingBag size={42} strokeWidth={1.2} /><p>Nothing here yet.</p><span>Every wreath starts with a memory.</span><Link href="/matching" onClick={close}>Begin a memory →</Link></div> : items.map((item) => <div className="cart-item" key={item.id}>
          <div className={`cart-thumb ${item.type}`}><span>{item.type === "blueprint" ? "BP" : item.type === "bundle" ? "03" : "○"}</span></div>
          <div className="cart-copy"><h3>{item.name}</h3><p>{item.variant}</p><div className="quantity"><button onClick={() => updateQuantity(item.id, item.quantity - 1)} aria-label={`Decrease ${item.name}`}><Minus size={12} /></button><span>{item.quantity}</span><button onClick={() => updateQuantity(item.id, item.quantity + 1)} aria-label={`Increase ${item.name}`}><Plus size={12} /></button></div></div>
          <div className="cart-price"><strong>{money(item.price * item.quantity)}</strong><button onClick={() => remove(item.id)}>Remove</button></div>
        </div>)}
      </div>
      {!!items.length && <div className="drawer-foot"><div className="subtotal"><span>Subtotal</span><strong>{money(total)}</strong></div><p>{items.some((item) => item.type === "wreath") ? "Finished wreaths ship in numbered runs." : "Blueprint files are presented as an instant-download prototype."}</p><Link className="button button-olive checkout-button" href="/checkout" onClick={close}>Continue to checkout →</Link></div>}
    </aside>
  </>;
}

function Footer({ isOwner }: { isOwner: boolean }) {
  return <footer className="site-footer">
    <div className="shell-width footer-grid">
      <div><Link href="/" className="brand footer-brand"><img src="/manus-storage/moodoor-symbol_912ef462.png" alt="" className="brand-mark" /><span>Mood<span>oor</span></span></Link><p>A memory-led wreath library with the finished pieces and exact blueprints to carry a feeling home.</p></div>
      <div><p className="footer-label">The library</p><Link href="/wreaths">Signature wreaths</Link><Link href="/blueprints">Digital blueprints</Link><Link href="/bundles">Collection bundles</Link></div>
      <div><p className="footer-label">The studio</p><Link href="/territories">Emotional territories</Link><Link href="/drops">Seasonal drops</Link><Link href="/stories">Moodoor Stories</Link><Link href="/lookbook">Homepage Lookbook</Link><Link href="/ateliers">Atelier Locator</Link><Link href="/studio">The studio note</Link></div>
      <div><p className="footer-label">A note on this build</p><p className="footer-small">Shopping uses local browser storage. Checkout is a no-payment prototype until commerce infrastructure is connected.</p>{isOwner && <Link href="/admin" className="footer-admin-entry">Open Content Room →</Link>}</div>
    </div>
    <div className="shell-width footer-base"><span>© 2026 Moodoor</span><span>Blueprint-backed botanical keepsakes</span></div>
  </footer>;
}

---
name: evercrafted-web-builder
description: >
  Build high-end, cinematic, editorial-grade websites and pages for the Evercrafted SaaS
  wreath platform — including landing pages, marketing pages, feature pages, pricing pages,
  and dashboard UI. Use this skill whenever the user wants to build or improve any
  Evercrafted-facing web page, site section, or marketing surface. Trigger for requests
  like "build a landing page", "create the pricing page", "design the hero section",
  "make an Evercrafted marketing site", "build the Bloom tier page", "create a waitlist page",
  "design the subscription cards", "make a feature page for the blueprint engine", or any
  request to build a polished public-facing web page for Evercrafted. This skill produces
  magazine-worthy, animation-rich, production-grade HTML/CSS/JS or React — never generic
  SaaS templates. Always use this skill when a page needs to feel cinematic, editorial,
  or luxury-grade, even if the user just says "make it look amazing".
---

# Evercrafted Web Builder

Builds cinematic, editorial-grade marketing pages and UI for the Evercrafted wreath SaaS platform.

## Design Mandate

Every page must feel like it belongs in a high-end botanical editorial — think *Kinfolk* meets
modern SaaS. The aesthetic bar is: **would this page stop a designer mid-scroll?**

Three non-negotiable qualities in every output:
1. **Cinematic hero** — bold typographic statement, generous negative space, scroll-triggered reveal
2. **Editorial layout** — asymmetry, overlap, diagonal flow, not a grid of equal boxes
3. **Micro-interactions** — hover states, scroll animations, entrance reveals that feel intentional

---

## Brand System

Brand tokens are **blank slate by default** — accept from the user's brief. When no brand is
specified, ask before assuming. When building for Evercrafted specifically, load the full token
system from `references/brand-tokens.md`.

> **Read `references/brand-tokens.md`** when: user confirms this is an Evercrafted page,
> user says "use our brand", or context makes it obvious (wreath, Bloom/Craft/Studio/Atelier tiers).

---

## Output Format Decision

| Page Type | Preferred Format |
|-----------|-----------------|
| Landing / marketing page | Single-file HTML (CSS + JS inline) |
| Dashboard / app UI | React JSX (single component) |
| Feature or pricing page | Single-file HTML |
| Embeddable component | React JSX |

Use HTML for anything that will be viewed as a standalone page. Use React when the user
explicitly needs component architecture or interactivity with state.

---

## Component Library

This skill knows how to build the following sections — always offer the relevant ones based
on page type:

### Marketing / Landing Pages
- **Cinematic Hero** — full-viewport, bold serif headline, scroll-fade entrance, optional video bg or botanical SVG
- **Feature Marquee** — horizontal scroll strip of feature pills or icons
- **Editorial Feature Section** — alternating image+text with asymmetric layout, diagonal dividers
- **Social Proof / Testimonials** — magazine pull-quote style, author avatars, star ratings
- **Waitlist / Email Capture** — minimal centered form, urgency copy, animated CTA button
- **Stats Bar** — 3–4 key metrics, large serif numbers, subtle entrance animation

### Pricing Pages
- **Subscription Tier Cards** — Bloom / Craft / Studio / Atelier; highlight recommended tier;
  show locked features with upgrade CTAs (never hide features entirely)
- **Feature Comparison Table** — horizontal scroll on mobile, sticky header column, check/lock icons
- **FAQ Accordion** — smooth height animation, botanical divider between sections

### Dashboard / App UI
- **App Shell** — sidebar nav + main content area, on-brand header, tier badge
- **Metric Cards** — stat + label + trend indicator
- **Data Table** — sortable, paginated, zebra rows
- **Empty State** — botanical illustration, friendly copy, primary CTA

---

## Design Rules

### Typography
- Hero headline: serif, 64–96px, tight leading (1.1), letter-spacing -0.03em
- Section heading: serif, 36–48px, regular weight
- Decorative accent: script font, used sparingly (one per section max)
- Body: sans-serif, 16–18px, 1.65 leading
- Labels / overlines: sans-serif, 11–12px, 0.1em tracking, ALL CAPS

### Motion
- Page load: staggered entrance (opacity 0→1 + translateY 24px→0, 600ms ease-out)
- Scroll reveal: IntersectionObserver, trigger at 80% viewport, 400ms ease
- Hover on cards: translateY(-4px) + shadow deepening, 200ms ease
- CTA button: subtle scale(1.02) + glow on hover
- Never animate more than 3 elements simultaneously — choreograph, don't dump

### Layout
- Hero: min-height 90vh, centered or split layout
- Section padding: 120px vertical on desktop, 64px on mobile
- Max content width: 1200px, centered
- Use CSS Grid for editorial sections, Flexbox for components
- Overlap elements deliberately — cards over hero bottom edge, headings over images

### Visual Atmosphere
- Backgrounds: layered — base color + subtle noise texture (SVG filter) + optional gradient mesh
- Botanical SVG accents at section transitions (leaf, branch, wreath arc)
- No stock-photo placeholders — use CSS gradient shapes or SVG illustrations
- Shadows: soft and deep (0 24px 64px rgba(0,0,0,0.10)), not sharp drop shadows

---

## Build Process

1. **Confirm brief** — page type, brand input (or confirm Evercrafted defaults), key sections needed
2. **Load brand tokens** — from `references/brand-tokens.md` if Evercrafted, else define from brief
3. **Plan layout** — sketch section order in comments before writing HTML/CSS
4. **Build hero first** — establish the tone, then build sections beneath it
5. **Add motion last** — layer in animations after structure is solid
6. **Mobile check** — every section must be responsive; test at 375px, 768px, 1280px mentally
7. **Deliver** — single file (HTML) or JSX component, with inline comments on key sections

---

## Quality Checklist

Before delivering any page:
- [ ] Hero stops the scroll — bold, cinematic, memorable
- [ ] At least one editorial layout moment (asymmetry, overlap, or diagonal)
- [ ] Scroll-triggered entrance animations present
- [ ] Hover micro-interactions on all interactive elements
- [ ] Botanical or organic decorative accent used at least once
- [ ] Typography mixes serif display + sans body (+ optional script accent)
- [ ] Mobile responsive — no horizontal overflow
- [ ] No generic AI aesthetics — no purple gradients, no Inter+Roboto combos, no equal-column grids
- [ ] Brand tokens used via CSS variables, no raw hex values
- [ ] Waitlist/email forms are functional (or clearly marked as placeholder with TODO comment)
- [ ] Tier cards show Bloom / Craft / Studio / Atelier with locked feature handling

---

## Reference Files

| File | When to Read |
|------|-------------|
| `references/brand-tokens.md` | When building any Evercrafted-branded page |
| `references/section-patterns.md` | When needing detailed section code patterns |
| `references/tier-system.md` | When building pricing or subscription tier UI |

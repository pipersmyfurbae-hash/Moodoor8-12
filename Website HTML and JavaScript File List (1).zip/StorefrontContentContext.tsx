/**
 * MOODOOR / THE MEMORY ARCHIVE
 * Public content is loaded from the management backend and merged with the supplied catalog,
 * preserving a safe static fallback while the first editorial records are created.
 */
import { trpc } from "@/lib/trpc";
import { Wreath } from "@/lib/catalog";
import { attachLaunchState, PublicLaunchOperation } from "@/lib/launchState";
import { createContext, ReactNode, useContext, useMemo } from "react";

type ManagedPage = { contentKey: string; label: string; heading: string | null; body: string | null; imageUrl: string | null; imageKey: string | null; altText: string | null };
type ManagedProduct = { slug: string; name: string; territory: string; lede: string | null; description: string | null; price: string; blueprintCode: string | null; listingImageUrl: string | null; listingImageKey: string | null; heroImageUrl: string | null; heroImageKey: string | null; inventoryQuantity: number; runLimit: number; blueprintPrice: string; blueprintAssetUrl: string | null; blueprintAssetKey: string | null; blueprintFilename: string | null; blueprintMimeType: string | null; isPublished: boolean; sortOrder: number };
type ManagedBundleRow = { slug: string; name: string; territory: string; price: string; saving: string | null; lede: string | null; productSlugsJson: string | null; tone: "olive" | "amber" | "linen" | "ink" | "rose"; imageUrl: string | null; imageKey: string | null; isPublished: boolean; sortOrder: number };
type ManagedTerritoryRow = { slug: string; name: string; description: string | null; designCount: number; tone: "olive" | "amber" | "linen" | "ink" | "rose"; imageUrl: string | null; imageKey: string | null; isPublished: boolean; sortOrder: number };
type ManagedDropRow = { slug: string; title: string; timingLabel: string; status: "planned" | "next" | "live" | "archived"; lede: string | null; description: string | null; tagSlugsJson: string | null; finishedRunCount: number; blueprintCount: number; imageUrl: string | null; imageKey: string | null; launchAt: Date | null; isPublished: boolean; sortOrder: number };
export type ManagedWreath = Wreath & { listingImageUrl?: string | null; heroImageUrl?: string | null; inventoryQuantity: number; runLimit: number; blueprintPrice: number; blueprintAssetUrl?: string | null; blueprintFilename?: string | null };
export type ManagedBundle = { slug: string; name: string; territory: string; price: number; saving: string; lede: string; productSlugs: string[]; tone: "olive" | "amber" | "linen" | "ink" | "rose"; imageUrl?: string | null };
export type ManagedTerritory = { slug: string; name: string; description: string; designCount: number; tone: "olive" | "amber" | "linen" | "ink" | "rose"; imageUrl?: string | null };
export type ManagedDrop = { slug: string; title: string; timingLabel: string; status: "planned" | "next" | "live" | "archived"; lede: string; description: string; tagSlugs: string[]; finishedRunCount: number; blueprintCount: number; imageUrl?: string | null; launchAt: Date | null; launchState?: "planned" | "active" | "blocked" | "complete"; launchSummary?: string };

type StorefrontContentValue = { getPage: (key: string) => ManagedPage | undefined; mergeProduct: (product: Wreath) => ManagedWreath; mergeProducts: (products: Wreath[]) => ManagedWreath[]; managedBundles: ManagedBundle[]; managedTerritories: ManagedTerritory[]; managedDrops: ManagedDrop[]; loading: boolean };
const StorefrontContentContext = createContext<StorefrontContentValue | null>(null);

export function StorefrontContentProvider({ children }: { children: ReactNode }) {
  const { data, isLoading } = trpc.content.publicOverview.useQuery(undefined, { retry: false, staleTime: 60_000 });
  const value = useMemo<StorefrontContentValue>(() => {
    const pages = new Map((data?.siteContent ?? []).map((item) => [item.contentKey, item as ManagedPage]));
    const products = new Map((data?.products ?? []).map((item) => [item.slug, item as ManagedProduct]));
    const parseList = (value: string | null) => { try { const parsed = JSON.parse(value ?? "[]"); return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : []; } catch { return []; } };
    const mergeProduct = (product: Wreath): ManagedWreath => {
      const update = products.get(product.slug);
      if (!update) return { ...product, inventoryQuantity: product.runRemaining, runLimit: product.runTotal, blueprintPrice: 39, blueprintAssetUrl: null, blueprintFilename: null };
      const runLimit = update.runLimit || product.runTotal;
      const inventoryQuantity = update.inventoryQuantity;
      return { ...product, name: update.name, territory: update.territory, lede: update.lede ?? product.lede, description: update.description ?? product.description, price: Number(update.price), blueprintCode: update.blueprintCode ?? product.blueprintCode, runRemaining: Math.min(inventoryQuantity, runLimit), runTotal: runLimit, inventoryQuantity, runLimit, blueprintPrice: Number(update.blueprintPrice), blueprintAssetUrl: update.blueprintAssetUrl, blueprintFilename: update.blueprintFilename, listingImageUrl: update.listingImageUrl, heroImageUrl: update.heroImageUrl };
    };
    const mergeProducts = (items: Wreath[]) => {
      const merged = items.map(mergeProduct);
      const known = new Set(items.map((item) => item.slug));
      const custom = Array.from(products.values()).filter((item) => !known.has(item.slug)).map((item): ManagedWreath => ({
        slug: item.slug,
        name: item.name,
        territory: item.territory,
        lede: item.lede || "A Moodoor composition, held in a new form.",
        description: item.description || "A new botanical design prepared in the Moodoor content library.",
        price: Number(item.price),
        blueprintCode: item.blueprintCode || "BP-MOODOOR",
        runRemaining: Math.min(item.inventoryQuantity, item.runLimit),
        runTotal: item.runLimit,
        base: '18" exposed grapevine',
        focal: "A considered focal movement",
        space: "A protected open arc",
        stems: 24,
        score: "In review",
        story: "This product’s editorial story can be expanded in the storefront source once its final design is resolved.",
        quote: "A new Moodoor design.",
        palette: "olive",
        profile: [["Warmth", 68], ["Nostalgia", 62], ["Restraint", 70], ["Intimacy", 64], ["Energy", 43]],
        listingImageUrl: item.listingImageUrl,
        heroImageUrl: item.heroImageUrl,
        inventoryQuantity: item.inventoryQuantity,
        runLimit: item.runLimit,
        blueprintPrice: Number(item.blueprintPrice),
        blueprintAssetUrl: item.blueprintAssetUrl,
        blueprintFilename: item.blueprintFilename,
      }));
      return [...merged, ...custom];
    };
    const managedBundles = (data?.bundles ?? []).map((item) => { const row = item as ManagedBundleRow; return { slug: row.slug, name: row.name, territory: row.territory, price: Number(row.price), saving: row.saving ?? "", lede: row.lede ?? "", productSlugs: parseList(row.productSlugsJson), tone: row.tone, imageUrl: row.imageUrl }; });
    const managedTerritories = (data?.territories ?? []).map((item) => { const row = item as ManagedTerritoryRow; return { slug: row.slug, name: row.name, description: row.description ?? "", designCount: row.designCount, tone: row.tone, imageUrl: row.imageUrl }; });
    const dropRows = (data?.drops ?? []).map((item) => { const row = item as ManagedDropRow; return { slug: row.slug, title: row.title, timingLabel: row.timingLabel, status: row.status, lede: row.lede ?? "", description: row.description ?? "", tagSlugs: parseList(row.tagSlugsJson), finishedRunCount: row.finishedRunCount, blueprintCount: row.blueprintCount, imageUrl: row.imageUrl, launchAt: row.launchAt }; });
    const managedDrops = attachLaunchState(dropRows, (data?.launchOperations ?? []) as PublicLaunchOperation[]);
    return { getPage: (key) => pages.get(key), mergeProduct, mergeProducts, managedBundles, managedTerritories, managedDrops, loading: isLoading };
  }, [data, isLoading]);
  return <StorefrontContentContext.Provider value={value}>{children}</StorefrontContentContext.Provider>;
}

export function useStorefrontContent() {
  const context = useContext(StorefrontContentContext);
  if (!context) throw new Error("useStorefrontContent must be used inside StorefrontContentProvider");
  return context;
}

/**
 * MOODOOR / THE MEMORY ARCHIVE
 * Catalog source adapted from the supplied storefront files. The data is intentionally
 * editorial: territory, story, construction notes, and product details remain connected.
 */

export type Wreath = {
  slug: string;
  name: string;
  territory: string;
  lede: string;
  description: string;
  price: number;
  blueprintCode: string;
  runRemaining: number;
  runTotal: number;
  base: string;
  focal: string;
  space: string;
  stems: number;
  score: string;
  story: string;
  quote: string;
  palette: "olive" | "amber" | "linen" | "ink" | "rose";
  profile: Array<[string, number]>;
};

export const wreaths: Wreath[] = [
  {
    slug: "september-porch",
    name: "September Porch",
    territory: "Seasonal Nostalgia",
    lede: "Cedar, cold coffee, the screen door.",
    description: "An exposed grapevine base with asymmetric autumn clusters, amber pips, and deep cedar sweeps. The open interval is part of the composition, never an omission.",
    price: 345,
    blueprintCode: "BP-EC-0417 · v2",
    runRemaining: 2,
    runTotal: 5,
    base: '18" exposed grapevine',
    focal: "10:30 · focal dahlia ×3",
    space: "1:00 – 3:30 preserved",
    stems: 23,
    score: "104 / 120",
    quote: "My grandmother's porch in late September — cedar, cold coffee, and the screen door that never quite closed.",
    story: "A time-soaked autumn memory becomes a low, quiet composition. Amber accents mark its warmth, while the deliberate unfilled arc gives the wreath room to breathe.",
    palette: "amber",
    profile: [["Nostalgia", 91], ["Warmth", 82], ["Seasonal", 88], ["Intimacy", 71], ["Restraint", 64]],
  },
  {
    slug: "cider-house",
    name: "Cider House",
    territory: "Seasonal Nostalgia",
    lede: "Amber pips and warm spice tones.",
    description: "A fuller, spice-warm take on the season: pressed apples, woodsmoke, and a kitchen that ran hot all October.",
    price: 365,
    blueprintCode: "BP-EC-0419 · v1",
    runRemaining: 4,
    runTotal: 5,
    base: '18" exposed grapevine',
    focal: "1:30 · spiced focal ×3",
    space: "4:00 – 5:30 preserved",
    stems: 26,
    score: "98 / 120",
    quote: "The whole house smelled like apples and woodsmoke. You could feel October before you opened the door.",
    story: "Cider House carries more mass than its seasonal neighbour. Its composition keeps a bright amber lead and a generous grapevine frame for a memory of warmth that filled a whole room.",
    palette: "amber",
    profile: [["Warmth", 90], ["Nostalgia", 84], ["Seasonal", 86], ["Valence", 74], ["Restraint", 41]],
  },
  {
    slug: "linen-cedar",
    name: "Linen & Cedar",
    territory: "Comfort",
    lede: "Low contrast, soft texture, home.",
    description: "The quietest design in the library: muted whites, soft cedar, and an ordinary safe afternoon held in a circular form.",
    price: 295,
    blueprintCode: "BP-EC-0402 · v3",
    runRemaining: 5,
    runTotal: 5,
    base: '16" exposed grapevine',
    focal: "7:30 · soft focal ×3",
    space: "2:00 – 4:00 preserved",
    stems: 21,
    score: "101 / 120",
    quote: "Nothing happened that day. That's exactly why I keep it.",
    story: "Linen & Cedar comes from a memory with almost no event in it: a soft afternoon, line-dried sheets, and a cedar closet. It is composed for safety rather than spectacle.",
    palette: "linen",
    profile: [["Comfort", 92], ["Warmth", 80], ["Intimacy", 74], ["Restraint", 78], ["Energy", 24]],
  },
  {
    slug: "quiet-hearth",
    name: "Quiet Hearth",
    territory: "Comfort",
    lede: "Bottom-weighted, settled, warm.",
    description: "Weight sits low and central: warm neutrals, one grounded focal, and a greenery sweep that never lifts far.",
    price: 315,
    blueprintCode: "BP-EC-0404 · v2",
    runRemaining: 3,
    runTotal: 5,
    base: '18" exposed grapevine',
    focal: "6:00 · grounded focal ×3",
    space: "1:00 – 2:30 preserved",
    stems: 22,
    score: "99 / 120",
    quote: "The fire was always going. You'd fall asleep in the chair and nobody woke you.",
    story: "The low center of gravity makes Quiet Hearth read as settled. Its story is warmth and permission to rest, translated into a full lower arc and a small counterweight of light.",
    palette: "olive",
    profile: [["Comfort", 88], ["Warmth", 85], ["Intimacy", 70], ["Restraint", 69], ["Energy", 30]],
  },
  {
    slug: "first-light",
    name: "First Light",
    territory: "Celebration",
    lede: "Lifted, bright, arriving.",
    description: "A design for beginnings: higher contrast, a bright lead bloom, and a greenery line that rises just beyond the frame.",
    price: 335,
    blueprintCode: "BP-EC-0408 · v1",
    runRemaining: 5,
    runTotal: 5,
    base: '18" exposed grapevine',
    focal: "11:00 · bright focal ×3",
    space: "2:30 – 4:30 preserved",
    stems: 24,
    score: "96 / 120",
    quote: "We stood in the parking lot at sunrise and just knew everything was about to change.",
    story: "First Light scores for forward movement rather than nostalgia. Its green line travels out and up, allowing the eye to follow a beginning as it opens.",
    palette: "rose",
    profile: [["Celebration", 90], ["Valence", 87], ["Energy", 76], ["Warmth", 72], ["Restraint", 30]],
  },
  {
    slug: "the-long-table",
    name: "The Long Table",
    territory: "Connection",
    lede: "Full chairs, late plates, the people who stayed.",
    description: "A paired-cluster composition that gives each side a voice. Soft olive bridges the distance between them.",
    price: 325,
    blueprintCode: "BP-EC-0411 · v1",
    runRemaining: 4,
    runTotal: 5,
    base: '18" exposed grapevine',
    focal: "8:00 + 2:00 · paired focal",
    space: "12:00 – 1:00 preserved",
    stems: 25,
    score: "97 / 120",
    quote: "No one left when the plates were cleared.",
    story: "The Long Table uses two distinct clusters rather than a single central event. Its composition stays balanced through a line of olive, making space for a gathering that kept expanding.",
    palette: "olive",
    profile: [["Connection", 91], ["Warmth", 79], ["Energy", 66], ["Intimacy", 62], ["Nostalgia", 58]],
  },
  {
    slug: "legacy-garden",
    name: "Legacy Garden",
    territory: "Remembrance",
    lede: "What she grew, kept growing.",
    description: "A restrained wreath for honouring rather than decorating, with deliberate negative space and a botanical line that asks for patience.",
    price: 355,
    blueprintCode: "BP-EC-0422 · v1",
    runRemaining: 2,
    runTotal: 5,
    base: '18" exposed grapevine',
    focal: "9:00 · garden focal ×3",
    space: "12:30 – 3:00 preserved",
    stems: 20,
    score: "106 / 120",
    quote: "Her garden is gone, but I know what it felt like to walk through it.",
    story: "Legacy Garden is constructed with one quiet focal movement and generous opening. The restraint is purposeful: a design that honours a person without trying to fill the space they left.",
    palette: "ink",
    profile: [["Remembrance", 94], ["Intimacy", 83], ["Nostalgia", 86], ["Restraint", 88], ["Energy", 18]],
  },
  {
    slug: "white-hour",
    name: "White Hour",
    territory: "Renewal",
    lede: "Rain lifted; everything began again.",
    description: "Pale stems and a light, open rhythm hold the first clear hour after a long weather system moves through.",
    price: 305,
    blueprintCode: "BP-EC-0425 · v2",
    runRemaining: 5,
    runTotal: 5,
    base: '16" exposed grapevine',
    focal: "10:00 · pale focal ×2",
    space: "4:30 – 7:00 preserved",
    stems: 19,
    score: "100 / 120",
    quote: "The rain stopped and the whole house changed colour.",
    story: "White Hour makes the wreath feel almost weightless. Pale flowers hold a lifted arc while the lower portion of the vine is allowed to remain quietly visible.",
    palette: "linen",
    profile: [["Renewal", 91], ["Valence", 80], ["Restraint", 73], ["Warmth", 61], ["Energy", 47]],
  },
];

export const territories = [
  ["Comfort", "Soft texture, warm neutrals, low contrast. The feeling of a familiar room.", "14 designs", "linen"],
  ["Celebration", "Lifted energy and bright focal hierarchy for arrivals, milestones, and good news.", "9 designs", "rose"],
  ["Remembrance", "Restrained, honouring compositions for a person, place, or season that remains.", "11 designs", "ink"],
  ["Renewal", "Open movement, pale structure, and the feeling of a weather system breaking.", "8 designs", "olive"],
  ["Connection", "Paired shapes and linked rhythms for shared stories and full rooms.", "10 designs", "olive"],
  ["Seasonal Nostalgia", "Specific months you can smell, hear, and recognise before you enter the room.", "8 designs", "amber"],
] as const;

export const bundles = [
  { slug: "autumn-memories", name: "Autumn Memories", territory: "Seasonal Nostalgia", price: 129, saving: "Save $27 vs. single", lede: "The whole season, front door to mantel to table.", designs: ["September Porch", "Cider House", "Last Bonfire"], tone: "amber" },
  { slug: "gathered-grace", name: "Gathered Grace", territory: "Celebration & Connection", price: 119, saving: "Save $25 vs. single", lede: "For the house where everyone ends up.", designs: ["Gathered Grace", "First Light", "The Long Table"], tone: "olive" },
  { slug: "legacy-garden-set", name: "Legacy Garden", territory: "Remembrance", price: 149, saving: "Save $31 vs. single", lede: "What she grew, kept growing.", designs: ["Legacy Garden", "White Hour", "Kept Letters"], tone: "ink" },
];

export const money = (value: number) => `$${value.toLocaleString("en-US")}`;


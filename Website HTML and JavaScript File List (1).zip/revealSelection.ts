export type RevealCandidate = { inventoryQuantity: number; runLimit: number; heroImageUrl?: string | null; listingImageUrl?: string | null };
export type RevealDrop = { status: "planned" | "next" | "live" | "archived" };

/** Returns only a real, available catalog render; no placeholder product is ever substituted. */
export function selectRevealProduct<T extends RevealCandidate>(products: T[]): T | null {
  return products.find((product) => product.inventoryQuantity > 0 && (product.heroImageUrl || product.listingImageUrl)) ?? null;
}

export function selectRevealDrop<T extends RevealDrop>(drops: T[]): T | null {
  return drops.find((drop) => drop.status === "live") ?? drops.find((drop) => drop.status === "next") ?? null;
}

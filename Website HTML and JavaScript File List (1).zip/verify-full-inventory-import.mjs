import { readFile } from "node:fs/promises";
import { parseInventoryImport } from "../server/routers.ts";

const sourceText = await readFile("/home/ubuntu/moodoor-complete-archive/moodoor-inventory.json", "utf8");
const rows = parseInventoryImport(sourceText, "json");
console.log(JSON.stringify({ importedRows: rows.length, first: rows[0], last: rows.at(-1) }, null, 2));

ALTER TABLE `moodoor_inventory_items` MODIFY COLUMN `wheelSector` text;--> statement-breakpoint
ALTER TABLE `moodoor_inventory_items` MODIFY COLUMN `textureArchetype` text;
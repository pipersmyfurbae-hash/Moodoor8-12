import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  getAdminContentOverview: vi.fn(), getPublicContentOverview: vi.fn(), getStudioConceptBySlug: vi.fn(), getStudioConcepts: vi.fn(), removeBundle: vi.fn(), removeCatalogProduct: vi.fn(), removeDrop: vi.fn(), removeTerritory: vi.fn(), saveBundle: vi.fn(), saveCatalogProduct: vi.fn(), saveDrop: vi.fn(), saveSiteContent: vi.fn(), saveStudioConcept: vi.fn(), saveTerritory: vi.fn(), storagePut: vi.fn(), generateImage: vi.fn(),
}));

vi.mock("./db", () => mocks);
vi.mock("./storage", () => ({ storagePut: mocks.storagePut }));
vi.mock("./_core/imageGeneration", () => ({ generateImage: mocks.generateImage }));

import { appRouter } from "./routers";

const baseConcept = {
  id: 1, slug: "autumn-parlor", name: "Autumn Parlor", memory: "A quiet room in October", territory: "Nostalgia", palette: "olive, parchment, cinnamon", focalFlorals: "dahlia, hydrangea", foliage: "cedar, eucalyptus", styleNotes: "asymmetrical with a silence arc", renderPrompt: "Compiled Moodoor Studio prompt", renderUrl: "/manus-storage/studio.png", renderKey: null, renderAlt: "Autumn Parlor studio-rendered botanical wreath", status: "ready", generationError: null, reviewNotes: null, productSlug: null, createdBy: 7, updatedBy: 7, publishedAt: null, createdAt: new Date(), updatedAt: new Date(),
} as const;

function adminContext(): TrpcContext {
  return { user: { id: 7, openId: "moodoor-owner", email: "owner@example.com", name: "Owner", loginMethod: "manus", role: "admin", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("Studio owner success paths", () => {
  it("saves a structured concept with a compiled render prompt", async () => {
    mocks.saveStudioConcept.mockResolvedValue(undefined);
    const caller = appRouter.createCaller(adminContext());
    await expect(caller.studio.create({ slug: "autumn-parlor", name: "Autumn Parlor", memory: "A quiet room in October", territory: "Nostalgia", palette: "olive, parchment", focalFlorals: "dahlia", foliage: "cedar", styleNotes: "asymmetric" })).resolves.toMatchObject({ success: true, slug: "autumn-parlor" });
    expect(mocks.saveStudioConcept).toHaveBeenCalledWith(expect.objectContaining({ status: "draft", createdBy: 7, renderPrompt: expect.stringContaining("Luxury handcrafted faux botanical grapevine wreath") }));
  });

  it("generates and approves a managed Studio render", async () => {
    mocks.getStudioConceptBySlug.mockResolvedValue({ ...baseConcept, renderUrl: null, status: "draft" });
    mocks.saveStudioConcept.mockResolvedValue(undefined);
    mocks.generateImage.mockResolvedValue({ url: "/manus-storage/generated-studio.png" });
    const caller = appRouter.createCaller(adminContext());
    await expect(caller.studio.generate({ slug: "autumn-parlor" })).resolves.toMatchObject({ success: true, url: "/manus-storage/generated-studio.png" });
    expect(mocks.saveStudioConcept).toHaveBeenCalledWith(expect.objectContaining({ status: "generating" }));
    expect(mocks.saveStudioConcept).toHaveBeenCalledWith(expect.objectContaining({ status: "ready", renderUrl: "/manus-storage/generated-studio.png" }));
    mocks.getStudioConceptBySlug.mockResolvedValue(baseConcept);
    await expect(caller.studio.review({ slug: "autumn-parlor", reviewNotes: "Use as hero", approve: true })).resolves.toEqual({ success: true });
    expect(mocks.saveStudioConcept).toHaveBeenLastCalledWith(expect.objectContaining({ status: "approved", reviewNotes: "Use as hero" }));
  });

  it("publishes an approved render into an editable storefront product", async () => {
    mocks.getStudioConceptBySlug.mockResolvedValue({ ...baseConcept, status: "approved" });
    mocks.saveCatalogProduct.mockResolvedValue(undefined); mocks.saveStudioConcept.mockResolvedValue(undefined);
    const caller = appRouter.createCaller(adminContext());
    await expect(caller.studio.publish({ slug: "autumn-parlor", price: 345, inventoryQuantity: 5, runLimit: 12, blueprintPrice: 39, isPublished: true, sortOrder: 4 })).resolves.toEqual({ success: true, productSlug: "autumn-parlor" });
    expect(mocks.saveCatalogProduct).toHaveBeenCalledWith(expect.objectContaining({ slug: "autumn-parlor", listingImageUrl: "/manus-storage/studio.png", heroImageUrl: "/manus-storage/studio.png", inventoryQuantity: 5, runLimit: 12, isPublished: true }));
    expect(mocks.saveStudioConcept).toHaveBeenLastCalledWith(expect.objectContaining({ status: "published", productSlug: "autumn-parlor", publishedAt: expect.any(Date) }));
  });
});

import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { randomUUID } from "crypto";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { getAdminContentOverview, getMoodoorBriefBySlug, getMoodoorInventory, getMoodoorInventoryBySku, getMoodoorStoryBySlug, getMoodoorWorkspaceOverview, getPublicContentOverview, getPublishedMoodoorStories, getStudioConceptBySlug, getStudioConcepts, removeBundle, removeCatalogProduct, removeDrop, removeMoodoorBrief, removeMoodoorInventoryItem, removeMoodoorOperation, removeMoodoorQualityCheck, removeMoodoorStory, removeTerritory, saveBundle, saveCatalogProduct, saveDrop, saveMoodoorBrief, saveMoodoorInventoryItem, saveMoodoorOperation, saveMoodoorQualityCheck, saveMoodoorStory, saveSiteContent, saveStudioConcept, saveTerritory } from "./db";
import { generateImage } from "./_core/imageGeneration";
import { storagePut } from "./storage";

const textField = z.string().trim().max(12_000).nullable();
const urlField = z.string().trim().max(1_000).nullable();
const slugField = z.string().trim().min(2).max(100).regex(/^[a-z0-9-]+$/);
const toneField = z.enum(["olive", "amber", "linen", "ink", "rose"]);
const contentInput = z.object({ contentKey: slugField, label: z.string().trim().min(2).max(160), heading: textField, body: textField, imageUrl: urlField, imageKey: urlField, altText: textField });
const productInput = z.object({
  slug: slugField, name: z.string().trim().min(2).max(180), territory: z.string().trim().min(2).max(120), lede: textField, description: textField, price: z.coerce.number().min(0).max(100_000), blueprintCode: z.string().trim().max(120).nullable(), listingImageUrl: urlField, listingImageKey: urlField, heroImageUrl: urlField, heroImageKey: urlField,
  inventoryQuantity: z.coerce.number().int().min(0).max(100_000), runLimit: z.coerce.number().int().min(0).max(100_000), blueprintPrice: z.coerce.number().min(0).max(10_000), blueprintAssetUrl: urlField, blueprintAssetKey: urlField, blueprintFilename: z.string().trim().max(180).nullable(), blueprintMimeType: z.string().trim().max(100).nullable(), isPublished: z.boolean(), sortOrder: z.coerce.number().int().min(0).max(9_999),
});
const bundleInput = z.object({ slug: slugField, name: z.string().trim().min(2).max(180), territory: z.string().trim().min(2).max(140), price: z.coerce.number().min(0).max(100_000), saving: z.string().trim().max(180).nullable(), lede: textField, productSlugs: z.array(z.string().trim().min(1).max(100)).max(24), tone: toneField, imageUrl: urlField, imageKey: urlField, isPublished: z.boolean(), sortOrder: z.coerce.number().int().min(0).max(9_999) });
const territoryInput = z.object({ slug: slugField, name: z.string().trim().min(2).max(140), description: textField, designCount: z.coerce.number().int().min(0).max(10_000), tone: toneField, imageUrl: urlField, imageKey: urlField, isPublished: z.boolean(), sortOrder: z.coerce.number().int().min(0).max(9_999) });
const dropInput = z.object({ slug: slugField, title: z.string().trim().min(2).max(180), timingLabel: z.string().trim().min(2).max(140), status: z.enum(["planned", "next", "live", "archived"]), lede: textField, description: textField, tagSlugs: z.array(z.string().trim().min(1).max(100)).max(30), finishedRunCount: z.coerce.number().int().min(0).max(10_000), blueprintCount: z.coerce.number().int().min(0).max(10_000), imageUrl: urlField, imageKey: urlField, launchAt: z.date().nullable(), isPublished: z.boolean(), sortOrder: z.coerce.number().int().min(0).max(9_999) });
const imageUploadInput = z.object({ dataUrl: z.string().min(32).max(7_200_000), filename: z.string().trim().min(1).max(160) });
const blueprintUploadInput = z.object({ dataUrl: z.string().min(32).max(20_500_000), filename: z.string().trim().min(1).max(180) });
const studioConceptInput = z.object({ slug: slugField, name: z.string().trim().min(2).max(180), memory: z.string().trim().max(1_200).nullable(), territory: z.string().trim().min(2).max(120), palette: z.string().trim().max(180).nullable(), focalFlorals: z.string().trim().max(1_000).nullable(), foliage: z.string().trim().max(1_000).nullable(), styleNotes: z.string().trim().max(1_600).nullable() });
const studioReviewInput = z.object({ slug: slugField, reviewNotes: z.string().trim().max(2_000).nullable(), approve: z.boolean() });
const studioPublishInput = z.object({ slug: slugField, price: z.coerce.number().min(0).max(100_000), inventoryQuantity: z.coerce.number().int().min(0).max(100_000), runLimit: z.coerce.number().int().min(0).max(100_000), blueprintPrice: z.coerce.number().min(0).max(10_000), isPublished: z.boolean(), sortOrder: z.coerce.number().int().min(0).max(9_999) });
const moodoorBriefInput = z.object({ slug: slugField, title: z.string().trim().min(2).max(180), sourceMemory: z.string().trim().max(2_000).nullable(), season: z.string().trim().max(120).nullable(), territory: z.string().trim().min(2).max(120), collectionName: z.string().trim().max(180).nullable(), palette: z.string().trim().max(180).nullable(), materials: z.string().trim().max(2_000).nullable(), collectionInsight: z.string().trim().max(8_000).nullable(), collectionPlan: z.string().trim().max(8_000).nullable(), status: z.enum(["draft", "analyzed", "approved", "archived"]) });
const moodoorStoryInput = z.object({ slug: slugField, kind: z.enum(["lifestyle", "studio", "genesis", "story", "lookbook"]), title: z.string().trim().min(2).max(180), eyebrow: z.string().trim().max(180).nullable(), excerpt: z.string().trim().max(2_000).nullable(), body: z.string().trim().max(12_000).nullable(), imageUrl: urlField, imageKey: urlField, linkedProductSlug: z.string().trim().max(100).nullable(), linkedDropSlug: z.string().trim().max(100).nullable(), isPublished: z.boolean(), sortOrder: z.coerce.number().int().min(0).max(9_999) });
const moodoorQualityInput = z.object({ slug: slugField, title: z.string().trim().min(2).max(180), studioConceptSlug: z.string().trim().max(100).nullable(), productSlug: z.string().trim().max(100).nullable(), status: z.enum(["queued", "in_review", "passed", "needs_revision"]), compositionScore: z.coerce.number().int().min(0).max(100), materialScore: z.coerce.number().int().min(0).max(100), commerceScore: z.coerce.number().int().min(0).max(100), notes: z.string().trim().max(5_000).nullable(), reviewedBy: z.string().trim().max(180).nullable() });
const moodoorOperationInput = z.object({ slug: slugField, title: z.string().trim().min(2).max(180), module: z.enum(["operator", "pipeline", "experience", "drop"]), status: z.enum(["planned", "active", "blocked", "complete"]), summary: z.string().trim().max(5_000).nullable(), ownerNote: z.string().trim().max(5_000).nullable(), linkedBriefSlug: z.string().trim().max(100).nullable(), linkedStorySlug: z.string().trim().max(100).nullable(), linkedProductSlug: z.string().trim().max(100).nullable(), linkedDropSlug: z.string().trim().max(100).nullable(), dueAt: z.date().nullable() });
const collectionEngineInput = z.object({ briefSlug: slugField, price: z.coerce.number().min(0).max(100_000), productSlugs: z.array(z.string().trim().min(1).max(100)).max(24), launchDropSlug: z.string().trim().max(100).nullable(), isPublished: z.boolean(), sortOrder: z.coerce.number().int().min(0).max(9_999) });
const launchDropInput = z.object({ slug: slugField, title: z.string().trim().min(2).max(180), timingLabel: z.string().trim().min(2).max(140), status: z.enum(["planned", "next", "live", "archived"]), lede: z.string().trim().max(2_000).nullable(), description: z.string().trim().max(8_000).nullable(), tagSlugs: z.array(z.string().trim().min(1).max(100)).max(30), finishedRunCount: z.coerce.number().int().min(0).max(10_000), blueprintCount: z.coerce.number().int().min(0).max(10_000), isPublished: z.boolean(), sortOrder: z.coerce.number().int().min(0).max(9_999), linkedBriefSlug: z.string().trim().max(100).nullable() });
const experienceInput = z.object({ slug: slugField, title: z.string().trim().min(2).max(180), summary: z.string().trim().max(5_000).nullable(), storySlug: z.string().trim().max(100).nullable(), productSlug: z.string().trim().max(100).nullable(), dropSlug: z.string().trim().max(100).nullable(), status: z.enum(["planned", "active", "blocked", "complete"]) });
const blueprintStoryInput = z.object({ blueprintJson: z.string().trim().min(2).max(50_000) });
const inventoryImportInput = z.object({ sourceText: z.string().trim().min(2).max(2_500_000), format: z.enum(["json", "csv"]) });
const inventoryQuantityInput = z.object({ sku: z.string().trim().min(1).max(120), qtyOnHand: z.coerce.number().int().min(0).max(1_000_000), lowStockThreshold: z.coerce.number().int().min(0).max(100_000), notes: z.string().trim().max(2_000).nullable() });

/** Validates the image header as well as its declared MIME type before object storage receives it. */
export function decodeImageData(dataUrl: string) {
  const match = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/i.exec(dataUrl);
  if (!match) throw new Error("Please upload a JPEG, PNG, WebP, or GIF image.");
  const mimeType = match[1].toLowerCase();
  const bytes = Buffer.from(match[2], "base64");
  if (bytes.length === 0 || bytes.length > 5 * 1024 * 1024) throw new Error("Images must be between 1 byte and 5 MB.");
  const valid = (mimeType === "image/jpeg" && bytes.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]))) || (mimeType === "image/png" && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) || (mimeType === "image/gif" && bytes.subarray(0, 4).toString("ascii") === "GIF8") || (mimeType === "image/webp" && bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP");
  if (!valid) throw new Error("The selected file does not match its declared image format.");
  return { bytes, mimeType, extension: mimeType === "image/jpeg" ? "jpg" : mimeType.split("/")[1] };
}

/** Blueprint documents are restricted to PDFs and checked by magic header before object storage receives them. */
export function decodeBlueprintData(dataUrl: string) {
  const match = /^data:application\/pdf;base64,([A-Za-z0-9+/=]+)$/i.exec(dataUrl);
  if (!match) throw new Error("Please upload a PDF blueprint document.");
  const bytes = Buffer.from(match[1], "base64");
  if (bytes.length === 0 || bytes.length > 15 * 1024 * 1024) throw new Error("Blueprint PDFs must be between 1 byte and 15 MB.");
  if (bytes.subarray(0, 5).toString("ascii") !== "%PDF-") throw new Error("The selected file does not match the declared PDF format.");
  return { bytes, mimeType: "application/pdf" };
}

/**
 * Distills the supplied Moodoor Studio’s prompt conventions into a safe, repeatable
 * product-render brief for the internal image service. It intentionally preserves
 * the signature asymmetric grapevine, negative-space, editorial-product language.
 */
export function compileStudioRenderPrompt(input: z.infer<typeof studioConceptInput>) {
  const parts = [
    "Luxury handcrafted faux botanical grapevine wreath, straight-on hero product photograph",
    `named ${input.name}`,
    input.focalFlorals ? `focal florals: ${input.focalFlorals}` : "focal florals with quiet seasonal texture",
    input.foliage ? `foliage: ${input.foliage}` : "layered cedar, eucalyptus, and restrained foliage",
    input.palette ? `locked palette: ${input.palette}` : "warm olive, parchment, muted cinnamon, and natural brown",
    input.styleNotes ? `design direction: ${input.styleNotes}` : "asymmetrical composition with an intentional silence arc",
    input.memory ? `emotional reference: ${input.memory}` : "a memory-led feeling of intimacy and nostalgia",
    "visible individual stems at organic angles, dimensional front-to-back layering, intentionally bare right-side grapevine arc",
    "pale warm grey textured plaster wall, soft daylight from upper left, refined editorial home decor photography, one complete wreath centered in frame",
    "no people, no text, no typography, no hands, no ribbon unless explicitly specified, no perfect symmetry, no artificial plastic sheen",
  ];
  return parts.filter(Boolean).join(", ");
}

function conceptPayload(concept: Awaited<ReturnType<typeof getStudioConceptBySlug>>, patch: Record<string, unknown>, updatedBy: number) {
  if (!concept) throw new TRPCError({ code: "NOT_FOUND", message: "Studio concept not found." });
  return {
    slug: concept.slug, name: concept.name, memory: concept.memory, territory: concept.territory, palette: concept.palette, focalFlorals: concept.focalFlorals, foliage: concept.foliage, styleNotes: concept.styleNotes, renderPrompt: concept.renderPrompt, renderUrl: concept.renderUrl, renderKey: concept.renderKey, renderAlt: concept.renderAlt, status: concept.status, generationError: concept.generationError, reviewNotes: concept.reviewNotes, productSlug: concept.productSlug, createdBy: concept.createdBy, updatedBy, publishedAt: concept.publishedAt,
    ...patch,
  } as Parameters<typeof saveStudioConcept>[0];
}

/** Structured, operator-visible collection intelligence derived from the source brief fields. */
export function compileCollectionIntelligence(input: z.infer<typeof moodoorBriefInput>) {
  const collectionName = input.collectionName || input.title;
  const feeling = input.sourceMemory || `a ${input.territory.toLowerCase()} collection moment`;
  const materials = input.materials || "a restrained seasonal mix of focal blooms, supportive flowers, and dimensional foliage";
  const palette = input.palette || "Moodoor olive, parchment, and an accent drawn from the season";
  return {
    insight: `${collectionName} translates ${feeling} into a ${input.territory.toLowerCase()} collection for ${input.season || "the current season"}. The palette holds ${palette}. Material direction: ${materials}.`,
    plan: `1. Hero wreath — the emotional anchor.\n2. Companion wreath — a quieter variation for layering.\n3. Blueprint edition — the exact build documentation.\n4. Lifestyle story — a memory-led editorial field note.\n5. Drop sequence — announce, preview, release, and archive the collection with a clear inventory handoff.`,
  };
}

/** A source-informed, deterministic Story Genesis fallback that keeps the Moodoor editorial voice available without exposing third-party model credentials. */
export function compileStoryGenesis(input: { title: string; eyebrow: string | null; excerpt: string | null; body: string | null; kind: string }) {
  const seed = (input.excerpt || input.body || input.title).trim();
  const sensory = seed || "a feeling that stays at the threshold";
  const title = input.title || "A Threshold Note";
  const opening = `It begins where the memory does — ${sensory.charAt(0).toLowerCase() + sensory.slice(1)}.`;
  const body = `What it carries is not decoration, but atmosphere: a composition held with enough restraint to leave room for the person arriving home. Each material is placed to make the threshold feel inhabited before anyone knocks.`;
  const closing = `The finished form holds at the door as a small, exact signal. The open arc is not absence; it is the part of the story that remains yours.`;
  return { title, excerpt: input.excerpt || opening, body: `${opening}\n\n${body}\n\n${closing}`, eyebrow: input.eyebrow || `Moodoor ${input.kind === "lookbook" ? "Lookbook" : "Stories"}` };
}

type BlueprintRecord = Record<string, unknown>;
function isBlueprintRecord(value: unknown): value is BlueprintRecord { return typeof value === "object" && value !== null && !Array.isArray(value); }
function blueprintText(value: unknown): string | null {
  if (typeof value === "string") return value.trim() || null;
  if (typeof value === "number") return String(value);
  if (Array.isArray(value)) return value.map(blueprintText).filter((item): item is string => Boolean(item)).join(", ") || null;
  if (isBlueprintRecord(value)) return Object.values(value).map(blueprintText).filter((item): item is string => Boolean(item)).join(", ") || null;
  return null;
}
function pickBlueprintField(blueprint: BlueprintRecord, fields: string[]) {
  for (const field of fields) { const value = blueprintText(blueprint[field]); if (value) return value; }
  return null;
}
function blueprintSlug(value: string) { return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 100); }

/**
 * Accepts flexible studio, product, or manual blueprint JSON. Common title, story,
 * palette, material, structure, product, and drop keys are gathered into one editorial draft.
 */
export function compileBlueprintStory(blueprintJson: string) {
  let parsed: unknown;
  try { parsed = JSON.parse(blueprintJson); } catch { throw new TRPCError({ code: "BAD_REQUEST", message: "The blueprint must be valid JSON. Check commas, quotation marks, and braces." }); }
  if (!isBlueprintRecord(parsed)) throw new TRPCError({ code: "BAD_REQUEST", message: "The blueprint JSON must be a single object, not a list or plain value." });
  const title = pickBlueprintField(parsed, ["title", "name", "blueprintTitle", "designName", "wreathName"]);
  if (!title) throw new TRPCError({ code: "BAD_REQUEST", message: "Add a title, name, blueprintTitle, designName, or wreathName field to create the story." });
  const slug = blueprintSlug(pickBlueprintField(parsed, ["slug", "blueprintSlug", "id", "blueprintId"]) || title);
  if (!slug) throw new TRPCError({ code: "BAD_REQUEST", message: "The blueprint title could not be converted into a safe story slug." });
  const memory = pickBlueprintField(parsed, ["memory", "story", "inspiration", "emotion", "intent", "description", "concept"]);
  const palette = pickBlueprintField(parsed, ["palette", "colors", "colourPalette"]);
  const materials = pickBlueprintField(parsed, ["materials", "florals", "flowers", "ingredients", "components"]);
  const construction = pickBlueprintField(parsed, ["construction", "structure", "composition", "designNotes", "placement"]);
  const territory = pickBlueprintField(parsed, ["territory", "mood", "collection", "theme"]);
  const productSlug = pickBlueprintField(parsed, ["productSlug", "productId", "catalogSlug"]);
  const dropSlug = pickBlueprintField(parsed, ["dropSlug", "seasonalDrop", "launchDrop"]);
  const source = [memory, territory && `Territory: ${territory}`, palette && `Palette: ${palette}`, materials && `Materials: ${materials}`, construction && `Construction: ${construction}`].filter(Boolean).join(". ");
  const generated = compileStoryGenesis({ title, eyebrow: "Moodoor Blueprint Story", excerpt: source || null, body: construction || null, kind: "studio" });
  return { story: { slug, kind: "studio" as const, title: generated.title, eyebrow: generated.eyebrow, excerpt: generated.excerpt, body: generated.body, imageUrl: null, imageKey: null, linkedProductSlug: productSlug, linkedDropSlug: dropSlug, isPublished: false, sortOrder: 0 }, extracted: { title, territory, palette, materials, construction, memory } };
}

type ImportedInventoryRow = { sku: string; canonId: string | null; species: string; colorName: string | null; colorHex: string | null; primaryRole: string | null; qtyOnHand: number; recommendedQty24in: number | null; unitPrice: string | null; seasonality: string | null; primaryEmotion: string | null; secondaryEmotion: string | null; wheelSector: string | null; textureArchetype: string | null; isRegisterGap: boolean; lowStockThreshold: number; notes: string | null; };
function inventoryString(value: unknown) { return typeof value === "string" ? value.trim() || null : typeof value === "number" ? String(value) : null; }
function inventoryNumber(value: unknown, fallback: number | null) { const number = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN; return Number.isFinite(number) && number >= 0 ? Math.floor(number) : fallback; }
function inventoryMoney(value: unknown) { const number = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN; return Number.isFinite(number) && number >= 0 ? number.toFixed(2) : null; }
function inventoryBoolean(value: unknown) { return value === true || value === "true" || value === 1 || value === "1"; }
function parseCsvRow(line: string) { const result: string[] = []; let cell = ""; let quoted = false; for (let index = 0; index < line.length; index += 1) { const char = line[index]; if (char === '"' && line[index + 1] === '"' && quoted) { cell += '"'; index += 1; } else if (char === '"') quoted = !quoted; else if (char === "," && !quoted) { result.push(cell.trim()); cell = ""; } else cell += char; } result.push(cell.trim()); return result; }
function normalizeInventoryRow(raw: Record<string, unknown>, inherited: Record<string, unknown> = {}, index = 0): ImportedInventoryRow {
  const value = (...fields: string[]) => {
    for (const source of [raw, inherited]) for (const field of fields) { const candidate = source[field]; if (candidate !== undefined && candidate !== null && candidate !== "") return candidate; }
    return undefined;
  };
  const sku = inventoryString(value("sku", "SKU", "sku_id", "skuId", "item_sku", "itemSku", "product_code", "productCode", "item_code", "itemCode", "code"));
  const species = inventoryString(value("species", "species_name", "speciesName", "botanical_name", "botanicalName", "plant_name", "plantName", "flower_name", "flowerName", "flower", "material_name", "materialName", "material", "product_name", "productName", "name", "title"));
  if (!sku || !species) throw new TRPCError({ code: "BAD_REQUEST", message: `Inventory row ${index + 1} needs both SKU and species. Recognized aliases include sku/product_code and species/botanical_name/product_name.` });
  return { sku, species, canonId: inventoryString(value("canonId", "canon_id", "canonical_id", "canonicalId")), colorName: inventoryString(value("colorName", "color_name", "color", "colour_name", "colourName")), colorHex: inventoryString(value("colorHex", "hex", "color_hex", "colour_hex")), primaryRole: inventoryString(value("primaryRole", "primary_role", "role", "category")), qtyOnHand: inventoryNumber(value("qtyOnHand", "qty_on_hand", "quantity", "qty", "available_quantity", "availableQuantity", "stock", "stock_qty", "stockQty"), 0) ?? 0, recommendedQty24in: inventoryNumber(value("recommendedQty24in", "recommended_qty_24in", "recommended_quantity", "recommendedQuantity"), null), unitPrice: inventoryMoney(value("unitPrice", "price", "unit_price", "unitPrice", "cost", "unit_cost", "unitCost")), seasonality: inventoryString(value("seasonality", "season", "seasonal")), primaryEmotion: inventoryString(value("primaryEmotion", "primary_emotion", "emotion")), secondaryEmotion: inventoryString(value("secondaryEmotion", "secondary_emotion")), wheelSector: inventoryString(value("wheelSector", "wheel_sector")), textureArchetype: inventoryString(value("textureArchetype", "texture_archetype", "texture")), isRegisterGap: inventoryBoolean(value("isRegisterGap", "register_gap")), lowStockThreshold: inventoryNumber(value("lowStockThreshold", "low_stock_threshold", "reorder_point", "reorderPoint"), 5) ?? 5, notes: inventoryString(value("notes", "note", "description")) };
}
export function parseInventoryImport(sourceText: string, format: "json" | "csv"): ImportedInventoryRow[] {
  const rows: ImportedInventoryRow[] = [];
  if (format === "csv") {
    const lines = sourceText.split(/\r?\n/).filter((line) => line.trim()); if (lines.length < 2) throw new TRPCError({ code: "BAD_REQUEST", message: "CSV inventory needs a header row and at least one inventory row." });
    const headers = parseCsvRow(lines[0]).map((header) => header.trim().replace(/^\uFEFF/, ""));
    lines.slice(1).forEach((line, index) => { const cells = parseCsvRow(line); const record = Object.fromEntries(headers.map((header, position) => [header, cells[position] ?? ""])); rows.push(normalizeInventoryRow(record, {}, index)); });
  } else {
    let parsed: unknown; try { parsed = JSON.parse(sourceText); } catch { throw new TRPCError({ code: "BAD_REQUEST", message: "Inventory JSON is invalid. Check commas, quotation marks, and braces." }); }
    const source = Array.isArray(parsed) ? parsed : isBlueprintRecord(parsed) ? parsed : null;
    if (!source) throw new TRPCError({ code: "BAD_REQUEST", message: "Inventory JSON must be an array of SKUs or an EFS-style inventory object." });
    const nestedKeys = ["skus", "variants", "items", "inventory", "products", "materials", "records", "data", "catalog", "species"];
    const walk = (record: unknown, inherited: Record<string, unknown> = {}) => {
      if (!isBlueprintRecord(record)) throw new TRPCError({ code: "BAD_REQUEST", message: `Inventory row ${rows.length + 1} must be an object.` });
      const merged = { ...inherited, ...record };
      for (const key of nestedKeys) {
        const nested = record[key];
        if (Array.isArray(nested)) { nested.forEach((child) => walk(child, merged)); return; }
        if (isBlueprintRecord(nested)) { walk(nested, merged); return; }
      }
      rows.push(normalizeInventoryRow(record, inherited, rows.length));
    };
    if (Array.isArray(source)) source.forEach((row) => walk(row)); else walk(source);
  }
  if (!rows.length) throw new TRPCError({ code: "BAD_REQUEST", message: "No importable inventory records were found." });
  if (rows.length > 2_000) throw new TRPCError({ code: "BAD_REQUEST", message: "Import up to 2,000 SKU records at a time." });
  return rows;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  content: router({
    publicOverview: publicProcedure.query(() => getPublicContentOverview()),
    adminOverview: adminProcedure.query(() => getAdminContentOverview()),
    saveSiteContent: adminProcedure.input(contentInput).mutation(async ({ ctx, input }) => { await saveSiteContent({ ...input, updatedBy: ctx.user.id }); return { success: true }; }),
    saveProduct: adminProcedure.input(productInput).mutation(async ({ ctx, input }) => { await saveCatalogProduct({ ...input, price: input.price.toFixed(2), blueprintPrice: input.blueprintPrice.toFixed(2), updatedBy: ctx.user.id }); return { success: true }; }),
    deleteProduct: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ input }) => { await removeCatalogProduct(input.slug); return { success: true }; }),
    saveBundle: adminProcedure.input(bundleInput).mutation(async ({ ctx, input }) => { await saveBundle({ ...input, price: input.price.toFixed(2), productSlugsJson: JSON.stringify(input.productSlugs), updatedBy: ctx.user.id }); return { success: true }; }),
    deleteBundle: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ input }) => { await removeBundle(input.slug); return { success: true }; }),
    saveTerritory: adminProcedure.input(territoryInput).mutation(async ({ ctx, input }) => { await saveTerritory({ ...input, updatedBy: ctx.user.id }); return { success: true }; }),
    deleteTerritory: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ input }) => { await removeTerritory(input.slug); return { success: true }; }),
    saveDrop: adminProcedure.input(dropInput).mutation(async ({ ctx, input }) => { await saveDrop({ ...input, tagSlugsJson: JSON.stringify(input.tagSlugs), updatedBy: ctx.user.id }); return { success: true }; }),
    deleteDrop: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ input }) => { await removeDrop(input.slug); return { success: true }; }),
    uploadImage: adminProcedure.input(imageUploadInput).mutation(async ({ ctx, input }) => {
      const { bytes, mimeType, extension } = decodeImageData(input.dataUrl);
      const stored = await storagePut(`moodoor-content/${ctx.user.id}/${randomUUID()}.${extension}`, bytes, mimeType);
      return { key: stored.key, url: stored.url };
    }),
    uploadBlueprint: adminProcedure.input(blueprintUploadInput).mutation(async ({ ctx, input }) => {
      const { bytes, mimeType } = decodeBlueprintData(input.dataUrl);
      const safeName = input.filename.replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-");
      const filename = safeName || "blueprint.pdf";
      const stored = await storagePut(`moodoor-blueprints/${ctx.user.id}/${randomUUID()}-${filename}`, bytes, mimeType);
      return { key: stored.key, url: stored.url, filename, mimeType };
    }),
  }),
  studio: router({
    list: adminProcedure.query(() => getStudioConcepts()),
    create: adminProcedure.input(studioConceptInput).mutation(async ({ ctx, input }) => {
      const prompt = compileStudioRenderPrompt(input);
      await saveStudioConcept({ ...input, renderPrompt: prompt, renderUrl: null, renderKey: null, renderAlt: `${input.name} wreath render`, status: "draft", generationError: null, reviewNotes: null, productSlug: null, createdBy: ctx.user.id, updatedBy: ctx.user.id, publishedAt: null });
      return { success: true, slug: input.slug, prompt };
    }),
    generate: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ ctx, input }) => {
      const concept = await getStudioConceptBySlug(input.slug);
      const base = conceptPayload(concept, {}, ctx.user.id);
      const prompt = base.renderPrompt || compileStudioRenderPrompt({ slug: base.slug, name: base.name, memory: base.memory, territory: base.territory, palette: base.palette, focalFlorals: base.focalFlorals, foliage: base.foliage, styleNotes: base.styleNotes });
      await saveStudioConcept({ ...base, renderPrompt: prompt, status: "generating", generationError: null });
      try {
        const image = await generateImage({ prompt, model: "MODEL_GPT_IMAGE_2", quality: "medium" });
        if (!image.url) throw new Error("The image service did not return a render URL.");
        await saveStudioConcept({ ...base, renderPrompt: prompt, renderUrl: image.url, renderKey: null, renderAlt: `${base.name} studio-rendered botanical wreath`, status: "ready", generationError: null });
        return { success: true, url: image.url, prompt };
      } catch (error) {
        const message = error instanceof Error ? error.message.slice(0, 1_800) : "Image generation failed.";
        await saveStudioConcept({ ...base, renderPrompt: prompt, status: "failed", generationError: message });
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Studio render generation failed. Please try again." });
      }
    }),
    review: adminProcedure.input(studioReviewInput).mutation(async ({ ctx, input }) => {
      const concept = await getStudioConceptBySlug(input.slug);
      const base = conceptPayload(concept, {}, ctx.user.id);
      if (input.approve && !base.renderUrl) throw new TRPCError({ code: "BAD_REQUEST", message: "Generate a render before approving this concept." });
      await saveStudioConcept({ ...base, reviewNotes: input.reviewNotes, status: input.approve ? "approved" : base.renderUrl ? "ready" : "draft", generationError: null });
      return { success: true };
    }),
    publish: adminProcedure.input(studioPublishInput).mutation(async ({ ctx, input }) => {
      const concept = await getStudioConceptBySlug(input.slug);
      const base = conceptPayload(concept, {}, ctx.user.id);
      if (base.status !== "approved" || !base.renderUrl) throw new TRPCError({ code: "BAD_REQUEST", message: "Approve a completed Studio render before publishing it to the catalog." });
      await saveCatalogProduct({ slug: base.slug, name: base.name, territory: base.territory, lede: base.memory ? `A Moodoor Studio design shaped by ${base.memory}` : "A Moodoor Studio design held in a new form.", description: base.styleNotes ? `${base.styleNotes} ${base.memory ?? ""}`.trim() : base.memory ?? "A Studio-rendered botanical wreath prepared for the Moodoor library.", price: input.price.toFixed(2), blueprintCode: `STUDIO-${base.slug.toUpperCase().slice(0, 18)}`, listingImageUrl: base.renderUrl, listingImageKey: null, heroImageUrl: base.renderUrl, heroImageKey: null, inventoryQuantity: input.inventoryQuantity, runLimit: input.runLimit, blueprintPrice: input.blueprintPrice.toFixed(2), blueprintAssetUrl: null, blueprintAssetKey: null, blueprintFilename: null, blueprintMimeType: null, isPublished: input.isPublished, sortOrder: input.sortOrder, updatedBy: ctx.user.id });
      await saveStudioConcept({ ...base, status: "published", productSlug: base.slug, publishedAt: new Date(), generationError: null });
      return { success: true, productSlug: base.slug };
    }),
  }),
  inventory: router({
    list: adminProcedure.query(() => getMoodoorInventory()),
    import: adminProcedure.input(inventoryImportInput).mutation(async ({ ctx, input }) => { const rows = parseInventoryImport(input.sourceText, input.format); const uniqueRows = Array.from(new Map(rows.map((row) => [row.sku, row])).values()); for (const row of uniqueRows) await saveMoodoorInventoryItem({ ...row, createdBy: ctx.user.id, updatedBy: ctx.user.id }); return { success: true, imported: uniqueRows.length, sourceRows: rows.length, duplicateSkus: rows.length - uniqueRows.length }; }),
    updateQuantity: adminProcedure.input(inventoryQuantityInput).mutation(async ({ ctx, input }) => { const current = await getMoodoorInventoryBySku(input.sku); if (!current) throw new TRPCError({ code: "NOT_FOUND", message: "Inventory SKU not found." }); await saveMoodoorInventoryItem({ sku: current.sku, canonId: current.canonId, species: current.species, colorName: current.colorName, colorHex: current.colorHex, primaryRole: current.primaryRole, qtyOnHand: input.qtyOnHand, recommendedQty24in: current.recommendedQty24in, unitPrice: current.unitPrice, seasonality: current.seasonality, primaryEmotion: current.primaryEmotion, secondaryEmotion: current.secondaryEmotion, wheelSector: current.wheelSector, textureArchetype: current.textureArchetype, isRegisterGap: current.isRegisterGap, lowStockThreshold: input.lowStockThreshold, notes: input.notes, createdBy: current.createdBy, updatedBy: ctx.user.id }); return { success: true }; }),
    delete: adminProcedure.input(z.object({ sku: z.string().trim().min(1).max(120) })).mutation(async ({ input }) => { await removeMoodoorInventoryItem(input.sku); return { success: true }; }),
  }),
  workspace: router({
    overview: adminProcedure.query(() => getMoodoorWorkspaceOverview()),
    publicStories: publicProcedure.query(() => getPublishedMoodoorStories()),
    saveBrief: adminProcedure.input(moodoorBriefInput).mutation(async ({ ctx, input }) => { await saveMoodoorBrief({ ...input, createdBy: ctx.user.id, updatedBy: ctx.user.id }); return { success: true }; }),
    analyzeBrief: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ ctx, input }) => {
      const brief = await getMoodoorBriefBySlug(input.slug);
      if (!brief) throw new TRPCError({ code: "NOT_FOUND", message: "Moodoor brief not found." });
      const output = compileCollectionIntelligence({ slug: brief.slug, title: brief.title, sourceMemory: brief.sourceMemory, season: brief.season, territory: brief.territory, collectionName: brief.collectionName, palette: brief.palette, materials: brief.materials, collectionInsight: brief.collectionInsight, collectionPlan: brief.collectionPlan, status: brief.status });
      await saveMoodoorBrief({ slug: brief.slug, title: brief.title, sourceMemory: brief.sourceMemory, season: brief.season, territory: brief.territory, collectionName: brief.collectionName, palette: brief.palette, materials: brief.materials, collectionInsight: output.insight, collectionPlan: output.plan, status: "analyzed", createdBy: brief.createdBy, updatedBy: ctx.user.id });
      return { success: true, ...output };
    }),
    deleteBrief: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ input }) => { await removeMoodoorBrief(input.slug); return { success: true }; }),
    saveStory: adminProcedure.input(moodoorStoryInput).mutation(async ({ ctx, input }) => { await saveMoodoorStory({ ...input, createdBy: ctx.user.id, updatedBy: ctx.user.id, publishedAt: input.isPublished ? new Date() : null }); return { success: true }; }),
    generateStoryGenesis: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ ctx, input }) => {
      const story = await getMoodoorStoryBySlug(input.slug);
      if (!story) throw new TRPCError({ code: "NOT_FOUND", message: "Moodoor story not found." });
      const output = compileStoryGenesis(story);
      await saveMoodoorStory({ slug: story.slug, kind: story.kind, title: output.title, eyebrow: output.eyebrow, excerpt: output.excerpt, body: output.body, imageUrl: story.imageUrl, imageKey: story.imageKey, linkedProductSlug: story.linkedProductSlug, linkedDropSlug: story.linkedDropSlug, isPublished: story.isPublished, sortOrder: story.sortOrder, createdBy: story.createdBy, updatedBy: ctx.user.id, publishedAt: story.publishedAt });
      return { success: true, ...output };
    }),
    blueprintToStory: adminProcedure.input(blueprintStoryInput).mutation(({ input }) => ({ success: true, ...compileBlueprintStory(input.blueprintJson) })),
    deleteStory: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ input }) => { await removeMoodoorStory(input.slug); return { success: true }; }),
    saveQualityCheck: adminProcedure.input(moodoorQualityInput).mutation(async ({ ctx, input }) => { await saveMoodoorQualityCheck({ ...input, checkedAt: input.status === "passed" || input.status === "needs_revision" ? new Date() : null, createdBy: ctx.user.id, updatedBy: ctx.user.id }); return { success: true }; }),
    deleteQualityCheck: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ input }) => { await removeMoodoorQualityCheck(input.slug); return { success: true }; }),
    saveOperation: adminProcedure.input(moodoorOperationInput).mutation(async ({ ctx, input }) => { await saveMoodoorOperation({ ...input, completedAt: input.status === "complete" ? new Date() : null, createdBy: ctx.user.id, updatedBy: ctx.user.id }); return { success: true }; }),
    deleteOperation: adminProcedure.input(z.object({ slug: slugField })).mutation(async ({ input }) => { await removeMoodoorOperation(input.slug); return { success: true }; }),
    buildCollectionEngine: adminProcedure.input(collectionEngineInput).mutation(async ({ ctx, input }) => {
      const brief = await getMoodoorBriefBySlug(input.briefSlug);
      if (!brief) throw new TRPCError({ code: "NOT_FOUND", message: "Moodoor brief not found." });
      if (brief.status === "draft") throw new TRPCError({ code: "BAD_REQUEST", message: "Run Collection Intelligence before building the collection output." });
      const bundleSlug = `${brief.slug}-collection`;
      await saveBundle({ slug: bundleSlug, name: brief.collectionName || brief.title, territory: brief.territory, price: input.price.toFixed(2), saving: null, lede: brief.collectionInsight || brief.sourceMemory, productSlugsJson: JSON.stringify(input.productSlugs), tone: "olive", imageUrl: null, imageKey: null, isPublished: input.isPublished, sortOrder: input.sortOrder, updatedBy: ctx.user.id });
      await saveMoodoorOperation({ slug: `${brief.slug}-collection-engine`, title: `Collection Engine — ${brief.collectionName || brief.title}`, module: "pipeline", status: "active", summary: "Collection Engine created or refreshed the linked collection bundle from the analyzed brief.", ownerNote: brief.collectionPlan, linkedBriefSlug: brief.slug, linkedStorySlug: null, linkedProductSlug: input.productSlugs[0] || null, linkedDropSlug: input.launchDropSlug, dueAt: null, createdBy: ctx.user.id, updatedBy: ctx.user.id, completedAt: null });
      return { success: true, bundleSlug };
    }),
    createLaunchDrop: adminProcedure.input(launchDropInput).mutation(async ({ ctx, input }) => {
      await saveDrop({ slug: input.slug, title: input.title, timingLabel: input.timingLabel, status: input.status, lede: input.lede, description: input.description, tagSlugsJson: JSON.stringify(input.tagSlugs), finishedRunCount: input.finishedRunCount, blueprintCount: input.blueprintCount, imageUrl: null, imageKey: null, launchAt: null, isPublished: input.isPublished, sortOrder: input.sortOrder, updatedBy: ctx.user.id });
      await saveMoodoorOperation({ slug: `${input.slug}-launch`, title: `Launch — ${input.title}`, module: "drop", status: input.status === "live" ? "active" : input.status === "archived" ? "complete" : "planned", summary: input.description || input.lede, ownerNote: "Connected seasonal-drop launch record.", linkedBriefSlug: input.linkedBriefSlug, linkedStorySlug: null, linkedProductSlug: null, linkedDropSlug: input.slug, dueAt: null, createdBy: ctx.user.id, updatedBy: ctx.user.id, completedAt: input.status === "archived" ? new Date() : null });
      return { success: true, dropSlug: input.slug };
    }),
    orchestrateExperience: adminProcedure.input(experienceInput).mutation(async ({ ctx, input }) => {
      await saveMoodoorOperation({ slug: input.slug, title: input.title, module: "experience", status: input.status, summary: input.summary, ownerNote: "Experience Orchestration connects the editorial story, product handoff, and seasonal release touchpoints.", linkedBriefSlug: null, linkedStorySlug: input.storySlug, linkedProductSlug: input.productSlug, linkedDropSlug: input.dropSlug, dueAt: null, createdBy: ctx.user.id, updatedBy: ctx.user.id, completedAt: input.status === "complete" ? new Date() : null });
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;

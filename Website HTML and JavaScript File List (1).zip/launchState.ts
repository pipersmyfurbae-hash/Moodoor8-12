export type PublicLaunchOperation = {
  linkedDropSlug: string | null;
  status: "planned" | "active" | "blocked" | "complete";
  summary: string | null;
  ownerNote: string | null;
};

export type LaunchAwareDrop = {
  slug: string;
  launchState?: PublicLaunchOperation["status"];
  launchSummary?: string;
};

/** Joins only explicit launch operations to their public seasonal-drop records. */
export function attachLaunchState<T extends { slug: string }>(drops: T[], operations: PublicLaunchOperation[]): Array<T & LaunchAwareDrop> {
  const byDrop = new Map(operations.filter((operation) => operation.linkedDropSlug).map((operation) => [operation.linkedDropSlug!, operation]));
  return drops.map((drop) => {
    const launch = byDrop.get(drop.slug);
    return { ...drop, launchState: launch?.status, launchSummary: launch?.summary ?? launch?.ownerNote ?? undefined };
  });
}

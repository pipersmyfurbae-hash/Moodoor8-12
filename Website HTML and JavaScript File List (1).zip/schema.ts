import { boolean, decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Editable page-level content. Images live in managed object storage; this table holds
 * only the storage key and serving URL alongside the written content.
 */
export const siteContent = mysqlTable("site_content", {
  id: int("id").autoincrement().primaryKey(),
  contentKey: varchar("contentKey", { length: 100 }).notNull().unique(),
  label: varchar("label", { length: 160 }).notNull(),
  heading: text("heading"),
  body: text("body"),
  imageUrl: text("imageUrl"),
  imageKey: varchar("imageKey", { length: 512 }),
  altText: text("altText"),
  updatedBy: int("updatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Product overrides managed through the editor. Existing storefront catalog records are
 * merged client-side until an administrator saves a corresponding row here.
 */
export const catalogProducts = mysqlTable("catalog_products", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 180 }).notNull(),
  territory: varchar("territory", { length: 120 }).notNull(),
  lede: text("lede"),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull().default("0.00"),
  blueprintCode: varchar("blueprintCode", { length: 120 }),
  listingImageUrl: text("listingImageUrl"),
  listingImageKey: varchar("listingImageKey", { length: 512 }),
  heroImageUrl: text("heroImageUrl"),
  heroImageKey: varchar("heroImageKey", { length: 512 }),
  inventoryQuantity: int("inventoryQuantity").notNull().default(0),
  runLimit: int("runLimit").notNull().default(0),
  blueprintPrice: decimal("blueprintPrice", { precision: 10, scale: 2 }).notNull().default("39.00"),
  blueprintAssetUrl: text("blueprintAssetUrl"),
  blueprintAssetKey: varchar("blueprintAssetKey", { length: 512 }),
  blueprintFilename: varchar("blueprintFilename", { length: 180 }),
  blueprintMimeType: varchar("blueprintMimeType", { length: 100 }),
  isPublished: boolean("isPublished").notNull().default(true),
  sortOrder: int("sortOrder").notNull().default(0),
  updatedBy: int("updatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Managed multi-design collection records. Product references are saved as a JSON array of slugs. */
export const catalogBundles = mysqlTable("catalog_bundles", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 180 }).notNull(),
  territory: varchar("territory", { length: 140 }).notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull().default("0.00"),
  saving: varchar("saving", { length: 180 }),
  lede: text("lede"),
  productSlugsJson: text("productSlugsJson"),
  tone: varchar("tone", { length: 24 }).notNull().default("olive"),
  imageUrl: text("imageUrl"),
  imageKey: varchar("imageKey", { length: 512 }),
  isPublished: boolean("isPublished").notNull().default(true),
  sortOrder: int("sortOrder").notNull().default(0),
  updatedBy: int("updatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Managed categories for the emotional collection library. */
export const catalogTerritories = mysqlTable("catalog_territories", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 140 }).notNull(),
  description: text("description"),
  designCount: int("designCount").notNull().default(0),
  tone: varchar("tone", { length: 24 }).notNull().default("olive"),
  imageUrl: text("imageUrl"),
  imageKey: varchar("imageKey", { length: 512 }),
  isPublished: boolean("isPublished").notNull().default(true),
  sortOrder: int("sortOrder").notNull().default(0),
  updatedBy: int("updatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Seasonal editorial releases. Tags are saved as a JSON array of territory or product slugs. */
export const seasonalDrops = mysqlTable("seasonal_drops", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  title: varchar("title", { length: 180 }).notNull(),
  timingLabel: varchar("timingLabel", { length: 140 }).notNull(),
  status: mysqlEnum("status", ["planned", "next", "live", "archived"]).notNull().default("planned"),
  lede: text("lede"),
  description: text("description"),
  tagSlugsJson: text("tagSlugsJson"),
  finishedRunCount: int("finishedRunCount").notNull().default(0),
  blueprintCount: int("blueprintCount").notNull().default(0),
  imageUrl: text("imageUrl"),
  imageKey: varchar("imageKey", { length: 512 }),
  launchAt: timestamp("launchAt"),
  isPublished: boolean("isPublished").notNull().default(true),
  sortOrder: int("sortOrder").notNull().default(0),
  updatedBy: int("updatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Owner-created Studio concepts. Each record follows the supplied Studio’s shared
 * library-item idea, but is server-backed and moves through generation, review, and
 * storefront publication rather than browser-local storage.
 */
export const studioConcepts = mysqlTable("studio_concepts", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 180 }).notNull(),
  memory: text("memory"),
  territory: varchar("territory", { length: 120 }).notNull(),
  palette: varchar("palette", { length: 180 }),
  focalFlorals: text("focalFlorals"),
  foliage: text("foliage"),
  styleNotes: text("styleNotes"),
  renderPrompt: text("renderPrompt"),
  renderUrl: text("renderUrl"),
  renderKey: varchar("renderKey", { length: 512 }),
  renderAlt: text("renderAlt"),
  status: mysqlEnum("status", ["draft", "generating", "ready", "approved", "published", "failed"]).notNull().default("draft"),
  generationError: text("generationError"),
  reviewNotes: text("reviewNotes"),
  productSlug: varchar("productSlug", { length: 100 }),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy"),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Brief Generator, Collection Intelligence, and Collection Engine records. */
export const moodoorBriefs = mysqlTable("moodoor_briefs", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  title: varchar("title", { length: 180 }).notNull(),
  sourceMemory: text("sourceMemory"),
  season: varchar("season", { length: 120 }),
  territory: varchar("territory", { length: 120 }).notNull(),
  collectionName: varchar("collectionName", { length: 180 }),
  palette: varchar("palette", { length: 180 }),
  materials: text("materials"),
  collectionInsight: text("collectionInsight"),
  collectionPlan: text("collectionPlan"),
  status: mysqlEnum("status", ["draft", "analyzed", "approved", "archived"]).notNull().default("draft"),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Author-led Moodoor Lifestyle Story, Stories Studio, Story Genesis, and Lookbook entries. */
export const moodoorStories = mysqlTable("moodoor_stories", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  kind: mysqlEnum("kind", ["lifestyle", "studio", "genesis", "story", "lookbook"]).notNull().default("story"),
  title: varchar("title", { length: 180 }).notNull(),
  eyebrow: varchar("eyebrow", { length: 180 }),
  excerpt: text("excerpt"),
  body: text("body"),
  imageUrl: text("imageUrl"),
  imageKey: varchar("imageKey", { length: 512 }),
  linkedProductSlug: varchar("linkedProductSlug", { length: 100 }),
  linkedDropSlug: varchar("linkedDropSlug", { length: 100 }),
  isPublished: boolean("isPublished").notNull().default(false),
  sortOrder: int("sortOrder").notNull().default(0),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy"),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Moodoor Quality Control review records attached to a Studio concept or catalog product. */
export const moodoorQualityChecks = mysqlTable("moodoor_quality_checks", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  title: varchar("title", { length: 180 }).notNull(),
  studioConceptSlug: varchar("studioConceptSlug", { length: 100 }),
  productSlug: varchar("productSlug", { length: 100 }),
  status: mysqlEnum("status", ["queued", "in_review", "passed", "needs_revision"]).notNull().default("queued"),
  compositionScore: int("compositionScore").notNull().default(0),
  materialScore: int("materialScore").notNull().default(0),
  commerceScore: int("commerceScore").notNull().default(0),
  notes: text("notes"),
  reviewedBy: varchar("reviewedBy", { length: 180 }),
  checkedAt: timestamp("checkedAt"),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Operator Console, bundled pipeline, Experience Orchestration, and seasonal-drop actions. */
export const moodoorOperations = mysqlTable("moodoor_operations", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  title: varchar("title", { length: 180 }).notNull(),
  module: mysqlEnum("module", ["operator", "pipeline", "experience", "drop"]).notNull().default("operator"),
  status: mysqlEnum("status", ["planned", "active", "blocked", "complete"]).notNull().default("planned"),
  summary: text("summary"),
  ownerNote: text("ownerNote"),
  linkedBriefSlug: varchar("linkedBriefSlug", { length: 100 }),
  linkedStorySlug: varchar("linkedStorySlug", { length: 100 }),
  linkedProductSlug: varchar("linkedProductSlug", { length: 100 }),
  linkedDropSlug: varchar("linkedDropSlug", { length: 100 }),
  dueAt: timestamp("dueAt"),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Imported botanical SKU inventory. The flattened record retains species-level mood
 * metadata from the original EFS register while allowing direct owner management.
 */
export const moodoorInventoryItems = mysqlTable("moodoor_inventory_items", {
  id: int("id").autoincrement().primaryKey(),
  sku: varchar("sku", { length: 120 }).notNull().unique(),
  canonId: varchar("canonId", { length: 120 }),
  species: varchar("species", { length: 180 }).notNull(),
  colorName: varchar("colorName", { length: 120 }),
  colorHex: varchar("colorHex", { length: 16 }),
  primaryRole: varchar("primaryRole", { length: 80 }),
  qtyOnHand: int("qtyOnHand").notNull().default(0),
  recommendedQty24in: int("recommendedQty24in"),
  unitPrice: decimal("unitPrice", { precision: 10, scale: 2 }),
  seasonality: varchar("seasonality", { length: 120 }),
  primaryEmotion: varchar("primaryEmotion", { length: 120 }),
  secondaryEmotion: varchar("secondaryEmotion", { length: 120 }),
  wheelSector: text("wheelSector"),
  textureArchetype: text("textureArchetype"),
  isRegisterGap: boolean("isRegisterGap").notNull().default(false),
  lowStockThreshold: int("lowStockThreshold").notNull().default(5),
  notes: text("notes"),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteContent = typeof siteContent.$inferSelect;
export type CatalogProduct = typeof catalogProducts.$inferSelect;
export type CatalogBundle = typeof catalogBundles.$inferSelect;
export type CatalogTerritory = typeof catalogTerritories.$inferSelect;
export type SeasonalDrop = typeof seasonalDrops.$inferSelect;
export type StudioConcept = typeof studioConcepts.$inferSelect;
export type MoodoorBrief = typeof moodoorBriefs.$inferSelect;
export type MoodoorStory = typeof moodoorStories.$inferSelect;
export type MoodoorQualityCheck = typeof moodoorQualityChecks.$inferSelect;
export type MoodoorOperation = typeof moodoorOperations.$inferSelect;
export type MoodoorInventoryItem = typeof moodoorInventoryItems.$inferSelect;

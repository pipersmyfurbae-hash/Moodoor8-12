/** MOODOOR ATELIER LOCATOR — source-reconciled map-based botanical sourcing concierge. */
import { MapView } from "@/components/Map";
import { Compass, ExternalLink, LocateFixed, MapPin, Search, Sprout } from "lucide-react";
import { useRef, useState } from "react";
import "./AtelierLocator.css";

type LocatorKind = "florists" | "supplies" | "ateliers";
type PlaceResult = { name: string; address: string; placeId?: string };

export default function AtelierLocator() {
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<any[]>([]);
  const [query, setQuery] = useState(""); const [kind, setKind] = useState<LocatorKind>("florists"); const [results, setResults] = useState<PlaceResult[]>([]); const [status, setStatus] = useState("Enter a city, ZIP code, or neighborhood to begin."); const [loading, setLoading] = useState(false);
  const clearMarkers = () => { markersRef.current.forEach((marker) => marker.map = null); markersRef.current = []; };
  const search = async (override?: string) => {
    const term = (override ?? query).trim(); const map = mapRef.current; if (!term || !map || !window.google) return setStatus(!map ? "The map is still loading. Please try again in a moment." : "Add a city, ZIP code, or neighborhood first.");
    setLoading(true); setResults([]); setStatus("Grounding the local botanical search…"); clearMarkers();
    const geocoder = new window.google.maps.Geocoder();
    geocoder.geocode({ address: term }, (geocoded, geoStatus) => {
      if (geoStatus !== "OK" || !geocoded?.[0]) { setStatus("We could not locate that area. Try a nearby city, state, or ZIP code."); setLoading(false); return; }
      const location = geocoded[0].geometry.location; map.setCenter(location); map.setZoom(12);
      const places = new window.google.maps.places.PlacesService(map);
      const labels: Record<LocatorKind, string> = { florists: "florists floral design studios", supplies: "botanical supply nurseries", ateliers: "flower arranging workshops botanical ateliers" };
      places.textSearch({ query: `${labels[kind]} near ${term}`, location, radius: 18000 }, (found, placeStatus) => {
        if (placeStatus !== window.google.maps.places.PlacesServiceStatus.OK || !found?.length) { setStatus("No verified places were returned for that search. Try a broader nearby city or a different sourcing filter."); setLoading(false); return; }
        const normalized = found.slice(0, 8).map((place) => ({ name: place.name || "Botanical place", address: place.formatted_address || "Address available in Google Maps", placeId: place.place_id }));
        setResults(normalized); setStatus(`${normalized.length} map-verified botanical sources near ${term}.`); setLoading(false);
        found.slice(0, 8).forEach((place) => { if (place.geometry?.location) markersRef.current.push(new (window.google as any).maps.marker.AdvancedMarkerElement({ map, position: place.geometry.location, title: place.name })); });
      });
    });
  };
  const locate = () => { if (!navigator.geolocation) return setStatus("Location detection is not available in this browser. Enter a city or ZIP code instead."); setStatus("Locating your workshop…"); navigator.geolocation.getCurrentPosition(({ coords }) => { const coordinate = `${coords.latitude.toFixed(4)}, ${coords.longitude.toFixed(4)}`; setQuery(coordinate); search(coordinate); }, () => setStatus("Location access was not granted. Enter a city or ZIP code instead."), { timeout: 10_000 }); };
  return <section className="atelier-page"><div className="shell-width"><header className="atelier-hero"><p className="eyebrow">Moodoor / Atelier Locator</p><h1>Find the botanical world <em>near your workshop.</em></h1><p>Search live map results for florists, botanical suppliers, and flower-arranging ateliers. The original Moodoor sourcing concierge is now a secure public map surface—results come from the map service, never from a fixed directory.</p></header><div className="atelier-layout"><aside className="atelier-search"><div className="atelier-panel-head"><Search size={17} /><div><p className="eyebrow">Local sourcing</p><h2>Atelier Concierge</h2></div></div><label>City, ZIP code, or neighborhood<div className="atelier-input"><MapPin size={15} /><input value={query} placeholder="Portland, OR" onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => event.key === "Enter" && search()} /></div></label><div className="atelier-kinds">{(["florists", "supplies", "ateliers"] as LocatorKind[]).map((item) => <button key={item} className={kind === item ? "active" : ""} onClick={() => setKind(item)}>{item === "florists" ? "Floral studios" : item === "supplies" ? "Botanical supplies" : "Workshops"}</button>)}</div><div className="atelier-actions"><button className="button button-olive" disabled={loading} onClick={() => search()}><Search size={14} /> {loading ? "Searching…" : "Search local sources"}</button><button className="atelier-locate" disabled={loading} onClick={locate}><LocateFixed size={14} /> Use my location</button></div><div className="atelier-note"><Sprout size={16} /><p>Pair Moodoor blueprint materials with local fresh accents, structural vines, or regional botanical finds. Verify availability directly with each source.</p></div></aside><div className="atelier-map-wrap"><MapView className="atelier-map" initialCenter={{ lat: 39.8283, lng: -98.5795 }} initialZoom={4} onMapReady={(map) => { mapRef.current = map; }} /><div className="atelier-status"><Compass size={15} /><span>{status}</span></div></div><aside className="atelier-results"><div className="atelier-panel-head"><Compass size={17} /><div><p className="eyebrow">Map results</p><h2>Source list</h2></div></div>{results.length ? <div className="atelier-results-list">{results.map((place) => <article key={`${place.name}-${place.placeId}`}><div><h3>{place.name}</h3><p>{place.address}</p></div>{place.placeId && <a href={`https://www.google.com/maps/search/?api=1&query_place_id=${place.placeId}`} target="_blank" rel="noreferrer" aria-label={`Open ${place.name} in Google Maps`}><ExternalLink size={14} /></a>}</article>)}</div> : <div className="atelier-empty"><MapPin size={24} /><p>Choose a location and sourcing category to see map-verified botanical partners here.</p></div>}</aside></div></div></section>;
}

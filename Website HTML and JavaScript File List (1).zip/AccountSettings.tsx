/** MOODOOR / OWNER ACCOUNT — identity is supplied by the authenticated Manus session. */
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowLeft, ArrowUpRight, CircleUserRound, Loader2, LogOut, ShieldCheck } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";

export default function AccountSettings() {
  const { user, loading, logout } = useAuth();
  const [, setLocation] = useLocation();
  const signOut = async () => { try { await logout(); toast.success("Signed out of Moodoor"); setLocation("/"); } catch { toast.error("Unable to sign out. Please try again."); } };
  if (loading) return <section className="account-page"><div className="account-loading"><Loader2 className="animate-spin" /> Loading account…</div></section>;
  if (user?.role !== "admin") return <section className="account-page"><div className="account-guard"><ShieldCheck size={28} /><p className="eyebrow">Private owner account</p><h1>Owner access required.</h1><p>Account settings are available only to the Moodoor owner account.</p><Link href="/" className="button button-olive">Return to storefront</Link></div></section>;
  const initial = (user.name || user.email || "O").trim().charAt(0).toUpperCase();
  return <section className="account-page"><div className="shell-width account-shell"><Link href="/" className="account-back"><ArrowLeft size={14} /> Back to storefront</Link><header><p className="eyebrow">Moodoor / owner account</p><h1>Account <em>settings.</em></h1><p>Your sign-in identity is managed securely by your connected account. The information below is read-only inside Moodoor.</p></header><div className="account-card"><div className="account-avatar">{initial}</div><div><p className="eyebrow">Signed in as</p><h2>{user.name || "Moodoor owner"}</h2><p>{user.email || "No email returned by identity provider"}</p></div><span className="account-role"><ShieldCheck size={14} /> Owner</span></div><div className="account-actions"><Link href="/admin" className="account-action"><SettingsRowIcon /><div><h2>Content Room</h2><p>Manage the store’s pages, catalog, inventory, blueprints, collections, and seasonal drops.</p></div><ArrowUpRight size={17} /></Link><button className="account-action account-signout-action" onClick={() => void signOut()}><LogOut size={18} /><div><h2>Sign out</h2><p>End this owner session on the current device.</p></div><ArrowUpRight size={17} /></button></div></div></section>;
}
function SettingsRowIcon() { return <CircleUserRound size={18} />; }

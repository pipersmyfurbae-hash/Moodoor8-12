import { asc, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { CatalogBundle, catalogBundles, CatalogProduct, catalogProducts, CatalogTerritory, catalogTerritories, InsertUser, MoodoorBrief, moodoorBriefs, MoodoorInventoryItem, moodoorInventoryItems, MoodoorOperation, moodoorOperations, MoodoorQualityCheck, moodoorQualityChecks, MoodoorStory, moodoorStories, SeasonalDrop, seasonalDrops, SiteContent, siteContent, StudioConcept, studioConcepts, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getPublicContentOverview(): Promise<{ siteContent: SiteContent[]; products: CatalogProduct[]; bundles: CatalogBundle[]; territories: CatalogTerritory[]; drops: SeasonalDrop[]; launchOperations: MoodoorOperation[] }> {
  const db = await getDb();
  if (!db) return { siteContent: [], products: [], bundles: [], territories: [], drops: [], launchOperations: [] };

  const [content, products, bundles, territories, drops, launchOperations] = await Promise.all([
    db.select().from(siteContent).orderBy(asc(siteContent.label)),
    db.select().from(catalogProducts).where(eq(catalogProducts.isPublished, true)).orderBy(asc(catalogProducts.sortOrder)),
    db.select().from(catalogBundles).where(eq(catalogBundles.isPublished, true)).orderBy(asc(catalogBundles.sortOrder)),
    db.select().from(catalogTerritories).where(eq(catalogTerritories.isPublished, true)).orderBy(asc(catalogTerritories.sortOrder)),
    db.select().from(seasonalDrops).where(eq(seasonalDrops.isPublished, true)).orderBy(asc(seasonalDrops.sortOrder)),
    db.select().from(moodoorOperations).where(eq(moodoorOperations.module, "drop")).orderBy(desc(moodoorOperations.updatedAt)),
  ]);

  return { siteContent: content, products, bundles, territories, drops, launchOperations };
}

export async function getAdminContentOverview(): Promise<{ siteContent: SiteContent[]; products: CatalogProduct[]; bundles: CatalogBundle[]; territories: CatalogTerritory[]; drops: SeasonalDrop[] }> {
  const db = await getDb();
  if (!db) throw new Error("The content database is temporarily unavailable.");
  const [content, products, bundles, territories, drops] = await Promise.all([
    db.select().from(siteContent).orderBy(asc(siteContent.label)),
    db.select().from(catalogProducts).orderBy(asc(catalogProducts.sortOrder)),
    db.select().from(catalogBundles).orderBy(asc(catalogBundles.sortOrder)),
    db.select().from(catalogTerritories).orderBy(asc(catalogTerritories.sortOrder)),
    db.select().from(seasonalDrops).orderBy(asc(seasonalDrops.sortOrder)),
  ]);
  return { siteContent: content, products, bundles, territories, drops };
}

export type SaveSiteContentInput = {
  contentKey: string;
  label: string;
  heading: string | null;
  body: string | null;
  imageUrl: string | null;
  imageKey: string | null;
  altText: string | null;
  updatedBy: number;
};

export async function saveSiteContent(input: SaveSiteContentInput) {
  const db = await getDb();
  if (!db) throw new Error("The content database is temporarily unavailable.");
  const values = { ...input };
  await db.insert(siteContent).values(values).onDuplicateKeyUpdate({
    set: { label: input.label, heading: input.heading, body: input.body, imageUrl: input.imageUrl, imageKey: input.imageKey, altText: input.altText, updatedBy: input.updatedBy },
  });
}

export type SaveCatalogProductInput = {
  slug: string;
  name: string;
  territory: string;
  lede: string | null;
  description: string | null;
  price: string;
  blueprintCode: string | null;
  listingImageUrl: string | null;
  listingImageKey: string | null;
  heroImageUrl: string | null;
  heroImageKey: string | null;
  inventoryQuantity: number;
  runLimit: number;
  blueprintPrice: string;
  blueprintAssetUrl: string | null;
  blueprintAssetKey: string | null;
  blueprintFilename: string | null;
  blueprintMimeType: string | null;
  isPublished: boolean;
  sortOrder: number;
  updatedBy: number;
};

export async function saveCatalogProduct(input: SaveCatalogProductInput) {
  const db = await getDb();
  if (!db) throw new Error("The content database is temporarily unavailable.");
  const values = { ...input };
  await db.insert(catalogProducts).values(values).onDuplicateKeyUpdate({
    set: { name: input.name, territory: input.territory, lede: input.lede, description: input.description, price: input.price, blueprintCode: input.blueprintCode, listingImageUrl: input.listingImageUrl, listingImageKey: input.listingImageKey, heroImageUrl: input.heroImageUrl, heroImageKey: input.heroImageKey, inventoryQuantity: input.inventoryQuantity, runLimit: input.runLimit, blueprintPrice: input.blueprintPrice, blueprintAssetUrl: input.blueprintAssetUrl, blueprintAssetKey: input.blueprintAssetKey, blueprintFilename: input.blueprintFilename, blueprintMimeType: input.blueprintMimeType, isPublished: input.isPublished, sortOrder: input.sortOrder, updatedBy: input.updatedBy },
  });
}

export async function removeCatalogProduct(slug: string) {
  const db = await getDb();
  if (!db) throw new Error("The content database is temporarily unavailable.");
  await db.delete(catalogProducts).where(eq(catalogProducts.slug, slug));
}

export type SaveBundleInput = {
  slug: string; name: string; territory: string; price: string; saving: string | null; lede: string | null; productSlugsJson: string | null; tone: string; imageUrl: string | null; imageKey: string | null; isPublished: boolean; sortOrder: number; updatedBy: number;
};
export async function saveBundle(input: SaveBundleInput) {
  const db = await getDb();
  if (!db) throw new Error("The content database is temporarily unavailable.");
  await db.insert(catalogBundles).values({ ...input }).onDuplicateKeyUpdate({ set: { name: input.name, territory: input.territory, price: input.price, saving: input.saving, lede: input.lede, productSlugsJson: input.productSlugsJson, tone: input.tone, imageUrl: input.imageUrl, imageKey: input.imageKey, isPublished: input.isPublished, sortOrder: input.sortOrder, updatedBy: input.updatedBy } });
}
export async function removeBundle(slug: string) { const db = await getDb(); if (!db) throw new Error("The content database is temporarily unavailable."); await db.delete(catalogBundles).where(eq(catalogBundles.slug, slug)); }

export type SaveTerritoryInput = {
  slug: string; name: string; description: string | null; designCount: number; tone: string; imageUrl: string | null; imageKey: string | null; isPublished: boolean; sortOrder: number; updatedBy: number;
};
export async function saveTerritory(input: SaveTerritoryInput) {
  const db = await getDb();
  if (!db) throw new Error("The content database is temporarily unavailable.");
  await db.insert(catalogTerritories).values({ ...input }).onDuplicateKeyUpdate({ set: { name: input.name, description: input.description, designCount: input.designCount, tone: input.tone, imageUrl: input.imageUrl, imageKey: input.imageKey, isPublished: input.isPublished, sortOrder: input.sortOrder, updatedBy: input.updatedBy } });
}
export async function removeTerritory(slug: string) { const db = await getDb(); if (!db) throw new Error("The content database is temporarily unavailable."); await db.delete(catalogTerritories).where(eq(catalogTerritories.slug, slug)); }

export type SaveDropInput = {
  slug: string; title: string; timingLabel: string; status: "planned" | "next" | "live" | "archived"; lede: string | null; description: string | null; tagSlugsJson: string | null; finishedRunCount: number; blueprintCount: number; imageUrl: string | null; imageKey: string | null; launchAt: Date | null; isPublished: boolean; sortOrder: number; updatedBy: number;
};
export async function saveDrop(input: SaveDropInput) {
  const db = await getDb();
  if (!db) throw new Error("The content database is temporarily unavailable.");
  await db.insert(seasonalDrops).values({ ...input }).onDuplicateKeyUpdate({ set: { title: input.title, timingLabel: input.timingLabel, status: input.status, lede: input.lede, description: input.description, tagSlugsJson: input.tagSlugsJson, finishedRunCount: input.finishedRunCount, blueprintCount: input.blueprintCount, imageUrl: input.imageUrl, imageKey: input.imageKey, launchAt: input.launchAt, isPublished: input.isPublished, sortOrder: input.sortOrder, updatedBy: input.updatedBy } });
}
export async function removeDrop(slug: string) { const db = await getDb(); if (!db) throw new Error("The content database is temporarily unavailable."); await db.delete(seasonalDrops).where(eq(seasonalDrops.slug, slug)); }

export type StudioConceptStatus = "draft" | "generating" | "ready" | "approved" | "published" | "failed";
export type SaveStudioConceptInput = {
  slug: string;
  name: string;
  memory: string | null;
  territory: string;
  palette: string | null;
  focalFlorals: string | null;
  foliage: string | null;
  styleNotes: string | null;
  renderPrompt: string | null;
  renderUrl: string | null;
  renderKey: string | null;
  renderAlt: string | null;
  status: StudioConceptStatus;
  generationError: string | null;
  reviewNotes: string | null;
  productSlug: string | null;
  createdBy: number;
  updatedBy: number;
  publishedAt: Date | null;
};

export async function getStudioConcepts(): Promise<StudioConcept[]> {
  const db = await getDb();
  if (!db) throw new Error("The Studio database is temporarily unavailable.");
  return db.select().from(studioConcepts).orderBy(desc(studioConcepts.updatedAt));
}

export async function getStudioConceptBySlug(slug: string): Promise<StudioConcept | undefined> {
  const db = await getDb();
  if (!db) throw new Error("The Studio database is temporarily unavailable.");
  const concepts = await db.select().from(studioConcepts).where(eq(studioConcepts.slug, slug)).limit(1);
  return concepts[0];
}

export async function saveStudioConcept(input: SaveStudioConceptInput) {
  const db = await getDb();
  if (!db) throw new Error("The Studio database is temporarily unavailable.");
  await db.insert(studioConcepts).values({ ...input }).onDuplicateKeyUpdate({
    set: { name: input.name, memory: input.memory, territory: input.territory, palette: input.palette, focalFlorals: input.focalFlorals, foliage: input.foliage, styleNotes: input.styleNotes, renderPrompt: input.renderPrompt, renderUrl: input.renderUrl, renderKey: input.renderKey, renderAlt: input.renderAlt, status: input.status, generationError: input.generationError, reviewNotes: input.reviewNotes, productSlug: input.productSlug, updatedBy: input.updatedBy, publishedAt: input.publishedAt },
  });
}

export async function getMoodoorWorkspaceOverview(): Promise<{ briefs: MoodoorBrief[]; stories: MoodoorStory[]; qualityChecks: MoodoorQualityCheck[]; operations: MoodoorOperation[] }> {
  const db = await getDb();
  if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable.");
  const [briefs, stories, qualityChecks, operations] = await Promise.all([
    db.select().from(moodoorBriefs).orderBy(desc(moodoorBriefs.updatedAt)),
    db.select().from(moodoorStories).orderBy(desc(moodoorStories.updatedAt)),
    db.select().from(moodoorQualityChecks).orderBy(desc(moodoorQualityChecks.updatedAt)),
    db.select().from(moodoorOperations).orderBy(desc(moodoorOperations.updatedAt)),
  ]);
  return { briefs, stories, qualityChecks, operations };
}

export async function getPublishedMoodoorStories(): Promise<MoodoorStory[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(moodoorStories).where(eq(moodoorStories.isPublished, true)).orderBy(asc(moodoorStories.sortOrder));
}

export type SaveMoodoorBriefInput = { slug: string; title: string; sourceMemory: string | null; season: string | null; territory: string; collectionName: string | null; palette: string | null; materials: string | null; collectionInsight: string | null; collectionPlan: string | null; status: "draft" | "analyzed" | "approved" | "archived"; createdBy: number; updatedBy: number; };
export async function saveMoodoorBrief(input: SaveMoodoorBriefInput) { const db = await getDb(); if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable."); await db.insert(moodoorBriefs).values({ ...input }).onDuplicateKeyUpdate({ set: { title: input.title, sourceMemory: input.sourceMemory, season: input.season, territory: input.territory, collectionName: input.collectionName, palette: input.palette, materials: input.materials, collectionInsight: input.collectionInsight, collectionPlan: input.collectionPlan, status: input.status, updatedBy: input.updatedBy } }); }
export async function removeMoodoorBrief(slug: string) { const db = await getDb(); if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable."); await db.delete(moodoorBriefs).where(eq(moodoorBriefs.slug, slug)); }
export async function getMoodoorBriefBySlug(slug: string) { const db = await getDb(); if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable."); return (await db.select().from(moodoorBriefs).where(eq(moodoorBriefs.slug, slug)).limit(1))[0]; }

export type SaveMoodoorStoryInput = { slug: string; kind: "lifestyle" | "studio" | "genesis" | "story" | "lookbook"; title: string; eyebrow: string | null; excerpt: string | null; body: string | null; imageUrl: string | null; imageKey: string | null; linkedProductSlug: string | null; linkedDropSlug: string | null; isPublished: boolean; sortOrder: number; createdBy: number; updatedBy: number; publishedAt: Date | null; };
export async function saveMoodoorStory(input: SaveMoodoorStoryInput) { const db = await getDb(); if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable."); await db.insert(moodoorStories).values({ ...input }).onDuplicateKeyUpdate({ set: { kind: input.kind, title: input.title, eyebrow: input.eyebrow, excerpt: input.excerpt, body: input.body, imageUrl: input.imageUrl, imageKey: input.imageKey, linkedProductSlug: input.linkedProductSlug, linkedDropSlug: input.linkedDropSlug, isPublished: input.isPublished, sortOrder: input.sortOrder, updatedBy: input.updatedBy, publishedAt: input.publishedAt } }); }
export async function removeMoodoorStory(slug: string) { const db = await getDb(); if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable."); await db.delete(moodoorStories).where(eq(moodoorStories.slug, slug)); }
export async function getMoodoorStoryBySlug(slug: string) { const db = await getDb(); if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable."); return (await db.select().from(moodoorStories).where(eq(moodoorStories.slug, slug)).limit(1))[0]; }

export type SaveMoodoorQualityInput = { slug: string; title: string; studioConceptSlug: string | null; productSlug: string | null; status: "queued" | "in_review" | "passed" | "needs_revision"; compositionScore: number; materialScore: number; commerceScore: number; notes: string | null; reviewedBy: string | null; checkedAt: Date | null; createdBy: number; updatedBy: number; };
export async function saveMoodoorQualityCheck(input: SaveMoodoorQualityInput) { const db = await getDb(); if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable."); await db.insert(moodoorQualityChecks).values({ ...input }).onDuplicateKeyUpdate({ set: { title: input.title, studioConceptSlug: input.studioConceptSlug, productSlug: input.productSlug, status: input.status, compositionScore: input.compositionScore, materialScore: input.materialScore, commerceScore: input.commerceScore, notes: input.notes, reviewedBy: input.reviewedBy, checkedAt: input.checkedAt, updatedBy: input.updatedBy } }); }
export async function removeMoodoorQualityCheck(slug: string) { const db = await getDb(); if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable."); await db.delete(moodoorQualityChecks).where(eq(moodoorQualityChecks.slug, slug)); }

export type SaveMoodoorOperationInput = { slug: string; title: string; module: "operator" | "pipeline" | "experience" | "drop"; status: "planned" | "active" | "blocked" | "complete"; summary: string | null; ownerNote: string | null; linkedBriefSlug: string | null; linkedStorySlug: string | null; linkedProductSlug: string | null; linkedDropSlug: string | null; dueAt: Date | null; createdBy: number; updatedBy: number; completedAt: Date | null; };
export async function saveMoodoorOperation(input: SaveMoodoorOperationInput) { const db = await getDb(); if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable."); await db.insert(moodoorOperations).values({ ...input }).onDuplicateKeyUpdate({ set: { title: input.title, module: input.module, status: input.status, summary: input.summary, ownerNote: input.ownerNote, linkedBriefSlug: input.linkedBriefSlug, linkedStorySlug: input.linkedStorySlug, linkedProductSlug: input.linkedProductSlug, linkedDropSlug: input.linkedDropSlug, dueAt: input.dueAt, updatedBy: input.updatedBy, completedAt: input.completedAt } }); }
export async function removeMoodoorOperation(slug: string) { const db = await getDb(); if (!db) throw new Error("The Moodoor workspace database is temporarily unavailable."); await db.delete(moodoorOperations).where(eq(moodoorOperations.slug, slug)); }

export type SaveMoodoorInventoryInput = {
  sku: string; canonId: string | null; species: string; colorName: string | null; colorHex: string | null; primaryRole: string | null; qtyOnHand: number; recommendedQty24in: number | null; unitPrice: string | null; seasonality: string | null; primaryEmotion: string | null; secondaryEmotion: string | null; wheelSector: string | null; textureArchetype: string | null; isRegisterGap: boolean; lowStockThreshold: number; notes: string | null; createdBy: number; updatedBy: number;
};
export async function getMoodoorInventory(): Promise<MoodoorInventoryItem[]> { const db = await getDb(); if (!db) throw new Error("The Moodoor inventory database is temporarily unavailable."); return db.select().from(moodoorInventoryItems).orderBy(asc(moodoorInventoryItems.species), asc(moodoorInventoryItems.sku)); }
export async function getMoodoorInventoryBySku(sku: string): Promise<MoodoorInventoryItem | undefined> { const db = await getDb(); if (!db) throw new Error("The Moodoor inventory database is temporarily unavailable."); return (await db.select().from(moodoorInventoryItems).where(eq(moodoorInventoryItems.sku, sku)).limit(1))[0]; }
export async function saveMoodoorInventoryItem(input: SaveMoodoorInventoryInput) { const db = await getDb(); if (!db) throw new Error("The Moodoor inventory database is temporarily unavailable."); await db.insert(moodoorInventoryItems).values({ ...input }).onDuplicateKeyUpdate({ set: { canonId: input.canonId, species: input.species, colorName: input.colorName, colorHex: input.colorHex, primaryRole: input.primaryRole, qtyOnHand: input.qtyOnHand, recommendedQty24in: input.recommendedQty24in, unitPrice: input.unitPrice, seasonality: input.seasonality, primaryEmotion: input.primaryEmotion, secondaryEmotion: input.secondaryEmotion, wheelSector: input.wheelSector, textureArchetype: input.textureArchetype, isRegisterGap: input.isRegisterGap, lowStockThreshold: input.lowStockThreshold, notes: input.notes, updatedBy: input.updatedBy } }); }
export async function removeMoodoorInventoryItem(sku: string) { const db = await getDb(); if (!db) throw new Error("The Moodoor inventory database is temporarily unavailable."); await db.delete(moodoorInventoryItems).where(eq(moodoorInventoryItems.sku, sku)); }

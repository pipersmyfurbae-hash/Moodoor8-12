import { useState, useEffect, useRef, useCallback } from "react";

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=Inter:wght@400;500;600;700&family=DM+Mono:wght@400;500;600&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body,#root{height:100%}
body{font-family:'Inter',system-ui,sans-serif;font-size:13px;color:#1A1A1A;background:#F9F7F4;-webkit-font-smoothing:antialiased;overflow:hidden}
button{font-family:inherit;cursor:pointer;border:none;background:none}
textarea,select{font-family:inherit}
::-webkit-scrollbar{width:4px}
::-webkit-scrollbar-thumb{background:#D0D0D0;border-radius:2px}
.ec-app{display:flex;flex-direction:column;height:100vh;overflow:hidden}
.ec-top{height:52px;flex-shrink:0;background:#1C2018;display:flex;align-items:center;padding:0 22px;gap:14px}
.ec-logo{font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:500;color:#F2EFE9}
.ec-logo em{font-style:italic;color:#7FB878}
.ec-module{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.14em;text-transform:uppercase;color:#7FB878;background:rgba(127,184,120,.12);border:1px solid rgba(127,184,120,.22);padding:3px 9px;border-radius:9999px}
.ec-pipe{font-family:'DM Mono',monospace;font-size:9px;color:rgba(255,255,255,.2);flex:1;text-align:center;letter-spacing:.03em}
.ec-catbadge{font-family:'DM Mono',monospace;font-size:11px;color:rgba(255,255,255,.3)}
.ec-catbadge b{color:#7FB878}
.ec-workspace{flex:1;display:grid;grid-template-columns:296px 1fr 352px;overflow:hidden;min-height:0}
.ec-left{background:#fff;border-right:1px solid #E8E8E8;overflow-y:auto;display:flex;flex-direction:column}
.ec-left-inner{padding:20px 18px 36px;flex:1}
.ec-slbl{font-family:'DM Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:#787878;margin-bottom:10px;display:block}
.ec-drop{border:1.5px dashed #C8C0B8;border-radius:10px;padding:24px 14px;text-align:center;cursor:pointer;transition:all .15s;background:#F9F7F4;display:flex;flex-direction:column;align-items:center;gap:6px}
.ec-drop:hover,.ec-drop.drag{border-color:#6B8F67;background:#EEF2ED}
.ec-drop p{font-family:'Cormorant Garamond',serif;font-style:italic;font-size:16px;color:#4A4A4A}
.ec-drop span{font-family:'DM Mono',monospace;font-size:9px;color:#A8A8A8}
.ec-thumb{position:relative;border-radius:10px;overflow:hidden;border:1px solid #E8E8E8;background:#F2EFE9}
.ec-thumb img{width:100%;display:block;max-height:190px;object-fit:contain}
.ec-clear{position:absolute;top:7px;right:7px;background:rgba(26,26,26,.72);color:#fff;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px}
.ec-field{margin-top:16px}
.ec-field label{font-family:'DM Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#787878;margin-bottom:7px;display:block}
.ec-sel{width:100%;padding:9px 11px;border:1px solid #E8E8E8;border-radius:7px;font-size:13px;color:#1A1A1A;outline:none;transition:border-color .15s}
.ec-sel:focus{border-color:#6B8F67}
.ec-mem{border:1px solid #E8E8E8;border-radius:10px;padding:12px 13px;transition:border-color .15s,box-shadow .15s;margin-bottom:8px}
.ec-mem:focus-within{border-color:#6B8F67;box-shadow:0 0 0 3px rgba(74,103,65,.09)}
.ec-mem textarea{width:100%;min-height:96px;border:none;outline:none;resize:vertical;background:transparent;font-family:'Cormorant Garamond',serif;font-style:italic;font-size:15.5px;color:#1A1A1A;line-height:1.5}
.ec-mem textarea::placeholder{color:#C4B8A4}
.ec-sample{font-family:'DM Mono',monospace;font-size:9.5px;color:#4A6741;text-decoration:underline;text-underline-offset:3px}
.ec-run{width:100%;margin-top:16px;background:#4A6741;color:#fff;font-weight:600;font-size:11px;letter-spacing:.07em;text-transform:uppercase;padding:13px;border-radius:9999px;display:flex;align-items:center;justify-content:center;gap:9px;transition:all .15s;border:none;cursor:pointer}
.ec-run:hover{background:#5C7D52;transform:scale(1.01)}
.ec-catalog{margin-top:22px}
.ec-catalog h3{font-family:'DM Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#787878;margin-bottom:10px;display:flex;justify-content:space-between}
.ec-catalog h3 span{font-weight:400;color:#A8A8A8}
.ec-catitem{display:grid;grid-template-columns:36px 1fr auto;gap:9px;align-items:center;padding:8px;border:1px solid #E8E8E8;border-radius:8px;margin-bottom:6px}
.ec-catthumb{width:36px;height:36px;border-radius:6px;object-fit:cover;background:#F2EFE9;border:1px solid #E8E8E8}
.ec-catname{font-family:'Cormorant Garamond',serif;font-size:14px;line-height:1.2;font-weight:500}
.ec-catmeta{font-family:'DM Mono',monospace;font-size:9px;color:#A8A8A8;margin-top:2px}
.ec-catdel{color:#D0D0D0;font-size:13px;padding:2px;transition:color .13s}
.ec-catdel:hover{color:#B94040}
.ec-catempty{font-family:'Cormorant Garamond',serif;font-style:italic;color:#A8A8A8;font-size:13px;padding:6px 0}
.ec-center{background:#F2EFE9;overflow-y:auto;padding:22px 22px 40px;display:flex;flex-direction:column;gap:16px}
.ec-stage{background:linear-gradient(150deg,#fff,#F2EFE9);border:1px solid #E8E8E8;border-radius:14px;min-height:230px;display:flex;align-items:center;justify-content:center;overflow:hidden;box-shadow:0 5px 20px rgba(0,0,0,.05);flex-shrink:0}
.ec-stage img{max-width:100%;max-height:320px;object-fit:contain;display:block}
.ec-ph{text-align:center;color:#C4B8A4;padding:44px 20px}
.ec-ph p{font-family:'Cormorant Garamond',serif;font-style:italic;font-size:17px;margin-top:10px}
.ec-rdh{font-family:'DM Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#787878;margin-bottom:11px;display:flex;justify-content:space-between}
.ec-rdh span{font-weight:400;color:#A8A8A8}
.ec-rdgrid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}
.ec-rd{background:#fff;border:1px solid #E8E8E8;border-radius:9px;padding:10px 12px}
.ec-rdl{font-family:'DM Mono',monospace;font-size:8.5px;text-transform:uppercase;letter-spacing:.06em;color:#A8A8A8;margin-bottom:3px}
.ec-rdv{font-family:'Cormorant Garamond',serif;font-size:20px;color:#1A1A1A;display:flex;align-items:center;gap:7px}
.ec-rdsw{width:13px;height:13px;border-radius:4px;border:1px solid rgba(0,0,0,.09);flex-shrink:0}
.ec-rdm{font-family:'DM Mono',monospace;font-size:9px;color:#A8A8A8;margin-top:2px}
.ec-verdict{background:#fff;border:1px solid #E8E8E8;border-radius:12px;padding:15px 17px}
.ec-vtop{display:flex;align-items:baseline;gap:10px;margin-bottom:13px}
.ec-vroman{font-family:'Cormorant Garamond',serif;font-size:14px;color:#6B8F67}
.ec-vname{font-family:'Cormorant Garamond',serif;font-size:23px;font-weight:400}
.ec-vconf{margin-left:auto;font-family:'DM Mono',monospace;font-size:10px;color:#4A6741;background:#EEF2ED;padding:3px 10px;border-radius:9999px}
.ec-vbars{display:grid;grid-template-columns:1fr 1fr;gap:7px 16px}
.ec-vbar{display:grid;grid-template-columns:56px 1fr 26px;gap:6px;align-items:center}
.ec-vbl{font-size:11px;color:#4A4A4A}
.ec-vbt{height:3.5px;background:#E8E8E8;border-radius:2px;overflow:hidden}
.ec-vbf{height:100%;border-radius:2px}
.ec-vbv{font-family:'DM Mono',monospace;font-size:9px;color:#787878;text-align:right}
.ec-right{background:#fff;border-left:1px solid #E8E8E8;display:flex;flex-direction:column;overflow:hidden}
.ec-right-inner{flex:1;overflow-y:auto;padding:20px 18px 16px}
.ec-story-empty{font-family:'Cormorant Garamond',serif;font-style:italic;color:#B0A898;font-size:15.5px;text-align:center;padding:48px 16px;line-height:1.55}
.ec-scard{background:linear-gradient(160deg,#EEF2ED,#F9F7F4);border:1px solid rgba(107,143,103,.2);border-radius:12px;padding:20px 20px;margin-bottom:13px}
.ec-sterr{font-family:'DM Mono',monospace;font-size:8.5px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:#4A6741;margin-bottom:6px}
.ec-stitle{font-family:'Cormorant Garamond',serif;font-size:25px;font-weight:400;line-height:1.1;letter-spacing:-.01em;margin-bottom:13px}
.ec-sbody{font-family:'Cormorant Garamond',serif;font-size:15px;line-height:1.62;color:#4A4A4A}
.ec-sbody p{margin-bottom:10px}
.ec-sbody p:last-child{margin-bottom:0}
.ec-sloading{display:flex;align-items:center;gap:9px;padding:20px 0;color:#A8A8A8;font-family:'DM Mono',monospace;font-size:10px;text-transform:uppercase;letter-spacing:.08em}
.ec-spin{width:14px;height:14px;border:2px solid rgba(74,103,65,.2);border-top-color:#4A6741;border-radius:50%;animation:ecspin .8s linear infinite;flex-shrink:0}
@keyframes ecspin{to{transform:rotate(360deg)}}
.ec-bpmini{background:#1C2018;border-radius:9px;padding:13px 15px}
.ec-bph{font-family:'DM Mono',monospace;font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:#5A6B54;margin-bottom:9px;display:flex;justify-content:space-between}
.ec-brow{display:flex;justify-content:space-between;font-family:'DM Mono',monospace;font-size:11px;color:#8A9A82;padding:3.5px 0;border-bottom:1px solid rgba(255,255,255,.05)}
.ec-brow:last-child{border:none}
.ec-brow b{color:#A8C4A0;font-weight:400}
.ec-saverow{padding:14px 18px;border-top:1px solid #E8E8E8;background:#F9F7F4;flex-shrink:0}
.ec-savebtn{width:100%;background:#4A6741;color:#fff;font-weight:600;font-size:11.5px;letter-spacing:.06em;text-transform:uppercase;padding:13px;border-radius:9999px;display:flex;align-items:center;justify-content:center;gap:8px;transition:all .15s;border:none;cursor:pointer}
.ec-savebtn:hover:not(:disabled){box-shadow:0 7px 18px rgba(74,103,65,.22);transform:scale(1.01)}
.ec-savebtn:disabled{background:#E8E8E8;color:#A8A8A8;cursor:default;transform:none;box-shadow:none}
.ec-savebtn.saved{background:rgba(74,103,65,.08);color:#4A6741;border:1.5px solid rgba(74,103,65,.25)}
.ec-savehint{font-family:'DM Mono',monospace;font-size:9px;color:#A8A8A8;text-align:center;margin-top:6px;letter-spacing:.03em}
.ec-toast{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#1A1A1A;color:#F2EFE9;font-size:12.5px;padding:10px 20px;border-radius:9999px;box-shadow:0 8px 28px rgba(0,0,0,.2);white-space:nowrap;z-index:9999;pointer-events:none;display:flex;align-items:center;gap:7px}
`;

const STORY_PROMPT = `You are the Moodoor Stories narrative engine. You write premium editorial Moodoor Stories AND four Midjourney lifestyle prompts for wreath designs.

You receive JSON with territory, EVS scores (0-100), palette, and optional client memory.

─── STORY ───
3 paragraphs, under 200 words total.
- Opening: The atmosphere or memory this wreath holds. If memory given, begin from it — sensory, present tense, no framing.
- Body: What the design communicates on a door. Its emotional weight before anyone knocks.
- Closing: The threshold moment. Someone coming home. What lands first.

Voice: literary, intimate, premium. Never "beautiful" or "stunning". Never craft-store language.

─── LIFESTYLE PROMPTS ───
4 complete, Midjourney-ready prompts drawn from the story's emotional world and the wreath's materials.

door: The wreath on a door. Match the story's architecture, season, and light. Name the door material (aged oak, chalk-white, slate-green, etc.). Include the wreath's palette and focal material. editorial product photography, 85mm f/2.8, side-lit. --ar 4:5 --style raw --s 150

interior: An interior lifestyle scene from the story's emotional world — no wreath visible. Just the room, the objects, the feeling. Editorial. Soft natural light. --ar 5:4 --style raw --s 150

detail: Macro botanical close-up of the wreath. Name the focal material explicitly. Side-lit natural daylight 12–2pm, visible silk microfibers, premium editorial styling, shallow depth of field. --ar 1:1 --style raw --s 150

mood: Wide atmospheric editorial shot. The emotional world of the story rendered as a scene — outdoors or threshold. Film grain, muted color grading, no text. --ar 16:9 --style raw --s 150

Return ONLY valid JSON, no markdown:
{"title":string,"opening":string,"body":string,"closing":string,"prompts":{"door":string,"interior":string,"detail":string,"mood":string}}`;

const DIMS = [
  {key:'warmth',label:'Warmth',color:'#C4922A'},
  {key:'energy',label:'Energy',color:'#B4652A'},
  {key:'nostalgia',label:'Nostalgia',color:'#4A6741'},
  {key:'valence',label:'Valence',color:'#6B8F67'},
  {key:'intimacy',label:'Intimacy',color:'#4A6785'},
  {key:'restraint',label:'Restraint',color:'#8A7458'},
  {key:'seasonal',label:'Seasonal',color:'#6E7A4E'},
];

const TERR = [
  {id:1,name:'Comfort',roman:'I',flavor:'the room that was always yours',word:'Hearth',c:{warmth:.863,energy:.220,nostalgia:.757,valence:.707,intimacy:.827,restraint:.760,seasonal:.483}},
  {id:2,name:'Celebration',roman:'II',flavor:'a threshold walked through smiling',word:'Arrival',c:{warmth:.785,energy:.855,nostalgia:.535,valence:.895,intimacy:.63,restraint:.41,seasonal:.555}},
  {id:3,name:'Remembrance',roman:'III',flavor:'what is kept by leaving space',word:'Quiet',c:{warmth:.715,energy:.12,nostalgia:.91,valence:.325,intimacy:.91,restraint:.91,seasonal:.475}},
  {id:4,name:'Renewal',roman:'IV',flavor:'the after, and everything ahead',word:'Morning',c:{warmth:.72,energy:.68,nostalgia:.35,valence:.82,intimacy:.62,restraint:.55,seasonal:.65}},
  {id:5,name:'Connection',roman:'V',flavor:'the people a house holds',word:'Table',c:{warmth:.80,energy:.32,nostalgia:.70,valence:.78,intimacy:.89,restraint:.65,seasonal:.32}},
  {id:6,name:'Seasonal Nostalgia',roman:'VI',flavor:'a month you can almost smell',word:'Season',c:{warmth:.7925,energy:.3425,nostalgia:.90,valence:.54,intimacy:.7725,restraint:.64,seasonal:.91}},
];

const LEX = {coffee:{warmth:.5,nostalgia:.4},fire:{warmth:.6,seasonal:.3},bonfire:{warmth:.5,seasonal:.6,nostalgia:.4},hearth:{warmth:.6,intimacy:.4},kitchen:{warmth:.5,intimacy:.4,nostalgia:.3},bread:{warmth:.5,nostalgia:.3},cedar:{warmth:.4,seasonal:.4,nostalgia:.3},wool:{warmth:.5,intimacy:.3},cozy:{warmth:.6,intimacy:.4},warm:{warmth:.6},sun:{warmth:.4,valence:.4},porch:{nostalgia:.6,warmth:.3,seasonal:.3},grandmother:{nostalgia:.6,warmth:.4,intimacy:.5},grandma:{nostalgia:.6,warmth:.4,intimacy:.5},childhood:{nostalgia:.7,valence:.3},remember:{nostalgia:.6},old:{nostalgia:.5},letters:{nostalgia:.5,restraint:.4,intimacy:.4},home:{warmth:.4,intimacy:.4,nostalgia:.4},lake:{nostalgia:.4,restraint:.3},mother:{intimacy:.5,warmth:.4,nostalgia:.4},mom:{intimacy:.5,warmth:.4,nostalgia:.4},father:{intimacy:.4,nostalgia:.4},together:{intimacy:.5,valence:.3},partner:{intimacy:.6,warmth:.3},whisper:{intimacy:.5,restraint:.4},quiet:{restraint:.6,intimacy:.3},still:{restraint:.6},calm:{restraint:.5},bare:{restraint:.6},hush:{restraint:.6,intimacy:.3},silence:{restraint:.6},mist:{restraint:.4,seasonal:.3},soft:{restraint:.3,warmth:.3},gentle:{restraint:.4,warmth:.3},joy:{valence:.7,energy:.3},dance:{energy:.6,valence:.5},wedding:{energy:.5,valence:.7,intimacy:.4},laughter:{energy:.5,valence:.7},bright:{energy:.4,valence:.6},morning:{energy:.4,valence:.4,warmth:.3},bloom:{valence:.5,seasonal:.3},garden:{valence:.4,seasonal:.3,nostalgia:.3},loss:{valence:-.6,nostalgia:.5,restraint:.5},grief:{valence:-.7,restraint:.6,intimacy:.4},passed:{valence:-.5,nostalgia:.5,restraint:.4},september:{seasonal:.7,nostalgia:.4},october:{seasonal:.7,nostalgia:.4},autumn:{seasonal:.7,nostalgia:.4,warmth:.3},fall:{seasonal:.6,nostalgia:.3},winter:{seasonal:.6,restraint:.3},december:{seasonal:.7,nostalgia:.3},snow:{seasonal:.6,restraint:.3},spring:{seasonal:.6,valence:.5,energy:.3},summer:{seasonal:.6,valence:.4,energy:.3},leaves:{seasonal:.5,nostalgia:.3},harvest:{seasonal:.6,warmth:.3},cider:{seasonal:.6,warmth:.4,nostalgia:.3},holiday:{seasonal:.6,valence:.4,nostalgia:.4}};

const NOUNS = ['screen door','porch','doorway','door','coffee','cedar','kitchen','garden','rain','snow','hearth','table','letters','lake','morning','window','candle','bread','tea','field','bonfire','harvest','leaves','cider'];
const MONTHS = ['january','february','march','april','may','june','july','august','september','october','november','december'];
const MAXD = Math.sqrt(7);
const KEYS = ['warmth','energy','nostalgia','valence','intimacy','restraint','seasonal'];
const clampV = x => Math.max(.04, Math.min(.99, x));
const cap = s => s ? s.split(' ').map(w => w[0].toUpperCase() + w.slice(1)).join(' ') : s;

function interpretMemory(text) {
  const t = ' ' + text.toLowerCase() + ' ';
  const base = {warmth:.35,energy:.32,nostalgia:.35,valence:.45,intimacy:.35,restraint:.30,seasonal:.30};
  const raw = {warmth:0,energy:0,nostalgia:0,valence:0,intimacy:0,restraint:0,seasonal:0};
  for (const kw in LEX) { if (t.includes(kw)) { const w = LEX[kw]; for (const d in w) raw[d] = (raw[d]||0) + w[d]; } }
  const v = {};
  for (const d in base) { const r = raw[d]; v[d] = r >= 0 ? clampV(base[d] + (0.99 - base[d]) * (1 - Math.exp(-0.7 * r))) : clampV(base[d] * Math.exp(0.7 * r)); }
  return v;
}

function classify(v) {
  return TERR.map(t => { let s=0; KEYS.forEach(k => { const d=v[k]-t.c[k]; s+=d*d; }); const dist=Math.sqrt(s); return {...t,dist,conf:Math.max(0,1-dist/MAXD)}; }).sort((a,b) => a.dist-b.dist);
}

function inferPalette(v) {
  const warm = v.warmth > 0.7, sHi = v.seasonal > 0.65, solemn = v.valence < 0.42;
  const dom = sHi&&warm ? ['toffee','#A8752A'] : (warm ? ['warm cream','#EFE6D3'] : (solemn ? ['aged ivory','#F2EDE3'] : ['dusty sage','#9AA88C']));
  const acc = warm ? ['amber','#C4922A'] : (solemn ? ['grey lichen','#9AA68C'] : ['cedar green','#4A6741']);
  return { domName:dom[0], domHex:dom[1], accName:acc[0], accHex:acc[1], focal: solemn?'preserved white rosebud':(sHi&&warm?'amber dahlia':(warm?'golden dahlia':'silver eucalyptus')) };
}

function reconstructBP(v, terr, size, pal) {
  const dia = parseInt(size)||18;
  const formula = terr.id===5?'Balanced Pair':(terr.id===3||v.restraint>.85?'Minimal Point':(terr.id===4?'Cascade':(v.energy>.66?'Asymmetric Spray':'Crescent')));
  const silSpan = Math.round(45 + v.restraint*70);
  const silStart = Math.round(90 + (1-v.energy)*40);
  const seed = Math.round((v.warmth*7+v.nostalgia*13+v.seasonal*17+v.energy*23)*131)%9000+1000;
  const cM = x => Math.max(4,Math.min(20,Math.round(x)));
  const score = cM(12+v.intimacy*8)+cM(9+v.energy*11)+cM(5+v.restraint*15)+cM(10+v.seasonal*9)+cM(11+v.warmth*8)+13;
  return { id:'EC_WR_V2_'+seed, formula, silence:silStart+'°–'+(silStart+silSpan)+'° · bare', focal:pal.focal, palette:pal.domName+' · '+pal.accName, score:score+' / 120' };
}

function sampleCanvas(imgEl) {
  const N=64; const c=document.createElement('canvas'); c.width=N; c.height=N;
  const ctx=c.getContext('2d'); ctx.drawImage(imgEl,0,0,N,N);
  const d=ctx.getImageData(0,0,N,N).data; const n=N*N;
  const corner=(x,y)=>{const i=(y*N+x)*4;return[d[i],d[i+1],d[i+2]];};
  const cs=[corner(0,0),corner(N-1,0),corner(0,N-1),corner(N-1,N-1)];
  const bg=[0,1,2].map(k=>(cs[0][k]+cs[1][k]+cs[2][k]+cs[3][k])/4);
  let R=0,G=0,B=0,topL=0,botL=0,covered=0;
  for(let y=0;y<N;y++) for(let x=0;x<N;x++){
    const i=(y*N+x)*4; const r=d[i],g=d[i+1],b=d[i+2]; R+=r;G+=g;B+=b;
    const lum=0.299*r+0.587*g+0.114*b;
    if(y<N/2)topL+=lum; else botL+=lum;
    if(Math.abs(r-bg[0])+Math.abs(g-bg[1])+Math.abs(b-bg[2])>60) covered++;
  }
  R/=n;G/=n;B/=n;
  return { warmth:clampV(0.5+(R-B)/200), energy:clampV(0.5+(topL/(n/2)-botL/(n/2))/160), restraint:clampV(0.9-(covered/n)*0.9), valence:clampV(0.35+((Math.max(R,G,B)-Math.min(R,G,B))/255)*0.9), coverage:covered/n, avg:[Math.round(R),Math.round(G),Math.round(B)] };
}

function buildFallbackStory(memory, v, terr, pal) {
  const mem = memory || 'a feeling that stays';
  const nouns = NOUNS.filter(n => mem.toLowerCase().includes(n));
  const month = MONTHS.find(m => mem.toLowerCase().includes(m));
  let title = month&&nouns[0] ? cap(month)+' '+cap(nouns[0]) : (nouns[0]&&nouns[1] ? cap(nouns[0])+' & '+cap(nouns[1]) : (nouns[0] ? 'The '+cap(nouns[0]) : 'A '+terr.word));
  const rk = DIMS.map(d=>({l:d.label.toLowerCase(),val:v[d.key]})).sort((a,b)=>b.val-a.val);
  const anchor = mem.trim().split(/[—.,;:]/)[0].trim().slice(0,88);
  const weight = v.energy>.55?'lifted, reaching toward the light':(v.restraint>.72?'held low — more than half the vine left bare on purpose':'settled, the way a warm room sits');
  return { title, opening:`It begins where the memory does — ${anchor.charAt(0).toLowerCase()+anchor.slice(1)}. The small, exact things that don't fade.`, body:`What it carries is ${rk[0].l}, and beneath it ${rk[1].l} — ${terr.flavor}. Mapped on the Emotional Vector System, it settled into ${terr.name}, and the design answered.`, closing:`Built in ${pal.domName} and ${pal.accName}, ${weight}. The empty arc of grapevine is not a gap. It is the part of the memory words never reach.` };
}

async function generateStory(v, terr, pal, memory) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({ model:'claude-sonnet-4-6', max_tokens:1000, system:STORY_PROMPT,
      messages:[{role:'user',content:JSON.stringify({
        territory:{name:terr.name,roman:terr.roman,flavor:terr.flavor},
        evs:Object.fromEntries(KEYS.map(k=>[k,Math.round(v[k]*100)])),
        palette:{dominant:pal.domName,accent:pal.accName},
        memory:memory||null
      })}]
    })
  });
  if(!res.ok) throw new Error('API '+res.status);
  const data = await res.json();
  const text = data.content?.find(b=>b.type==='text')?.text||'';
  return JSON.parse(text.replace(/```json\n?|```\n?/g,'').trim());
}

// ─────────────────────────────────────────────────────────────
// COMPONENTS
// ─────────────────────────────────────────────────────────────
function Toast({ msg }) {
  if (!msg) return null;
  return (
    <div className="ec-toast">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#7FB878" strokeWidth="2.5"><path d="M20 6 9 17l-5-5"/></svg>
      {msg}
    </div>
  );
}

function PixelGrid({ seeds, source }) {
  if (!seeds && !source) return null;
  const rows = [
    { l:'Palette temp', v: seeds ? (seeds.warmth>.58?'Warm':(seeds.warmth<.44?'Cool':'Neutral')) : '—', sw: seeds ? `rgb(${seeds.avg[0]},${seeds.avg[1]},${seeds.avg[2]})` : null, m: seeds ? `R${seeds.avg[0]} G${seeds.avg[1]} B${seeds.avg[2]}` : 'memory only' },
    { l:'Weight dist', v: seeds ? (seeds.energy>.56?'Top-lifted':(seeds.energy<.44?'Bottom-settled':'Even')) : '—', m: seeds ? 'luminance top vs bottom' : 'from memory' },
    { l:'Coverage', v: seeds ? Math.round(seeds.coverage*100)+'%' : '—', m: seeds ? (seeds.coverage<.5?'sparse — bare vine reads':'full vine coverage') : 'from memory' },
    { l:'Source', v: source, m: 'inputs blended' },
  ];
  return (
    <div className="ec-rdgrid">
      {rows.map((r,i) => (
        <div key={i} className="ec-rd">
          <div className="ec-rdl">{r.l}</div>
          <div className="ec-rdv">{r.sw && <span className="ec-rdsw" style={{background:r.sw}}/>}<span>{r.v}</span></div>
          <div className="ec-rdm">{r.m}</div>
        </div>
      ))}
    </div>
  );
}

function VerdictCard({ v, terr }) {
  const conf = Math.round(Math.pow(terr.conf,2)*100);
  return (
    <div className="ec-verdict">
      <div className="ec-vtop">
        <span className="ec-vroman">{terr.roman}</span>
        <span className="ec-vname">{terr.name}</span>
        <span className="ec-vconf">tag · {conf}%</span>
      </div>
      <div className="ec-vbars">
        {DIMS.map(d => { const pct=Math.round(v[d.key]*100); return (
          <div key={d.key} className="ec-vbar">
            <span className="ec-vbl">{d.label}</span>
            <div className="ec-vbt"><div className="ec-vbf" style={{width:pct+'%',background:d.color}}/></div>
            <span className="ec-vbv">.{String(pct).padStart(2,'0')}</span>
          </div>
        ); })}
      </div>
    </div>
  );
}

function StoryPanel({ story, loading, terr }) {
  if (loading) return (
    <div className="ec-scard">
      <div className="ec-sterr">{terr.roman} · {terr.name}</div>
      <div className="ec-sloading"><div className="ec-spin"/><span>Writing your story…</span></div>
    </div>
  );
  if (!story) return <div className="ec-story-empty">Run the pipeline and the story writes itself from the client's memory.</div>;
  return (
    <div className="ec-scard">
      <div className="ec-sterr">{terr.roman} · {terr.name} · Moodoor Story</div>
      <div className="ec-stitle">{story.title}</div>
      <div className="ec-sbody">
        <p>{story.opening}</p>
        <p>{story.body}</p>
        <p>{story.closing}</p>
      </div>
    </div>
  );
}

function BlueprintMini({ bp }) {
  if (!bp) return null;
  return (
    <div className="ec-bpmini">
      <div className="ec-bph"><span>EC_WR_V2 · regenerated</span><span>{bp.id}</span></div>
      {[['formula',bp.formula],['silence arc',bp.silence],['focal material',bp.focal],['palette',bp.palette],['composite score',bp.score]].map(([l,v])=>(
        <div key={l} className="ec-brow"><span>{l}</span><b>{v}</b></div>
      ))}
    </div>
  );
}

const PROMPT_META = {
  door:     { label: 'Door hero',           ar: '4:5'  },
  interior: { label: 'Interior lifestyle',  ar: '5:4'  },
  detail:   { label: 'Material close-up',   ar: '1:1'  },
  mood:     { label: 'Atmospheric mood',    ar: '16:9' },
};

function LifestylePrompts({ prompts }) {
  const [copied, setCopied] = useState(null);
  if (!prompts) return null;
  const copy = (key, text) => {
    if (navigator.clipboard) navigator.clipboard.writeText(text).catch(() => {});
    setCopied(key);
    setTimeout(() => setCopied(null), 1800);
  };
  return (
    <div style={{ marginTop: '16px' }}>
      <div style={{ fontFamily: "'DM Mono',monospace", fontSize: '9px', fontWeight: 700, letterSpacing: '.14em', textTransform: 'uppercase', color: '#787878', marginBottom: '12px', paddingTop: '14px', borderTop: '1px solid #E8E8E8' }}>
        Lifestyle render prompts
      </div>
      {Object.entries(PROMPT_META).map(([key, meta]) => {
        const text = prompts[key];
        if (!text) return null;
        const isCopied = copied === key;
        return (
          <div key={key} style={{ marginBottom: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '5px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
                <span style={{ fontFamily: "'DM Mono',monospace", fontSize: '8.5px', textTransform: 'uppercase', letterSpacing: '.1em', color: '#4A6741', fontWeight: 700 }}>{meta.label}</span>
                <span style={{ fontFamily: "'DM Mono',monospace", fontSize: '8px', color: '#A8A8A8', background: '#F2EFE9', border: '1px solid #E8E8E8', padding: '1px 6px', borderRadius: '9999px' }}>--ar {meta.ar}</span>
              </div>
              <button
                onClick={() => copy(key, text)}
                style={{ fontFamily: "'DM Mono',monospace", fontSize: '9px', color: isCopied ? '#4A6741' : '#A8A8A8', padding: '3px 9px', borderRadius: '9999px', border: `1px solid ${isCopied ? 'rgba(74,103,65,.3)' : '#E8E8E8'}`, background: isCopied ? '#EEF2ED' : 'transparent', cursor: 'pointer', transition: 'all .15s' }}>
                {isCopied ? '✓ Copied' : 'Copy'}
              </button>
            </div>
            <div style={{ background: '#1C2018', borderRadius: '8px', padding: '11px 13px', fontFamily: "'DM Mono',monospace", fontSize: '10.5px', color: '#8A9A82', lineHeight: '1.65', wordBreak: 'break-word', cursor: 'text', userSelect: 'all' }}>
              {text}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// APP
// ─────────────────────────────────────────────────────────────
export default function App() {
  const [imageUrl, setImageUrl] = useState(null);
  const [imageSeeds, setImageSeeds] = useState(null);
  const [size, setSize] = useState('18" grapevine');
  const [memory, setMemory] = useState('');
  const [analyzed, setAnalyzed] = useState(false);
  const [result, setResult] = useState(null);
  const [story, setStory] = useState(null);
  const [storyLoading, setStoryLoading] = useState(false);
  const [catalog, setCatalog] = useState([]);
  const [saved, setSaved] = useState(false);
  const [drag, setDrag] = useState(false);
  const [toast, setToast] = useState('');
  const fileRef = useRef(null);
  const toastTimer = useRef(null);

  useEffect(() => {
    const s = document.createElement('style');
    s.textContent = CSS;
    document.head.appendChild(s);
    return () => document.head.removeChild(s);
  }, []);

  const showToast = msg => { setToast(msg); clearTimeout(toastTimer.current); toastTimer.current = setTimeout(() => setToast(''), 2600); };

  const loadFile = useCallback(file => {
    if (!file || !file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const N=320; const s=Math.min(1,N/Math.max(img.width,img.height));
        const c=document.createElement('canvas'); c.width=Math.round(img.width*s); c.height=Math.round(img.height*s);
        c.getContext('2d').drawImage(img,0,0,c.width,c.height);
        setImageUrl(c.toDataURL('image/jpeg',0.85));
        setImageSeeds(sampleCanvas(img));
        setAnalyzed(false); setResult(null); setStory(null); setSaved(false);
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  }, []);

  const clearImage = () => { setImageUrl(null); setImageSeeds(null); setAnalyzed(false); setResult(null); setStory(null); setSaved(false); };

  const runPipeline = async () => {
    if (!memory.trim() && !imageSeeds) { showToast('Add a memory or upload a render first.'); return; }
    let v = memory.trim() ? interpretMemory(memory) : {warmth:.5,energy:.4,nostalgia:.5,valence:.5,intimacy:.5,restraint:.5,seasonal:.5};
    let source = 'memory only';
    if (imageSeeds) {
      const im = imageSeeds; const bl = (a,b) => clampV(a*.55+b*.45);
      v = {...v, warmth:bl(v.warmth,im.warmth), energy:bl(v.energy,im.energy), restraint:bl(v.restraint,im.restraint), valence:bl(v.valence,im.valence)};
      source = memory.trim() ? 'render + memory' : 'render only';
    }
    const terr = classify(v)[0];
    const pal = inferPalette(v);
    const bp = reconstructBP(v, terr, size, pal);
    setResult({v, terr, pal, bp, source});
    setAnalyzed(true); setSaved(false); setStory(null); setStoryLoading(true);
    try {
      const s = await generateStory(v, terr, pal, memory);
      setStory(s);
    } catch(e) {
      console.warn('API fallback:', e);
      setStory(buildFallbackStory(memory, v, terr, pal));
    }
    setStoryLoading(false);
  };

  const saveToLog = () => {
    if (!result || !story || saved) return;
    const item = { id:'W'+Date.now().toString(36), name:story.title, territory:result.terr.name, terrRoman:result.terr.roman, image:imageUrl||'', savedAt:new Date().toLocaleDateString('en-US',{month:'short',day:'numeric'}) };
    setCatalog(c => [item,...c]);
    setSaved(true);
    showToast(`"${item.name}" saved to catalog`);
  };

  return (
    <div className="ec-app"
      onDragOver={e => { e.preventDefault(); setDrag(true); }}
      onDragLeave={() => setDrag(false)}
      onDrop={e => { e.preventDefault(); setDrag(false); loadFile(e.dataTransfer.files[0]); }}>

      <Toast msg={toast}/>

      {/* TOP BAR */}
      <div className="ec-top">
        <span className="ec-logo">Ever<em>crafted</em></span>
        <span className="ec-module">Stories Studio</span>
        <span className="ec-pipe">render → sample → classify → EC_WR_V2 → story → catalog</span>
        <span className="ec-catbadge"><b>{catalog.length}</b> in catalog</span>
      </div>

      {/* WORKSPACE */}
      <div className="ec-workspace">

        {/* LEFT */}
        <div className="ec-left">
          <div className="ec-left-inner">
            <span className="ec-slbl">1 · Rendered wreath</span>
            {imageUrl ? (
              <div className="ec-thumb">
                <img src={imageUrl} alt="render"/>
                <button className="ec-clear" onClick={clearImage}>×</button>
              </div>
            ) : (
              <div className={`ec-drop${drag?' drag':''}`} onClick={() => fileRef.current?.click()}>
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#C4B8A4" strokeWidth="1.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5"/><path d="M12 3v13"/></svg>
                <p>Drop a render or click to upload</p>
                <span>PNG · JPG · Midjourney output or finished photo</span>
                <input ref={fileRef} type="file" accept="image/*" style={{display:'none'}} onChange={e=>loadFile(e.target.files[0])}/>
              </div>
            )}

            <div className="ec-field">
              <label>Base size</label>
              <select className="ec-sel" value={size} onChange={e=>setSize(e.target.value)}>
                {['16" grapevine','18" grapevine','20" grapevine','24" grapevine'].map(o=><option key={o}>{o}</option>)}
              </select>
            </div>

            <div className="ec-field">
              <label>Client memory <span style={{fontWeight:400,textTransform:'none',letterSpacing:0,color:'#A8A8A8'}}>— becomes the story</span></label>
              <div className="ec-mem">
                <textarea placeholder="The memory this wreath was built to hold — a place, a person, a season…" value={memory} onChange={e=>setMemory(e.target.value)}/>
              </div>
              <button className="ec-sample" onClick={()=>setMemory("My grandmother's porch in late September — cedar, cold coffee, and the screen door that never quite closed.")}>use a sample memory</button>
            </div>

            <button className="ec-run" onClick={runPipeline}>
              Run pipeline
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
            </button>

            <div className="ec-catalog">
              <h3>Catalog <span>{catalog.length} saved</span></h3>
              {catalog.length === 0 ? (
                <div className="ec-catempty">Nothing saved yet.</div>
              ) : catalog.map(c=>(
                <div key={c.id} className="ec-catitem">
                  {c.image ? <img className="ec-catthumb" src={c.image} alt=""/> : <div className="ec-catthumb"/>}
                  <div>
                    <div className="ec-catname">{c.name}</div>
                    <div className="ec-catmeta">{c.terrRoman} · {c.territory} · {c.savedAt}</div>
                  </div>
                  <button className="ec-catdel" onClick={()=>setCatalog(l=>l.filter(x=>x.id!==c.id))}>✕</button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* CENTER */}
        <div className="ec-center">
          <div className="ec-stage">
            {imageUrl ? <img src={imageUrl} alt="render"/> : (
              <div className="ec-ph">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#C4B8A4" strokeWidth="1.2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>
                <p>Upload a rendered wreath to begin</p>
              </div>
            )}
          </div>

          {analyzed && result && (
            <div>
              <div className="ec-rdh">Pixel readings <span>measured from the render</span></div>
              <PixelGrid seeds={imageSeeds} source={result.source}/>
              <VerdictCard v={result.v} terr={result.terr}/>
            </div>
          )}
        </div>

        {/* RIGHT */}
        <div className="ec-right">
          <div className="ec-right-inner">
            <span className="ec-slbl">Moodoor Story <span style={{fontWeight:400,textTransform:'none',letterSpacing:0,color:'#A8A8A8'}}>— drafted from the memory</span></span>
            <StoryPanel story={story} loading={storyLoading} terr={result?.terr || TERR[0]}/>
            {analyzed && result && <BlueprintMini bp={result.bp}/>}
            {analyzed && result && <LifestylePrompts prompts={story?.prompts}/>}
          </div>
          <div className="ec-saverow">
            <button
              className={`ec-savebtn${saved?' saved':''}`}
              disabled={!analyzed || storyLoading || !story || saved}
              onClick={saveToLog}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/></svg>
              {saved ? '✓ Saved to catalog' : 'Save wreath + story to catalog'}
            </button>
            <div className="ec-savehint">writes to Moodoor Wreaths + Moodoor Stories</div>
          </div>
        </div>

      </div>
    </div>
  );
}

# Moodoor Studio Source Notes

The supplied `moodoorstudiosrc.zip` describes a local-first Studio pipeline with two connected tools: a **Brief Generator** that turns a memory, theme, or whole-home brief into recipe-backed library items, and a **Prompt Library** that compiles those items into camera-specific product render prompts. Its source record preserves recipe name, emotional tags, territory, season, palette, form code, blueprint/prompt data, generated render image, and review-related EVS fields.

For the integrated owner workflow, the compatible production path is: create a Studio concept from a memory and creative direction; compile a structured product-render prompt using Moodoor’s wreath, camera, lighting, and negative-space conventions; generate the render server-side; store the approved render as managed media; and publish it into an editable catalog product rather than writing to browser storage.

The integrated Studio will not execute the uploaded client-side key handling or local-storage code. It will use the project’s protected server procedures, authenticated owner role, managed storage, and preconfigured image-generation service instead.

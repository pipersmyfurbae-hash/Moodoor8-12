# Moodoor Inventory Source Audit

The complete archive contains a source inventory file at `moodoor-inventory.json` using schema `EFS-1.0`. It has top-level metadata including `generated_at`, `species_count`, `sku_count_total`, and `register_gaps`.

Each `species` record contains `canon_id`, `species`, emotional metadata (`primary_emotion`, `secondary_emotion`, and `wheel_sector`), `intensity_range`, `texture_archetype`, `seasonality`, `register_gap`, and a nested `skus` array.

Each nested SKU contains `sku`, `color_name`, `hex`, `price`, `primary_role`, `qty_on_hand`, and `recommended_qty_24in`. The inventory importer must flatten these nested SKU records while retaining the species-level material and emotional metadata. It should also accept a direct array of SKU-like JSON records and a CSV with equivalent headers.

## Reveal Reference

The complete archive provides an original `product-reveal.jpg` reference rather than an executable Reveal component. Its intended reveal interaction is an archival product composition: a restrained header and breadcrumb line, a generous parchment-like blueprint stage, a limited-run badge, blueprint/version metadata, and small emotion-score labels such as nostalgia and warmth. The restored Reveal page should therefore draw only from approved Studio renders and public catalog/drop records, retaining these source-backed visual states while avoiding invented product claims or customer content.

# Original Moodoor Module Mapping

| Original module | Current Moodoor route or owner workspace |
|---|---|
| Moodoor | Public homepage at `/` |
| Moodoor How It Works | Memory matching explanation at `/how-it-works` |
| Moodoor Studio | Owner Studio at `/admin?tab=studio` |
| Moodoor Brief Generator | Moodoor OS → **Brief Generator** at `/admin?tab=workspace` |
| Moodoor Collection Intelligence | Moodoor OS → **Run Collection Intelligence** |
| Moodoor Collection Engine | Moodoor OS → **Build a connected collection**, creating an editable bundle and pipeline record |
| Moodoor Stories Studio | Moodoor OS → **Stories Studio** |
| Moodoor Story Genesis | Saved-story **Story Genesis** action in Stories Studio |
| Moodoor Lifestyle Story | Stories Studio type **lifestyle**, published to `/stories` |
| Moodoor Stories | Public story archive at `/stories` |
| Moodoor Homepage Lookbook | Stories Studio type **lookbook**, published to `/lookbook` |
| Moodoor Quality Control | Moodoor OS → **Quality Control** gate |
| Moodoor Operator Console | Moodoor OS → **Operator Console** |
| moodoor-pipeline-bundled / Moodoor Pipeline Dashboard | Moodoor OS → **Pipeline Dashboard** metrics and pipeline operations |
| Moodoor Experience Orchestration | Moodoor OS → **Experience Orchestration**, linking story, product, and drop |
| Moodoor Drop — When Winter Wakes | Moodoor OS → **Launch-drop management**, creating an actual seasonal-drop record |
| Original Maker Studio / Artisan Canvas | Reconciled through protected **Studio** generation, catalog publication, and the Moodoor OS Collection Engine |
| Original Atelier Locator | Retained as a planned customer-facing location surface; it has no corresponding supplied operational dataset in the archive. |

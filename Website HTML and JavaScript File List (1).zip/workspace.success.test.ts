import { describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  getAdminContentOverview: vi.fn(), getMoodoorBriefBySlug: vi.fn(), getMoodoorInventory: vi.fn(), getMoodoorInventoryBySku: vi.fn(), getMoodoorStoryBySlug: vi.fn(), getMoodoorWorkspaceOverview: vi.fn(), getPublicContentOverview: vi.fn(), getPublishedMoodoorStories: vi.fn(), getStudioConceptBySlug: vi.fn(), getStudioConcepts: vi.fn(), removeBundle: vi.fn(), removeCatalogProduct: vi.fn(), removeDrop: vi.fn(), removeMoodoorBrief: vi.fn(), removeMoodoorInventoryItem: vi.fn(), removeMoodoorOperation: vi.fn(), removeMoodoorQualityCheck: vi.fn(), removeMoodoorStory: vi.fn(), removeTerritory: vi.fn(), saveBundle: vi.fn(), saveCatalogProduct: vi.fn(), saveDrop: vi.fn(), saveMoodoorBrief: vi.fn(), saveMoodoorInventoryItem: vi.fn(), saveMoodoorOperation: vi.fn(), saveMoodoorQualityCheck: vi.fn(), saveMoodoorStory: vi.fn(), saveSiteContent: vi.fn(), saveStudioConcept: vi.fn(), saveTerritory: vi.fn(), storagePut: vi.fn(), generateImage: vi.fn(),
}));

vi.mock("./db", () => mocks);
vi.mock("./storage", () => ({ storagePut: mocks.storagePut }));
vi.mock("./_core/imageGeneration", () => ({ generateImage: mocks.generateImage }));

import { appRouter } from "./routers";

function adminContext(): TrpcContext {
  return { user: { id: 7, openId: "moodoor-owner", email: "owner@example.com", name: "Owner", loginMethod: "manus", role: "admin", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("Moodoor workspace success paths", () => {
  it("returns launch-operation records through the public content overview API", async () => {
    const caller = appRouter.createCaller(adminContext());
    mocks.getPublicContentOverview.mockResolvedValue({ siteContent: [], products: [], bundles: [], territories: [], drops: [], launchOperations: [{ linkedDropSlug: "when-winter-wakes", status: "active", summary: "Release window open", ownerNote: null }] });
    await expect(caller.content.publicOverview()).resolves.toMatchObject({ launchOperations: [{ linkedDropSlug: "when-winter-wakes", status: "active" }] });
  });

  it("saves and analyzes a source-backed Brief Generator record", async () => {
    const caller = appRouter.createCaller(adminContext());
    mocks.saveMoodoorBrief.mockResolvedValue(undefined);
    const brief = { id: 1, slug: "winter-wakes", title: "When Winter Wakes", sourceMemory: "The first quiet morning after frost", season: "Winter", territory: "Seasonal Ritual", collectionName: "When Winter Wakes", palette: "cedar, parchment, frost", materials: "cedar, hellebore, lichen", collectionInsight: null, collectionPlan: null, status: "draft", createdBy: 7, updatedBy: 7, createdAt: new Date(), updatedAt: new Date() };
    await expect(caller.workspace.saveBrief({ slug: "winter-wakes", title: "When Winter Wakes", sourceMemory: brief.sourceMemory, season: brief.season, territory: brief.territory, collectionName: brief.collectionName, palette: brief.palette, materials: brief.materials, collectionInsight: null, collectionPlan: null, status: "draft" })).resolves.toEqual({ success: true });
    expect(mocks.saveMoodoorBrief).toHaveBeenCalledWith(expect.objectContaining({ createdBy: 7, updatedBy: 7, slug: "winter-wakes" }));
    mocks.getMoodoorBriefBySlug.mockResolvedValue(brief);
    await expect(caller.workspace.analyzeBrief({ slug: "winter-wakes" })).resolves.toMatchObject({ success: true, insight: expect.stringContaining("When Winter Wakes"), plan: expect.stringContaining("Hero wreath") });
    expect(mocks.saveMoodoorBrief).toHaveBeenLastCalledWith(expect.objectContaining({ status: "analyzed", collectionPlan: expect.stringContaining("Drop sequence") }));
  });

  it("persists story, quality-control, and operator/pipeline records as the owner", async () => {
    const caller = appRouter.createCaller(adminContext());
    mocks.saveMoodoorStory.mockResolvedValue(undefined); mocks.saveMoodoorQualityCheck.mockResolvedValue(undefined); mocks.saveMoodoorOperation.mockResolvedValue(undefined);
    await expect(caller.workspace.saveStory({ slug: "winter-field-note", kind: "lifestyle", title: "Winter Field Note", eyebrow: "Moodoor Lifestyle Story", excerpt: "A quiet note", body: "A longer story", imageUrl: null, imageKey: null, linkedProductSlug: null, linkedDropSlug: "when-winter-wakes", isPublished: true, sortOrder: 0 })).resolves.toEqual({ success: true });
    await expect(caller.workspace.saveQualityCheck({ slug: "winter-quality", title: "Winter quality gate", studioConceptSlug: "winter-wakes", productSlug: null, status: "passed", compositionScore: 92, materialScore: 88, commerceScore: 90, notes: "Ready to release", reviewedBy: "Owner" })).resolves.toEqual({ success: true });
    await expect(caller.workspace.saveOperation({ slug: "winter-drop", title: "Moodoor Drop — When Winter Wakes", module: "drop", status: "active", summary: "Prepare launch", ownerNote: "Publish story first", linkedBriefSlug: "winter-wakes", linkedStorySlug: "winter-field-note", linkedProductSlug: null, linkedDropSlug: "when-winter-wakes", dueAt: null })).resolves.toEqual({ success: true });
    expect(mocks.saveMoodoorStory).toHaveBeenCalledWith(expect.objectContaining({ isPublished: true, publishedAt: expect.any(Date), createdBy: 7 }));
    expect(mocks.saveMoodoorQualityCheck).toHaveBeenCalledWith(expect.objectContaining({ status: "passed", checkedAt: expect.any(Date), compositionScore: 92 }));
    expect(mocks.saveMoodoorOperation).toHaveBeenCalledWith(expect.objectContaining({ module: "drop", status: "active", linkedBriefSlug: "winter-wakes" }));
  });

  it("generates and persists a Story Genesis narrative from a saved story record", async () => {
    const caller = appRouter.createCaller(adminContext());
    mocks.getMoodoorStoryBySlug.mockResolvedValue({ id: 2, slug: "winter-field-note", kind: "lifestyle", title: "Winter Field Note", eyebrow: null, excerpt: "The first quiet morning after frost", body: null, imageUrl: null, imageKey: null, linkedProductSlug: null, linkedDropSlug: "when-winter-wakes", isPublished: false, sortOrder: 0, createdBy: 7, updatedBy: 7, publishedAt: null, createdAt: new Date(), updatedAt: new Date() });
    mocks.saveMoodoorStory.mockResolvedValue(undefined);
    await expect(caller.workspace.generateStoryGenesis({ slug: "winter-field-note" })).resolves.toMatchObject({ success: true, eyebrow: "Moodoor Stories", body: expect.stringContaining("What it carries") });
    expect(mocks.saveMoodoorStory).toHaveBeenCalledWith(expect.objectContaining({ slug: "winter-field-note", body: expect.stringContaining("The open arc is not absence") }));
  });

  it("creates connected Collection Engine, seasonal-drop, and Experience Orchestration records", async () => {
    const caller = appRouter.createCaller(adminContext());
    mocks.getMoodoorBriefBySlug.mockResolvedValue({ id: 1, slug: "winter-wakes", title: "When Winter Wakes", sourceMemory: "Frost morning", season: "Winter", territory: "Seasonal Ritual", collectionName: "When Winter Wakes", palette: "cedar", materials: "cedar", collectionInsight: "A collection plan", collectionPlan: "A plan", status: "analyzed", createdBy: 7, updatedBy: 7, createdAt: new Date(), updatedAt: new Date() });
    mocks.saveBundle.mockResolvedValue(undefined); mocks.saveDrop.mockResolvedValue(undefined); mocks.saveMoodoorOperation.mockResolvedValue(undefined);
    await expect(caller.workspace.buildCollectionEngine({ briefSlug: "winter-wakes", price: 440, productSlugs: ["frost-arc"], launchDropSlug: "when-winter-wakes", isPublished: true, sortOrder: 0 })).resolves.toEqual({ success: true, bundleSlug: "winter-wakes-collection" });
    await expect(caller.workspace.createLaunchDrop({ slug: "when-winter-wakes", title: "Moodoor Drop — When Winter Wakes", timingLabel: "Winter 2026", status: "next", lede: "A winter release", description: null, tagSlugs: ["winter-wakes"], finishedRunCount: 4, blueprintCount: 2, isPublished: true, sortOrder: 0, linkedBriefSlug: "winter-wakes" })).resolves.toEqual({ success: true, dropSlug: "when-winter-wakes" });
    await expect(caller.workspace.orchestrateExperience({ slug: "winter-journey", title: "Winter customer journey", summary: "Story to product to drop", storySlug: "winter-field-note", productSlug: "frost-arc", dropSlug: "when-winter-wakes", status: "active" })).resolves.toEqual({ success: true });
    expect(mocks.saveBundle).toHaveBeenCalledWith(expect.objectContaining({ slug: "winter-wakes-collection", productSlugsJson: "[\"frost-arc\"]", isPublished: true }));
    expect(mocks.saveDrop).toHaveBeenCalledWith(expect.objectContaining({ slug: "when-winter-wakes", status: "next", isPublished: true }));
    expect(mocks.saveMoodoorOperation).toHaveBeenCalledWith(expect.objectContaining({ module: "pipeline", linkedBriefSlug: "winter-wakes", linkedProductSlug: "frost-arc", linkedDropSlug: "when-winter-wakes" }));
    expect(mocks.saveMoodoorOperation).toHaveBeenLastCalledWith(expect.objectContaining({ module: "experience", linkedStorySlug: "winter-field-note", linkedProductSlug: "frost-arc", linkedDropSlug: "when-winter-wakes" }));
  });

  it("imports original EFS inventory and allows an owner to update an existing SKU quantity", async () => {
    const caller = appRouter.createCaller(adminContext());
    mocks.saveMoodoorInventoryItem.mockResolvedValue(undefined);
    const sourceText = JSON.stringify({ species: [{ canon_id: "SPX-DAHLIA", species: "Amber Dahlia", primary_emotion: "joy", skus: [{ sku: "MD-0001", color_name: "Rust", qty_on_hand: 31, price: 14.26, primary_role: "accent", recommended_qty_24in: 7 }] }] });
    await expect(caller.inventory.import({ sourceText, format: "json" })).resolves.toMatchObject({ success: true, imported: 1, sourceRows: 1, duplicateSkus: 0 });
    expect(mocks.saveMoodoorInventoryItem).toHaveBeenCalledWith(expect.objectContaining({ sku: "MD-0001", species: "Amber Dahlia", qtyOnHand: 31, unitPrice: "14.26", createdBy: 7 }));
    mocks.getMoodoorInventoryBySku.mockResolvedValue({ sku: "MD-0001", canonId: "SPX-DAHLIA", species: "Amber Dahlia", colorName: "Rust", colorHex: null, primaryRole: "accent", qtyOnHand: 31, recommendedQty24in: 7, unitPrice: "14.26", seasonality: null, primaryEmotion: "joy", secondaryEmotion: null, wheelSector: null, textureArchetype: null, isRegisterGap: false, lowStockThreshold: 5, notes: null, createdBy: 7, updatedBy: 7, createdAt: new Date(), updatedAt: new Date() });
    await expect(caller.inventory.updateQuantity({ sku: "MD-0001", qtyOnHand: 12, lowStockThreshold: 4, notes: "Reserve for winter" })).resolves.toEqual({ success: true });
    expect(mocks.saveMoodoorInventoryItem).toHaveBeenLastCalledWith(expect.objectContaining({ sku: "MD-0001", qtyOnHand: 12, lowStockThreshold: 4, notes: "Reserve for winter", updatedBy: 7 }));
  });

  it("turns a pasted blueprint JSON object into an editable Story Genesis draft", async () => {
    const caller = appRouter.createCaller(adminContext());
    await expect(caller.workspace.blueprintToStory({ blueprintJson: JSON.stringify({ title: "Winter Wakes", memory: "The first quiet morning after frost", palette: "cedar, parchment", materials: "cedar, hellebore", construction: "an open right-side arc", productSlug: "winter-wakes", dropSlug: "when-winter-wakes" }) })).resolves.toMatchObject({ success: true, story: { slug: "winter-wakes", kind: "studio", linkedProductSlug: "winter-wakes", linkedDropSlug: "when-winter-wakes", body: expect.stringContaining("open arc") }, extracted: { title: "Winter Wakes", palette: "cedar, parchment" } });
  });

  it("publishes a blueprint-generated story through the public Moodoor Stories handoff", async () => {
    const caller = appRouter.createCaller(adminContext());
    mocks.saveMoodoorStory.mockResolvedValue(undefined);
    const generated = await caller.workspace.blueprintToStory({ blueprintJson: JSON.stringify({ title: "Winter Blueprint Story", memory: "A published field note", materials: "cedar, hellebore", construction: "an open arc", productSlug: "winter-wakes" }) });
    await expect(caller.workspace.saveStory({ ...generated.story, isPublished: true })).resolves.toEqual({ success: true });
    expect(mocks.saveMoodoorStory).toHaveBeenLastCalledWith(expect.objectContaining({ slug: "winter-blueprint-story", isPublished: true, publishedAt: expect.any(Date), linkedProductSlug: "winter-wakes" }));
    mocks.getPublishedMoodoorStories.mockResolvedValue([{ ...generated.story, isPublished: true }]);
    await expect(caller.workspace.publicStories()).resolves.toMatchObject([{ slug: "winter-blueprint-story", isPublished: true, title: "Winter Blueprint Story" }]);
  });
});

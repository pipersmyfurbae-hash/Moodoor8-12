import { describe, expect, it } from "vitest";
import { decodeBlueprintData, decodeImageData } from "./routers";

describe("content image validation", () => {
  it("accepts a valid PNG signature encoded in a data URL", () => {
    const bytes = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
    const result = decodeImageData(`data:image/png;base64,${bytes.toString("base64")}`);
    expect(result.mimeType).toBe("image/png");
    expect(result.extension).toBe("png");
  });

  it("rejects data that does not match the declared image type", () => {
    const data = Buffer.from("not an image").toString("base64");
    expect(() => decodeImageData(`data:image/png;base64,${data}`)).toThrow("does not match");
  });
});

describe("blueprint document validation", () => {
  it("accepts a PDF whose data header and file signature agree", () => {
    const bytes = Buffer.from("%PDF-1.7\n% Moodoor blueprint");
    const result = decodeBlueprintData(`data:application/pdf;base64,${bytes.toString("base64")}`);
    expect(result.mimeType).toBe("application/pdf");
    expect(result.bytes.subarray(0, 5).toString("ascii")).toBe("%PDF-");
  });

  it("rejects a file that claims to be a PDF but has no PDF signature", () => {
    const data = Buffer.from("not a blueprint").toString("base64");
    expect(() => decodeBlueprintData(`data:application/pdf;base64,${data}`)).toThrow("does not match");
  });
});

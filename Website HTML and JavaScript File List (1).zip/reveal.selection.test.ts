import { describe, expect, it } from "vitest";
import { selectRevealDrop, selectRevealProduct } from "../client/src/lib/revealSelection";

describe("public Reveal selection", () => {
  it("selects an in-stock catalog render and skips records with no image or availability", () => {
    const selected = selectRevealProduct([
      { inventoryQuantity: 0, runLimit: 5, heroImageUrl: "/sold-out.jpg" },
      { inventoryQuantity: 3, runLimit: 5, heroImageUrl: null, listingImageUrl: null },
      { inventoryQuantity: 2, runLimit: 5, listingImageUrl: "/approved-render.jpg" },
    ]);
    expect(selected).toMatchObject({ listingImageUrl: "/approved-render.jpg" });
  });

  it("prioritizes a live drop, falls back to next, and ignores planned or archived records", () => {
    expect(selectRevealDrop([{ status: "next" }, { status: "live" }, { status: "archived" }])).toMatchObject({ status: "live" });
    expect(selectRevealDrop([{ status: "planned" }, { status: "archived" }])).toBeNull();
  });
});

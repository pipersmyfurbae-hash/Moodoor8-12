import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function nonAdminContext(): TrpcContext {
  return {
    user: {
      id: 42,
      openId: "content-editor-without-admin-role",
      email: "editor@example.com",
      name: "Editor",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("content administration authorization", () => {
  it("denies a non-admin before it can list protected content", async () => {
    const caller = appRouter.createCaller(nonAdminContext());
    await expect(caller.content.adminOverview()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("denies a non-admin before it can save page content or upload an image", async () => {
    const caller = appRouter.createCaller(nonAdminContext());
    await expect(caller.content.saveSiteContent({ contentKey: "home-hero", label: "Homepage hero", heading: "New title", body: "New copy", imageUrl: null, imageKey: null, altText: null })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.content.uploadImage({ dataUrl: "data:image/png;base64,iVBORw0KGgo=", filename: "hero.png" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("denies a non-admin before it can manage collections, stock-bearing products, or blueprint assets", async () => {
    const caller = appRouter.createCaller(nonAdminContext());
    await expect(caller.content.saveProduct({ slug: "test-wreath", name: "Test Wreath", territory: "Comfort", lede: null, description: null, price: 100, blueprintCode: null, listingImageUrl: null, listingImageKey: null, heroImageUrl: null, heroImageKey: null, inventoryQuantity: 1, runLimit: 5, blueprintPrice: 39, blueprintAssetUrl: null, blueprintAssetKey: null, blueprintFilename: null, blueprintMimeType: null, isPublished: false, sortOrder: 0 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.content.saveBundle({ slug: "test-bundle", name: "Test Bundle", territory: "Comfort", price: 100, saving: null, lede: null, productSlugs: [], tone: "olive", imageUrl: null, imageKey: null, isPublished: false, sortOrder: 0 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.content.saveTerritory({ slug: "test-territory", name: "Test Territory", description: null, designCount: 0, tone: "olive", imageUrl: null, imageKey: null, isPublished: false, sortOrder: 0 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.content.saveDrop({ slug: "test-drop", title: "Test Drop", timingLabel: "Soon", status: "planned", lede: null, description: null, tagSlugs: [], finishedRunCount: 0, blueprintCount: 0, imageUrl: null, imageKey: null, launchAt: null, isPublished: false, sortOrder: 0 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.content.uploadBlueprint({ dataUrl: "data:application/pdf;base64,JVBERi0xLjQ=", filename: "test.pdf" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});

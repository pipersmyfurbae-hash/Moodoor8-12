CREATE TABLE `catalog_bundles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(100) NOT NULL,
	`name` varchar(180) NOT NULL,
	`territory` varchar(140) NOT NULL,
	`price` decimal(10,2) NOT NULL DEFAULT '0.00',
	`saving` varchar(180),
	`lede` text,
	`productSlugsJson` text,
	`tone` varchar(24) NOT NULL DEFAULT 'olive',
	`imageUrl` text,
	`imageKey` varchar(512),
	`isPublished` boolean NOT NULL DEFAULT true,
	`sortOrder` int NOT NULL DEFAULT 0,
	`updatedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `catalog_bundles_id` PRIMARY KEY(`id`),
	CONSTRAINT `catalog_bundles_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `catalog_territories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(100) NOT NULL,
	`name` varchar(140) NOT NULL,
	`description` text,
	`designCount` int NOT NULL DEFAULT 0,
	`tone` varchar(24) NOT NULL DEFAULT 'olive',
	`imageUrl` text,
	`imageKey` varchar(512),
	`isPublished` boolean NOT NULL DEFAULT true,
	`sortOrder` int NOT NULL DEFAULT 0,
	`updatedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `catalog_territories_id` PRIMARY KEY(`id`),
	CONSTRAINT `catalog_territories_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `seasonal_drops` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(100) NOT NULL,
	`title` varchar(180) NOT NULL,
	`timingLabel` varchar(140) NOT NULL,
	`status` enum('planned','next','live','archived') NOT NULL DEFAULT 'planned',
	`lede` text,
	`description` text,
	`tagSlugsJson` text,
	`finishedRunCount` int NOT NULL DEFAULT 0,
	`blueprintCount` int NOT NULL DEFAULT 0,
	`imageUrl` text,
	`imageKey` varchar(512),
	`launchAt` timestamp,
	`isPublished` boolean NOT NULL DEFAULT true,
	`sortOrder` int NOT NULL DEFAULT 0,
	`updatedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `seasonal_drops_id` PRIMARY KEY(`id`),
	CONSTRAINT `seasonal_drops_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `catalog_products` ADD `inventoryQuantity` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `catalog_products` ADD `runLimit` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `catalog_products` ADD `blueprintPrice` decimal(10,2) DEFAULT '39.00' NOT NULL;--> statement-breakpoint
ALTER TABLE `catalog_products` ADD `blueprintAssetUrl` text;--> statement-breakpoint
ALTER TABLE `catalog_products` ADD `blueprintAssetKey` varchar(512);--> statement-breakpoint
ALTER TABLE `catalog_products` ADD `blueprintFilename` varchar(180);--> statement-breakpoint
ALTER TABLE `catalog_products` ADD `blueprintMimeType` varchar(100);
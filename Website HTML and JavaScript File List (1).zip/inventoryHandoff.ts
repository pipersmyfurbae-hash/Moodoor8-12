export const INVENTORY_HANDOFF_KEYS = {
  studio: "moodoor.inventory.materials.forStudio",
  brief: "moodoor.inventory.materials.forBrief",
} as const;

type InventoryHandoffTarget = keyof typeof INVENTORY_HANDOFF_KEYS;
type StorageAdapter = Pick<Storage, "getItem" | "removeItem" | "setItem">;

export function storeInventoryHandoff(storage: StorageAdapter, target: InventoryHandoffTarget, materials: string) {
  storage.setItem(INVENTORY_HANDOFF_KEYS[target], materials);
}

export function consumeInventoryHandoff(storage: StorageAdapter, target: InventoryHandoffTarget) {
  const materials = storage.getItem(INVENTORY_HANDOFF_KEYS[target]);
  if (materials) storage.removeItem(INVENTORY_HANDOFF_KEYS[target]);
  return materials;
}

export function applyInventoryToStudio(existingFoliage: string, materials: string) {
  return {
    focalFlorals: materials,
    foliage: `${existingFoliage}${existingFoliage ? "; " : ""}Selected from Moodoor Inventory`,
  };
}

export function applyInventoryToBrief(materials: string) { return { materials }; }

import { readFile } from "node:fs/promises";
import { appRouter } from "../server/routers.ts";

const sourceText = await readFile("/home/ubuntu/upload/moodoor-inventory.json", "utf8");
const caller = appRouter.createCaller({
  user: {
    id: 1,
    openId: "owner-verification",
    name: "Owner",
    email: "owner@example.com",
    loginMethod: "verification",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  },
  req: { protocol: "https", headers: {} },
  res: {},
});

const imported = await caller.inventory.import({ sourceText, format: "json" });
const items = await caller.inventory.list();
console.log(JSON.stringify({ ...imported, inventoryRecordCount: items.length }, null, 2));
process.exit(0);

# Moodoor Storefront — Design Directions

## Three possible directions

### 1. The Memory Archive

**Very Brief Intro:** A quiet botanical archive where every wreath is treated as a physical keepsake and every product page reads like a found record. Warm paper, deep forest ink, and patient editorial composition turn browsing into recollection.

**Probability:** 0.07

### 2. The Florist’s Worktable

**Very Brief Intro:** An open-studio direction that foregrounds material, process, and arranging tools. It is tactile, bright, and observant, balancing informal workbench energy with clear premium product hierarchy.

**Probability:** 0.04

### 3. The Seasonal House

**Very Brief Intro:** A more domestic, light-filled approach built from rooms, thresholds, shadows, and changing seasons. Wreaths become small architectural gestures for a home rather than conventional décor products.

**Probability:** 0.09

---

## Chosen direction: The Memory Archive

### Design Movement

**Contemporary botanical editorial** informed by archival stationery, museum catalogues, and restrained European floral studios. The result should feel collected rather than decorated: a store whose visual language respects memory as the source material for design.

### Core Principles

1. **Memory before merchandise:** Product language begins with the feeling behind a design, then introduces material and purchase details.
2. **Asymmetry with restraint:** Editorial crops, off-axis blocks, and staggered pacing replace generic centered rows and equal cards.
3. **Tactile quiet:** Paper grain, painted plaster, linen, preserved florals, and fine rules create depth without visual noise.
4. **Traceable craft:** Blueprint identifiers, emotional markers, and construction notes make the collection feel deliberate and legible.

### Color Philosophy

The site starts from **archival off-white** and **warm paper** so content feels like a collected note rather than an interface. **Moodoor Olive** is the intellectual and emotional anchor: it suggests quiet permanence, not generic eco-branding. Charcoal gives the editorial spreads weight, while an amber note is reserved for specificity, a small point of warmth, or a design’s focal accent.

### Layout Paradigm

The primary structure follows a **sequence of folios** rather than a conventional centered grid. Sections alternate between expansive copy fields, close-cropped botanical evidence, full-bleed dark archive panels, and uneven product shelves. The homepage begins as a memory intake, then opens into the collection as though progressing through a box of carefully labelled records.

### Signature Elements

1. **The Door-Wreath mark:** A continuous wreath arc framing a doorway, used as the favicon, navigation mark, section seal, and lightweight loading device.
2. **Archive labels:** Tiny uppercase metadata such as territory, run, and blueprint code that sit beside large serif product names.
3. **Preserved openings:** Deliberate quiet gaps in layouts, illustrated wreath rings, and image crops to mirror the negative space essential to the product designs.

### Interaction Philosophy

Interaction should feel like handling a collection rather than operating a dashboard. Links underline from a fine olive rule, products rise gently from their paper fields, and the cart appears as a calm editorial drawer. The memory prompt is active and personal: a submitted prompt creates an understandable local match rather than pretending to perform unavailable analysis.

### Animation

Elements enter in restrained folio-like sequences: opacity from 0 to 1 combined with a 16–24px upward translation over 420–600ms using a clear ease-out. Image crops and product cards respond on hover with only a small vertical shift and subtle image scaling. The door-wreath emblem may drift only on rare, low-attention moments. Motion is disabled under `prefers-reduced-motion` and no animation delays the response to navigation, cart, or keyboard input.

### Typography System

**Cormorant Garamond** serves as the display serif for memory statements and product names, set at large, tightly led proportions. **Manrope** supplies the readable body voice, with compact all-caps metadata set in **DM Mono**. The hierarchy is intentionally dramatic: generous display text, quiet body prose, and small factual labels.

### Brand Essence

**Moodoor turns personal memories into materially precise wreaths and buildable floral blueprints for people who want their home to hold a feeling.**

**Personality:** reflective, considered, grounded.

### Brand Voice

Headlines should be short, sensory, and unforced; CTAs should describe an invitation or next gesture rather than employ generic conversion language. Microcopy should supply useful context in calm, factual sentences.

> “Tell us the memory. We’ll show you the wreath that holds it.”

> “A finished piece for the door—or the exact plan to make it yourself.”

### Wordmark & Logo

The **Moodoor** wordmark combines high-contrast serif letterforms with an opening in the second “o” that quietly resembles a threshold. It is paired with a separate **Door-Wreath** symbol: an arch defined by a continuous botanical arc. The symbol, never a tiny default icon, is used prominently in the header and as the favicon.

### Signature Brand Color

**Moodoor Olive — `#4A6741`**. This is the visual constant across launch, product, cart, archive, and interface states.

## Style Decisions

- Keep the source catalog’s product names, pricing, territories, and blueprint-backed positioning intact.
- Do not present demo ratings, testimonials, or unverified social proof.
- Use client-side browser storage for the current cart; the checkout is a clearly labelled prototype until commerce infrastructure is connected.
- Make every route reachable from the global header, footer, product links, or a clear back path.
- Product listing pages are uneven archive shelves, not uniform ecommerce grids; varied folio scale and pacing should remain visible.
- Every major shopping route pairs blueprint logic with tactile botanical evidence: finished wreaths, florals, paper, stems, and studio shadows.
- Treat the Door-Wreath symbol as a primary, independently recognisable brand device in navigation, folios, and the footer.

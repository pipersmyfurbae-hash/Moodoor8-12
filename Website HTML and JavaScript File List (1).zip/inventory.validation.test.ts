import { describe, expect, it } from "vitest";
import { parseInventoryImport } from "./routers";

describe("inventory import validation", () => {
  it("parses flat CSV records using the documented source-compatible headers", () => {
    const rows = parseInventoryImport("sku,species,color_name,qty_on_hand,primary_role,price\nMD-1001,White Rosebud,Cream,8,focal,12.5", "csv");
    expect(rows).toEqual([expect.objectContaining({ sku: "MD-1001", species: "White Rosebud", colorName: "Cream", qtyOnHand: 8, primaryRole: "focal", unitPrice: "12.50" })]);
  });

  it("normalizes nested supplier inventories, alternate fields, and a UTF-8 CSV BOM", () => {
    const nested = { inventory: { materials: [{ product_code: "SUP-101", botanical_name: "Paperwhite Narcissus", available_quantity: "12", role: "focal", unit_cost: "8.5" }] } };
    expect(parseInventoryImport(JSON.stringify(nested), "json")).toEqual([expect.objectContaining({ sku: "SUP-101", species: "Paperwhite Narcissus", qtyOnHand: 12, primaryRole: "focal", unitPrice: "8.50" })]);
    expect(parseInventoryImport("\uFEFFproduct_code,botanical_name,available_quantity\nSUP-102,White Ranunculus,9", "csv")).toEqual([expect.objectContaining({ sku: "SUP-102", species: "White Ranunculus", qtyOnHand: 9 })]);
  });

  it("preserves long source descriptions from the supplied EFS metadata", () => {
    const source = { species: [{ canon_id: "46", species: "Bittersweet", wheel_sector: "mixed register (warmth + wistfulness) — not cross-checked against emotion-wheel-taxonomy.md, verify before treating as final", texture_archetype: "trailing vine, clustered orange-toned berry pods, textural and directional", seasonality: "fall", skus: [{ sku: "BTTSWSP", color_name: "Bittersweet Orange", qty_on_hand: 5000, primary_role: "secondary", price: 7.25 }] }] };
    expect(parseInventoryImport(JSON.stringify(source), "json")).toEqual([expect.objectContaining({ sku: "BTTSWSP", wheelSector: source.species[0].wheel_sector, textureArchetype: source.species[0].texture_archetype })]);
  });

  it("keeps source order so repeated SKUs can be deterministically refreshed by the import procedure", () => {
    const rows = parseInventoryImport(JSON.stringify([{ sku: "MD-2001", species: "Seeded Eucalyptus", qty_on_hand: 4 }, { sku: "MD-2001", species: "Seeded Eucalyptus", qty_on_hand: 9 }]), "json");
    expect(rows).toHaveLength(2);
    expect(rows.at(-1)).toMatchObject({ sku: "MD-2001", qtyOnHand: 9 });
  });

  it("rejects malformed JSON and incomplete inventory rows", () => {
    expect(() => parseInventoryImport("{not JSON}", "json")).toThrow("invalid");
    expect(() => parseInventoryImport(JSON.stringify([{ sku: "MD-1002" }]), "json")).toThrow(/SKU and species/i);
  });
});

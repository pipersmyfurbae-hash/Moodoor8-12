import { describe, expect, it } from "vitest";
import { compileBlueprintStory } from "./routers";

describe("blueprint story validation", () => {
  it("rejects malformed JSON and valid JSON without an accepted title field", () => {
    expect(() => compileBlueprintStory("{not valid}")).toThrow("valid JSON");
    expect(() => compileBlueprintStory(JSON.stringify({ palette: "olive" }))).toThrow("Add a title");
  });
});

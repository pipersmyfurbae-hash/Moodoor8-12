/**
 * MOODOOR / THE MEMORY ARCHIVE
 * The homepage is a sequence of folios: memory intake, emotional territories, then traceable ways to collect a design.
 */
import { WreathArt } from "@/components/WreathArt";
import { useStorefrontContent } from "@/contexts/StorefrontContentContext";
import { territories, wreaths } from "@/lib/catalog";
import { ArrowRight, Check } from "lucide-react";
import { FormEvent, useState } from "react";
import { Link, useLocation } from "wouter";

export default function Home() {
  const [, setLocation] = useLocation();
  const { getPage } = useStorefrontContent();
  const [memory, setMemory] = useState("");
  const [joined, setJoined] = useState(false);
  const hero = getPage("home-hero");
  const heroHeading = hero?.heading?.trim();
  const heroBody = hero?.body?.trim() || "Moodoor matches a memory to a curated library of blueprint-backed botanical wreaths. Every design has a feeling, a story, and an exact way it can be built.";
  const heroImage = hero?.imageUrl || "/manus-storage/moodoor-hero-wreath_0e192f39.jpg";
  const goToMatch = (event: FormEvent) => { event.preventDefault(); setLocation(`/matching?memory=${encodeURIComponent(memory.trim())}`); };
  return <>
    <section className="home-hero">
      <div className="hero-sun" />
      <div className="shell-width hero-layout">
        <div className="hero-copy flow-reveal">
          <p className="eyebrow">A new way to choose a wreath</p>
          <h1>{heroHeading || <>Tell us the <em>memory.</em><br />We’ll show you the wreath that holds it.</>}</h1>
          <p className="hero-lede">{heroBody}</p>
          <form className="memory-card" onSubmit={goToMatch}>
            <label htmlFor="memory">Your memory</label>
            <textarea id="memory" value={memory} onChange={(event) => setMemory(event.target.value)} placeholder="My grandmother’s porch in late September — cedar, cold coffee, and the screen door that never quite closed…" />
            <div className="memory-card-foot"><span>A sentence is enough. A paragraph is better.</span><button className="button button-olive" type="submit">Find my wreath <ArrowRight size={15} /></button></div>
          </form>
          <div className="memory-chips">{["Sunday mornings at the lake house", "The year we finally came home", "Mom’s garden after the rain"].map((chip) => <button key={chip} onClick={() => setMemory(`${chip}…`)}>{chip}</button>)}</div>
          <p className="privacy-note">Browser-only matching prototype. Your words are not sent or stored by this site.</p>
        </div>
        <div className="hero-image-wrap"><img src={heroImage} alt={hero?.altText || "Moodoor botanical wreath"} /><span className="orbit-label o-one">warmth · 0.82</span><span className="orbit-label o-two">nostalgia · 0.91</span><span className="orbit-label o-three">restraint · 0.64</span></div>
      </div>
    </section>

    <section className="numbers-strip"><div className="shell-width stat-row"><Stat number="60" label="Curated designs, each profiled before it earns a place in the library" /><Stat number="6" label="Emotional territories, from comfort to seasonal nostalgia" /><Stat number="1:1" label="Every finished wreath traces to an exact, buildable blueprint" /></div></section>

    <section className="section shell-width"><div className="section-intro"><p className="eyebrow">How it works</p><h2>Three steps between a feeling <span className="script-accent">and a front door</span></h2></div><div className="step-sequence"><Step index="01" title="Share a memory" copy="A porch, a season, a person, a year. Write it as you would tell it to a friend. The memory is the brief." /><Step index="02" title="Read the feeling" copy="The prototype maps a few emotional signals from your words, then compares them to the library’s known design profiles." /><Step index="03" title="Choose the form" copy="See a finished signature wreath, its exact blueprint, or a collection of companion designs for a home." /></div><p className="centered-principle">AI interprets the emotion. <b>The design itself is deterministic.</b></p></section>

    <section className="territory-section"><div className="shell-width"><div className="section-intro"><p className="eyebrow">The library</p><h2>Six territories of feeling, <span className="script-accent">sixty designs</span></h2><p>Every design belongs somewhere emotionally. The library remains browsable if you would rather choose with your own eye.</p></div><div className="territory-mosaic">{territories.map(([name, description, count, tone], index) => <Link href={`/territories#${name.toLowerCase().replaceAll(" ", "-")}`} className={`territory-card ${tone} territory-${index + 1}`} key={name}><span>{count}</span><WreathArt tone={tone} simple /><h3>{name}</h3><p>{description}</p></Link>)}</div></div></section>

    <section className="section shell-width collection-spread"><div className="section-intro"><p className="eyebrow">Three ways to collect</p><h2>Order it finished. Build it yourself. <span className="script-accent">Or collect the story.</span></h2></div><div className="collection-rows">
      <CollectionRow image="/manus-storage/moodoor-signature-wreath_56dd3c73.jpg" kicker="Signature wreaths · from $295" title="A finished piece, made in a small numbered run." copy="Every stem follows a resolved blueprint; no second design language, no improvised version. The story and emotional profile arrive with the finished wreath." href="/wreaths" label="Browse signature wreaths" />
      <CollectionRow reverse image="/manus-storage/moodoor-blueprint-detail_b71c868c.jpg" kicker="Digital blueprints · $39" title="The exact recipe, yours to build." copy="Clock-position layouts, stem counts, layering order, materials, and the same construction logic used in the studio." href="/blueprints" label="Browse buildable designs" />
      <CollectionRow image="/manus-storage/moodoor-bundle-table_33243c11.jpg" kicker="Collection bundles · from $119" title="One feeling, carried through a home." copy="Three companion blueprints shaped by one palette and movement language, sized for doors, mantels, and interior walls." href="/bundles" label="See the collections" />
    </div></section>

    <section className="archive-panel"><div className="shell-width archive-grid"><div><p className="eyebrow">The blueprint system</p><h2>Every wreath begins as a blueprint, <em>not a vibe.</em></h2><p>Balance, rhythm, negative space, and silhouette are resolved on a polar clock grid before a single stem is placed. The document is the thing we build.</p><ul className="archive-list"><li><Check size={16} /> Specific placement, count, and order</li><li><Check size={16} /> A shared reference for every build</li><li><Check size={16} /> A blueprint you can take home</li></ul><Link href="/design-principles--blueprint-system" className="text-link">Read the blueprint notes <ArrowRight size={15} /></Link></div><div className="blueprint-preview"><div className="blueprint-topline"><span>MOODOOR / SYSTEM NOTE</span><span>BP-EC-0417</span></div><WreathArt tone="olive" /><div className="blueprint-rules"><span>focal · 10:30</span><span>stems · 23</span><span>space · preserved</span></div></div></div></section>

    <section className="waitlist-section"><div className="shell-width waitlist-layout"><div><p className="eyebrow">Small seasonal drops</p><h2>New designs arrive <span className="script-accent">in small seasons</span></h2><p>Receive a note when the library opens a fresh chapter. No promotional feed, only drop notices and studio stories.</p></div>{joined ? <p className="waitlist-success">You’re on the list. The next drop will find you first.</p> : <form className="waitlist-form" onSubmit={(event) => { event.preventDefault(); setJoined(true); }}><label className="sr-only" htmlFor="email">Email address</label><input id="email" type="email" required placeholder="you@example.com" /><button className="button button-olive">Keep me close</button><small>This prototype acknowledges the form locally; it does not submit email anywhere.</small></form>}</div></section>
  </>;
}

function Stat({ number, label }: { number: string; label: string }) { return <div className="stat"><strong>{number}</strong><span>{label}</span></div>; }
function Step({ index, title, copy }: { index: string; title: string; copy: string }) { return <article className="step-card"><span>{index}</span><h3>{title}</h3><p>{copy}</p></article>; }
function CollectionRow({ image, kicker, title, copy, href, label, reverse = false }: { image: string; kicker: string; title: string; copy: string; href: string; label: string; reverse?: boolean }) { return <article className={reverse ? "collection-row reverse" : "collection-row"}><div className="collection-image"><img src={image} alt="" /></div><div className="collection-copy"><p className="eyebrow">{kicker}</p><h3>{title}</h3><p>{copy}</p><Link href={href} className="text-link">{label} <ArrowRight size={15} /></Link></div></article>; }

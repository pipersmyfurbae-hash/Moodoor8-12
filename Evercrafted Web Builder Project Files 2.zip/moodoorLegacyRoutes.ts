import type { Express } from "express";
import { generateImage } from "./_core/imageGeneration";
import { makeRequest, PlacesSearchResult } from "./_core/map";
import { calculateSimilarity, critiqueComposition, deriveFallbackVector, interpretMemory } from "./moodoor";
import { registerMoodoorWaitlist, saveMoodoorMemory } from "./db";

const referenceVectors = [
  { id: "BP-EC-0417", vector: { warmth: .82, energy: .35, nostalgia: .91, valence: .58, intimacy: .78, restraint: .64, seasonal: .95 } },
  { id: "BP-EC-0422", vector: { warmth: .88, energy: .42, nostalgia: .87, valence: .65, intimacy: .72, restraint: .52, seasonal: .92 } },
  { id: "BP-EC-0431", vector: { warmth: .76, energy: .22, nostalgia: .94, valence: .48, intimacy: .86, restraint: .83, seasonal: .88 } },
  { id: "BP-EC-0447", vector: { warmth: .85, energy: .28, nostalgia: .66, valence: .72, intimacy: .74, restraint: .76, seasonal: .36 } },
  { id: "BP-EC-0468", vector: { warmth: .68, energy: .84, nostalgia: .34, valence: .92, intimacy: .61, restraint: .22, seasonal: .44 } },
  { id: "BP-EC-0484", vector: { warmth: .72, energy: .18, nostalgia: .65, valence: .80, intimacy: .72, restraint: .62, seasonal: .72 } },
];

const territoryName = (id: number) => ["Comfort", "Celebration", "Remembrance", "Renewal", "Connection", "Seasonal Nostalgia"][id - 1] ?? "Custom Artisanal";

export function registerMoodoorLegacyRoutes(app: Express) {
  app.post("/api/match", async (req, res) => {
    const memory = typeof req.body?.memory === "string" ? req.body.memory.trim() : "";
    if (!memory) return res.status(400).json({ error: "Memory text is required" });
    const interpreted = await interpretMemory(memory);
    const matches = referenceVectors.map((wreath) => ({ id: wreath.id, score: calculateSimilarity(interpreted.vector, wreath.vector), explanation: interpreted.explanation })).sort((first, second) => second.score - first.score).slice(0, 3);
    void saveMoodoorMemory({ memory, vector: interpreted.vector, explanation: interpreted.explanation });
    return res.json({ interpretedVector: interpreted.vector, explanation: interpreted.explanation, matches, isFallback: interpreted.isFallback });
  });

  app.post("/api/critique", async (req, res) => {
    const placements = Array.isArray(req.body?.placements) ? req.body.placements : [];
    const critique = await critiqueComposition({ territory: territoryName(Number(req.body?.targetTerritoryId)), notes: typeof req.body?.notes === "string" ? req.body.notes : "", placements });
    return res.json(critique);
  });

  app.post("/api/copilot-chat", async (req, res) => {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    const placements = Array.isArray(req.body?.placements) ? req.body.placements : [];
    const territory = territoryName(Number(req.body?.targetTerritoryId));
    if (!message) return res.status(400).json({ success: false, error: "A question is required." });
    const current = placements.length ? `${placements.length} placement${placements.length === 1 ? "" : "s"}` : "an open vine";
    return res.json({ success: true, text: `For a ${territory} composition, read ${current} as a starting rhythm rather than a finished answer. Keep one decisive focal movement, then let the remaining grapevine act as a counterweight; your question about “${message.slice(0, 90)}” is best answered by editing toward fewer, more intentional gestures.` });
  });

  app.post("/api/copilot-story", async (req, res) => {
    const type = req.body?.type === "poem" ? "poem" : "narrative";
    const territory = territoryName(Number(req.body?.targetTerritoryId));
    const notes = typeof req.body?.notes === "string" ? req.body.notes : "";
    const text = type === "poem"
      ? `A vine keeps one quiet arc\nfor the ${territory.toLowerCase()} you carried in.\nThe stems gather, then leave room\nfor what the room already knows.`
      : `This ${territory} composition is built as a small held landscape: a focal gathering, a gentler answering sweep, and enough exposed vine to let the memory breathe. ${notes ? "Its maker’s note remains in the work as a private source of direction." : "Its restraint keeps the story specific rather than decorative."}`;
    return res.json({ success: true, text });
  });

  app.post("/api/copilot-optimize", async (req, res) => {
    const placements = Array.isArray(req.body?.placements) ? req.body.placements : [];
    const actionType = req.body?.actionType;
    if (actionType === "autofill") {
      return res.json({ success: true, data: { explanation: "A small supporting sweep and a restrained counterweight give the focal area direction without closing the breathing channel.", itemsToAdd: [{ elementType: "Greenery Sweep", elementName: "Olive and cedar sweep", clockPosition: "10:30" }, { elementType: "Accent Stem", elementName: "Textural counterweight", clockPosition: "4:30" }] } });
    }
    const optimizedPlacements = placements.map((placement: any, index: number) => index === 1 ? { ...placement, clockPosition: "4:30" } : placement);
    return res.json({ success: true, data: { explanation: "The second gesture has been shifted to release the mirrored axis and create a slower diagonal conversation across the vine.", optimizedPlacements } });
  });

  app.post("/api/generate-image", async (req, res) => {
    try {
      const prompt = typeof req.body?.prompt === "string" ? req.body.prompt : "";
      if (!prompt.trim()) return res.status(400).json({ error: "A render prompt is required." });
      const image = await generateImage({ prompt });
      return res.json({ imageUrl: image.url });
    } catch (error) {
      return res.status(502).json({ error: error instanceof Error ? error.message : "Image generation was unavailable." });
    }
  });

  app.post("/api/edit-image", async (req, res) => {
    try {
      const prompt = typeof req.body?.prompt === "string" ? req.body.prompt : "";
      const sourceImage = typeof req.body?.image === "string" ? req.body.image : "";
      if (!prompt.trim() || !sourceImage) return res.status(400).json({ error: "A source image and edit prompt are required." });
      const image = await generateImage({ prompt, originalImages: [{ url: sourceImage, mimeType: sourceImage.startsWith("data:image/jpeg") ? "image/jpeg" : "image/png" }] });
      return res.json({ imageUrl: image.url });
    } catch (error) {
      return res.status(502).json({ error: error instanceof Error ? error.message : "Image editing was unavailable." });
    }
  });

  app.post("/api/locate-ateliers", async (req, res) => {
    const location = typeof req.body?.searchQuery === "string" && req.body.searchQuery.trim() ? req.body.searchQuery.trim() : "San Francisco, CA";
    const queryType = ["florists", "supplies", "ateliers"].includes(req.body?.queryType) ? req.body.queryType : "all";
    const term = queryType === "supplies" ? "floral supply" : queryType === "ateliers" ? "botanical atelier" : "florist botanical supply";
    try {
      const places = await makeRequest<PlacesSearchResult>("/maps/api/place/textsearch/json", { query: `${term} in ${location}` });
      const groundingChunks = (places.results || []).slice(0, 8).map((place) => ({ maps: { title: place.name, uri: `https://www.google.com/maps/place/?q=place_id:${place.place_id}` } }));
      const summary = groundingChunks.length ? `### Botanical resources near ${location}\n\nThe Atelier Locator found **${groundingChunks.length} current map results**. Open a result below for its location and current business details; availability and services should be confirmed directly with the studio.` : `### No current results returned for ${location}\n\nTry a nearby city, a broader region, or search again after checking your spelling.`;
      return res.json({ text: summary, groundingChunks });
    } catch {
      return res.json({ text: `### Atelier Locator is temporarily in concierge mode\n\nLive map search could not be reached for **${location}**. Try again shortly, or search the city name with “florist”, “botanical supply”, or “artificial flowers”.`, groundingChunks: [], isFallback: true });
    }
  });

  app.post("/api/waitlist", async (req, res) => {
    const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
    if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: "A valid email is required." });
    const result = await registerMoodoorWaitlist(email, typeof req.body?.source === "string" ? req.body.source : "moodoor");
    return res.json({ success: true, ...result });
  });
}

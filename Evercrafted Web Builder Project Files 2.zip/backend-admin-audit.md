# Moodoor Backend and Administration Audit

## Uploaded backend contract

The uploaded `moodoor (1)/server.ts` exposes the public application services that were absent from the initial frontend port. The contract includes deterministic emotional-vector matching, Maker Studio critique, Artisan Canvas generation and edit requests, atelier lookup, design-copilot assistance, story and prompt optimization, and a waitlist endpoint. The original runtime depended on Gemini and external image services; the restored project will preserve the behavior through the managed server, structured model responses where applicable, and persisted data.

## Uploaded administrative surfaces

The upload’s administrative area is not a conventional stock-and-orders panel. Its primary source is `evercrafted-collection-studio-light.jsx`, an internal Collection Studio that creates and manages curated product collections, blueprint-aware render prompts, stages, and render references. It also includes adjacent internal workflows for generating briefs and validating/managing a prompt library.

## Restoration approach

The active project has now been upgraded to support server procedures, database persistence, and authenticated users. The restored public Moodoor views will remain intact. The next implementation work will add a protected `/admin` Collection Studio with collection persistence and controls, preserve the source studio’s product-library and prompt workflow, and expose the public matching and maker/canvas contracts as typed server procedures. Administrator-only operations will use the managed user role rather than browser-local guest state.

## Compatibility note

The source archive does not contain the original Firebase/Gemini/Anthropic credentials or a fully self-contained production admin application. Therefore, credentials and external requests will not be copied. The implementation will use the project’s authenticated server, database, and built-in server-side model capability while retaining the uploaded workflow and data contract.

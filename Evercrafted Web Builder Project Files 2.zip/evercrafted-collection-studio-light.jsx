import { useState, useEffect, useCallback } from "react";

// ==========================================================
// ROLE STYLES -- light palette
// ==========================================================
const RS = {
  "Premium Anchor":     { badge: "#8B4A4A", bg: "#FDF0F0", border: "#EAD4D4", dim: "#C8A0A0" },
  "Hero":               { badge: "#3A6B4A", bg: "#EFF5EF", border: "#C0D8C0", dim: "#80B890" },
  "Supporting":         { badge: "#3A4F7A", bg: "#EFF2F8", border: "#C0CAE0", dim: "#8098C0" },
  "Atmospheric Filler": { badge: "#6B6032", bg: "#F5F2E8", border: "#D8D0B0", dim: "#B0A870" },
  "Gateway":            { badge: "#5A3A7A", bg: "#F2EFF8", border: "#D4C8E8", dim: "#A090C8" },
  "Accent":             { badge: "#3A7272", bg: "#EEF5F5", border: "#B8D4D4", dim: "#70B0B0" },
  "Lifestyle Render":   { badge: "#7A5A3A", bg: "#F8F3ED", border: "#D8C8B0", dim: "#B09870" },
};

const GEN_STEPS = [
  "Reading your collection intent...",
  "Building floral hierarchy and color movement...",
  "Mapping greenery suite and ribbon journey...",
  "Writing Layer 1 entry prompts...",
  "Writing Layer 2 draw and Layer 3 anchor prompts...",
  "Writing Layer 4 discovery prompts...",
  "Generating lifestyle room renders...",
  "Finalizing the full collection intelligence...",
];


// ==========================================================
// ITEM CATALOG -- resolves item_ids to plain-English descriptions
// Falls back to raw item_id if not found so nothing breaks.
// ==========================================================
const ITEM_CATALOG = {
  "PH-FOL-SAGE":   "silvery sage dusty miller -- silver-white felt-like velvet oval leaves",
  "PH-FOL-EUC":    "silver dollar eucalyptus -- round oval blue-grey-green leaves, matte dusty surface",
  "PH-FOL-OLIVE":  "matte olive leaf branch -- narrow dark sage-green leaves with silver undersides",
  "PH-FOL-DUSTY":  "silvery sage dusty miller -- silver-white felt-like velvet oval leaves",
  "PH-FOL-LAMB":   "lamb's ear -- silvery-white velvet oval leaves 2-3in, soft felt-like texture",
  "PH-FOL-BOXWOOD":"boxwood spray -- dense compact rounded leaves, deep sage green",
  "PH-FOL-SMILAX": "smilax leaf -- trailing vine-like stems with small heart-shaped leaves, dusty sage green",
  "PH-FOL-CEDAR":  "cedar branch -- dense scale-like dark green foliage on arching stems",
  "PH-FOL-PINE":   "pine stem -- soft needle clusters on flexible branches, deep forest green",
  "PH-FOL-SPRUCE": "blue spruce stem -- stiff silvery-blue needle clusters",
  "PH-FOL-FIR":    "noble fir tip -- soft flattened needle clusters, deep blue-green",
  "PH-PEO-IVORY":  "ivory cream silk peony -- large cupped bloom 4-5in, layered silk petals",
  "PH-HYD-BLUE":   "baby blue hydrangea cluster -- soft mounded globe 3-4in, dusty muted baby blue",
  "PH-MAG-BUD":    "velvet ivory magnolia bud -- tightly closed egg-shaped bud 1.5-2in, smooth velvet",
  "PH-ROSE-RUFFLE":"ruffle rose -- deeply ruffled velvety cupped bloom 3-4in, dusty mauve-rose",
  "PH-RAN-WHITE":  "white ranunculus -- tightly spiraled cup 2-2.5in, many layered petals, pure white silk",
  "PH-LIS-IVORY":  "ivory lisianthus -- ruffled cup 2in, delicate crepe-like petals, soft warm ivory",
  "PH-TULIP-BURG": "pointed tulip -- elegant closed form 3-4in, deep burgundy wine coloration",
  "PH-TULIP-DBL":  "double tulip -- full layered open bloom 4-5in, deep coral-rose, many overlapping petals",
  "PH-HELLE-LAV":  "hellebores -- nodding cupped bloom 2-3in, dusty lavender-purple, five petals facing downward",
  "PH-WAX-WHITE":  "white wax flower -- tiny star-shaped white blooms 0.5in on thin delicate branching stems",
  "PH-WAX-BLUSH":  "blush wax flower -- tiny star-shaped pale pink blooms 0.4in on thin branching stems",
  "PH-SWEETPEA-VIO":"sweet pea spray -- delicate climbing tendrils with small violet purple blooms 1in each",
};
const resolveItem = (id) => ITEM_CATALOG[id] || id;
const resolveShort = (id) => (ITEM_CATALOG[id] || id).split(" --")[0].trim();

// Odd-count enforcement -- every stem quantity in a compiled prompt must be odd.
// Even quantities round UP to the next odd (2->3, 4->5, 6->7, 8->9).
// Logs a console flag when a correction is made so the source blueprint can be fixed.
function enforceOddCount(qty, itemId, clusterId) {
  const n = Math.max(1, Math.round(qty));
  if (n % 2 === 0) {
    const corrected = n + 1;
    console.warn(`[Evercrafted] Odd-count correction: ${clusterId || "cluster"} ${itemId} qty ${n} -> ${corrected}. Source blueprint has even count -- update blueprint to fix.`);
    return corrected;
  }
  return n;
}

// ==========================================================
// DEGREE -> CLOCK POSITION  (0deg = 12:00, clockwise)
// ==========================================================
function degToClock(deg) {
  deg = ((deg % 360) + 360) % 360;
  const totalHours = deg / 30;
  const h = Math.floor(totalHours) || 12;
  const m = Math.round((totalHours - Math.floor(totalHours)) * 60);
  return m === 0 ? `${h}:00` : `${h}:${m < 10 ? "0" + m : m}`;
}

// ==========================================================
// BLUEPRINT HELPERS
// ==========================================================
function getBlueprintAspectRatio(bp) {
  if (!bp) return "1:1";
  const type = (bp.canvas?.type || "polar").toLowerCase();
  if (type === "polar") return "1:1";
  if (type === "linear") return "3:2";
  return "1:1";
}

function getBlueprintSilenceDesc(bp) {
  if (!bp?.silence_arcs?.length) return null;
  const sa = bp.silence_arcs[0];
  const from = degToClock(sa.from_deg);
  const to   = degToClock(sa.to_deg);
  const enforcement = sa.enforcement === "hard" ? "HARD STOP -- " : "";
  const note = sa.render_note || `raw exposed dark brown grapevine only from ${from} to ${to} o'clock -- designed structural feature equal visual value to the botanical mass`;
  return { from, to, enforcement, note, label: sa.label || "bare_grapevine" };
}

function getBlueprintFoliageDesc(bp) {
  if (!bp?.foliage_sweeps?.length) return null;
  return bp.foliage_sweeps.map(sw => {
    const from = degToClock(sw.arc_from);
    const stop = sw.arc_hard_stop_deg ? degToClock(sw.arc_hard_stop_deg) : degToClock(sw.arc_to);
    const species = resolveShort(sw.item_id);
    return `${species} from ${from} to ${stop} o'clock (hard stop at ${stop})`;
  }).join(", ");
}

function getBlueprintClusterDesc(bp, types) {
  if (!bp?.clusters?.length) return "";
  return bp.clusters
    .filter(c => !types || types.includes(c.type))
    .map(c => {
      const clock = degToClock(c.angle_deg);
      const stemList = (c.stems || []).map(s => {
        const qty = enforceOddCount(s.qty, s.item_id, c.cluster_id);
        return `${qty}x ${resolveShort(s.item_id)}`;
      }).join(", ");
      return `${stemList} at ${clock} o'clock (${c.type})`;
    }).join(", ");
}

function getAllBlueprintItemIds(coll) {
  const ids = new Set();
  (coll.products || []).forEach(p => {
    const bp = p.blueprint;
    if (!bp) return;
    (bp.foliage_sweeps || []).forEach(sw => ids.add(sw.item_id));
    (bp.clusters || []).forEach(c => (c.stems || []).forEach(s => ids.add(s.item_id)));
  });
  return [...ids];
}

// ==========================================================
// GREENERY BASE PROMPT BUILDER
// Blueprint-aware: reads exact sweep arcs, silence arc, directives.
// Falls back to formula/role inference if no blueprint.
// ==========================================================
function buildGreeneryBase(prod, coll) {
  const bp = prod.blueprint;

  if (bp) {
    // --- Blueprint path ---
    const size     = bp.canvas?.diameter_in ? `${bp.canvas.diameter_in}in` : (prod.scale || "24in");
    const ar       = getBlueprintAspectRatio(bp);
    const silence  = getBlueprintSilenceDesc(bp);
    const silenceStr = silence
      ? `${silence.from} to ${silence.to} o'clock is completely bare dark brown grapevine -- ${silence.note}`
      : "right arc from 1:30 to 5:30 o'clock is completely bare dark brown grapevine -- intentional structural feature";

    const sweepParts = (bp.foliage_sweeps || []).map(sw => {
      const from = degToClock(sw.arc_from);
      const stop = degToClock(sw.arc_hard_stop_deg || sw.arc_to);
      const note = sw.render_note ? ` (${sw.render_note})` : "";
      return `${resolveItem(sw.item_id).split(" --")[0]} covering ${from} to ${stop} o'clock${note}`;
    }).join(", ");

    const compRead = bp.render_directives?.composition_read || "Crescent mass on left arc, open right arc is the counterweight.";
    const foliageBoundary = bp.render_directives?.foliage_boundary || "";

    return `luxury handcrafted faux botanical ${size} grapevine ring wreath, home decor product photography, photorealistic commercial photograph, real photograph not illustrated, GREENERY ONLY no florals no berries no pods no seeds, ${sweepParts}, ${silenceStr}, ${foliageBoundary} ${compRead} each stem at unique individual angle organic irregularity front-to-back layering, pale warm grey textured plaster wall, soft daylight from upper left, full wreath in frame --ar ${ar} --v 7 --style raw --s 50 --no berries, pods, seeds, florals, flowers, dark background, full ring coverage, ivy, symmetry`.trim();
  }

  // --- Fallback path (no blueprint) --- unchanged from original ---
  const size    = (prod.scale || "24in").replace(/[^0-9in]/g, "").trim() || "24in";
  const formula = (prod.formula || "crescent").toLowerCase();
  const role    = (prod.role || "").toLowerCase();

  let foliageDesc = "silver dollar eucalyptus and silvery sage dusty miller";
  if (coll.greenerySuite) {
    const gs = coll.greenerySuite;
    const parts = [...(gs.darks||[]).slice(0,2), ...(gs.mids||[]).slice(0,1), ...(gs.lights||[]).slice(0,1)].filter(Boolean);
    if (parts.length) foliageDesc = parts.join(", ");
  }

  let silenceNote = "right arc from 1:30 to 5:30 o'clock is completely bare dark brown grapevine -- intentional structural feature not a gap";
  if (prod.silenceArc) silenceNote = `right arc from ${prod.silenceArc.from} to ${prod.silenceArc.to} o'clock is completely bare dark brown grapevine -- intentional structural feature not a gap`;

  if (formula.includes("crescent") || formula.includes("wreath") || formula.includes("hoop") || formula.includes("moon") || role.includes("anchor") || role.includes("hero") || role.includes("gateway")) {
    return `luxury faux botanical ${size} grapevine ring wreath, product photography, photorealistic, real photograph, GREENERY ONLY no florals no berries no pods no seeds, ${foliageDesc} covering LEFT arc 6 to 12 o'clock only, ${silenceNote}, pale warm grey plaster wall, soft daylight from upper left, full wreath in frame --ar 1:1 --v 7 --style raw --s 50 --no berries, pods, seeds, florals, flowers, dark background, full ring coverage, ivy, symmetry`;
  }
  if (formula.includes("garland") || formula.includes("linear") || role.includes("anchor")) {
    return `luxury faux botanical greenery garland, product photography, photorealistic, real photograph, GREENERY ONLY no florals no berries no pods, ${foliageDesc}, linear directional densest at center tapering at ends, pale warm grey plaster wall, soft daylight from upper left, full garland in frame --ar 3:2 --v 7 --style raw --s 50 --no berries, pods, seeds, florals, flowers, dark background`;
  }
  if (formula.includes("cascade") || formula.includes("puddle") || formula.includes("swag") || formula.includes("threshold")) {
    return `luxury faux botanical greenery cascade installation, product photography, photorealistic, real photograph, GREENERY ONLY no florals no berries no pods, ${foliageDesc} directional organic asymmetric, pale warm grey plaster wall, soft daylight from upper left --ar 4:5 --v 7 --style raw --s 50 --no berries, pods, seeds, florals, flowers, dark background`;
  }
  return `luxury faux botanical arrangement, product photography, photorealistic, real photograph, GREENERY ONLY no florals no berries no pods, ${foliageDesc}, asymmetric natural, pale warm grey plaster wall, soft daylight from upper left --ar 4:5 --v 7 --style raw --s 50 --no berries, pods, seeds, florals, flowers, dark background`;
}

// ==========================================================
// COLLECTION BOUQUET PROMPT BUILDER
// Blueprint-aware: scans all product blueprints for item_ids.
// Falls back to floralHierarchy / greenerySuite if no blueprints.
// ==========================================================
function buildCollectionBouquetPrompt(coll) {
  const parts = [];
  const seen  = new Set();

  const add = (desc) => {
    const key = desc.toLowerCase().trim();
    if (!seen.has(key) && desc) { seen.add(key); parts.push(desc); }
  };

  // Blueprint path: collect all item_ids from all product blueprints
  const bpIds = getAllBlueprintItemIds(coll);
  bpIds.forEach(id => add(resolveShort(id)));

  // Supplement with floralHierarchy if AI-generated
  if (coll.floralHierarchy) {
    const fh = coll.floralHierarchy;
    if (fh.tier1Signature) add(fh.tier1Signature.split("--")[0].split(".")[0].trim());
    (Array.isArray(fh.tier2Supporting) ? fh.tier2Supporting.slice(0,3) : []).forEach(add);
    (Array.isArray(fh.tier3Discovery)  ? fh.tier3Discovery.slice(0,2)  : []).forEach(add);
  }

  // Supplement with greenerySuite
  if (coll.greenerySuite) {
    const gs = coll.greenerySuite;
    [...(gs.darks||[]).slice(0,2), ...(gs.mids||[]).slice(0,1), ...(gs.lights||[]).slice(0,1)].forEach(add);
  }

  // Final fallback: extract species from hero prompts
  if (parts.length === 0) {
    (coll.products || []).forEach(p => {
      const hero = (p.prompts || {})["Hero"] || "";
      const matches = hero.match(/(?:silk |faux |velvet |dried |dusty )?[a-z]+ (?:rose|peony|hydrangea|dahlia|tulip|ranunculus|lily|lavender|eucalyptus|magnolia|dusty miller|olive|boxwood|fern|wax flower|hellebore|sweet pea|smilax|cedar|pine|spruce|fir)[s]?/gi) || [];
      matches.slice(0,4).forEach(m => add(m.trim()));
    });
  }

  const speciesDesc = parts.length > 0
    ? parts.slice(0,8).join(", ")
    : "premium silk florals and faux botanicals in the collection palette";

  const paletteNote = coll.palette?.length ? `palette: ${coll.palette.slice(0,3).join(", ")}, ` : "";

  return `editorial lifestyle photograph of a hand-held luxury faux botanical bouquet, a woman's hand and forearm holding a loosely gathered arrangement, ${speciesDesc}, ${paletteNote}stems wrapped loosely in natural linen twine at the hand, bouquet held at a natural downward angle arm relaxed not posed, photographed against a pale warm grey textured plaster wall, soft north-facing window light from the left, bouquet in sharp focus hand softly blurred, florals at true natural scale nothing enlarged, 85mm f/1.8 medium format --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, wilting, dew, vase, plastic shine, bright colors, symmetrical, studio backdrop, cartoon, text, watermark`;
}

// ==========================================================
// BLUEPRINT HERO / VARIANT A / DETAIL CROP BUILDER
// Only called when prod.blueprint exists.
// ==========================================================
function buildHeroFromBlueprint(prod, coll, tab) {
  const bp = prod.blueprint;
  const size = bp.canvas?.diameter_in ? `${bp.canvas.diameter_in}in` : (prod.scale||"24in");
  const ar   = getBlueprintAspectRatio(bp);
  const silence = getBlueprintSilenceDesc(bp);
  const silStr  = silence ? `silence arc ${silence.from} to ${silence.to} o'clock bare grapevine only -- designed feature` : "right arc 1:30 to 5:30 bare grapevine";
  const emotional = (bp.emotional_tags||[]).join(", ");
  const compRead  = bp.render_directives?.composition_read || "";

  const descCluster = (c) => {
    const clock = degToClock(c.angle_deg);
    const stems = (c.stems||[]).map(s => `${enforceOddCount(s.qty,s.item_id,c.cluster_id)}x ${resolveShort(s.item_id)}`).join(", ");
    return `${stems} at ${clock} o'clock (${c.type})${c.render_note ? " ["+c.render_note+"]" : ""}`;
  };

  const focal     = (bp.clusters||[]).filter(c=>c.type==="focal").map(descCluster).join(", ");
  const secondary = (bp.clusters||[]).filter(c=>c.type==="secondary").map(descCluster).join(", ");
  const accent    = (bp.clusters||[]).filter(c=>c.type==="accent").map(descCluster).join(", ");
  const filler    = (bp.clusters||[]).filter(c=>c.type==="filler").map(descCluster).join(", ");
  const clusters  = [focal&&`FOCAL: ${focal}`,secondary&&`SECONDARY: ${secondary}`,accent&&`ACCENT: ${accent}`,filler&&`FILLER: ${filler}`].filter(Boolean).join(", ");

  const base = `luxury handcrafted faux botanical ${size} grapevine ring wreath, home decor product photography, photorealistic commercial photograph, real photograph not illustrated, pale warm grey plaster wall, soft studio daylight from upper left, full wreath visible in frame${emotional?`, ${emotional}`:""}, ${clusters}, ${silStr}, ${compRead}`;
  const neg  = "--no symmetry, bouquet, centered, fresh flowers, wilting, plastic shine, craft store, full ring florals, dark background";

  if (tab==="Hero")      return `${base}, asymmetric directional composition, each stem unique angle organic irregularity, 85mm medium format, shallow depth of field on focal cluster --ar ${ar} --v 7 --style raw --s 100 ${neg}`;
  if (tab==="Variant A") return `${base}, wreath on aged warm plaster wall above dark console table, soft afternoon light from left, 85mm medium format --ar ${ar} --v 7 --style raw --s 100 ${neg}`;
  if (tab==="Detail Crop") {
    const f = (bp.clusters||[]).find(c=>c.type==="focal")||(bp.clusters||[])[0];
    const clock = f ? degToClock(f.angle_deg) : "9:00";
    const stems = f ? (f.stems||[]).map(s=>resolveItem(s.item_id)).join(", ") : "focal cluster";
    return `close-up editorial detail of a luxury faux botanical wreath, focal cluster at ${clock} o'clock in sharp focus: ${stems}, layered botanical texture, dimensional depth front-to-back, soft directional window light, macro botanical detail, shallow depth of field --ar 4:5 --v 7 --style raw --s 100 ${neg}, full wreath in frame`;
  }
  return "";
}



// ==========================================================
// PRODUCT LIBRARY -- all 32 form definitions
// Used by the Collection Intelligence Engine (intent panel)
// and as reference for prompt generation.
// Each entry: formCode, name, role, layer, scale, formula,

const SYSTEM_PROMPT = `You are the Evercrafted Collection Intelligence Engine -- a complete home botanical design system that generates full-home luxury faux botanical collections with Midjourney render prompts and architectural pencil illustration prompts. You select the right products from a 30-form library based on the collection intent, rather than generating a fixed product list every time.

==========================================
EVERCRAFTED SIGHTLINE PHILOSOPHY
==========================================
Every collection tells a sightline story. When the front door opens the eye travels through four layers:
Layer 1 ENTRY: Front door, foyer, threshold, entry lamps. First impression, boldest botanical expression.
Layer 2 DRAW: Staircase, newel post, interior doorways. Pulls the eye deeper into the home.
Layer 3 ANCHOR: Mantel, chandelier, bookcase, kitchen. Room centerpieces.
Layer 4 DISCOVERY: Chair wreaths, cabinet wreaths, lamp wreaths, candle rings, window wreaths. Found when you look closely.

==========================================
PRODUCT LIBRARY -- 32 forms (use formCode for selectedForms array)
==========================================
LAYER 1 ENTRY: E1 Grande Wreath 26-30in | E2 Hero Wreath 22-26in | E3 Entry Tree Pair | E4 Foyer Arrangement 24-36in | E5 Threshold Treatment | E6 Lamp Neck Wreath Pair 8-10in | E7 Door Swag 18-30in
LAYER 2 DRAW:  D1 Puddle Post Pair (greenery-only) | D2 Interior Threshold | D3 Staircase Cascade (greenery-only)
LAYER 3 ANCHOR: A1 Mantel Garland 48-60in | A2 Chandelier Treatment | A3 Bookcase Cascade (greenery-only) | A4 Bookcase Shelf Drape (greenery-only, no bow) | A5 Stove Surround Garland (greenery-only) | A6 Kitchen Ledge Garland 24-36in (greenery-only)
LAYER 4 DISCOVERY: R1 Chair Wreath Set 4x10in | R2 Cabinet Wreath Pair 2x8-10in (greenery-only) | R3 Lamp Neck Wreath Set | R4 Window Wreath 8-12in (greenery-only, no bow) | R5 Pantry Door Wreath 8-10in | R6 Candle Ring Set 2x8in (NO BOW EVER) | R7 Lantern Collar | R8 Table Centerpiece 8-14in
SPECIALTY: S1 Tabletop Tree 12-24in | S2 Kissing Ball 8-14in | S3 Dough Bowl Arrangement | S4 Bottle Brush Tree Cluster 3-piece (Christmas only, no bow) | S5 Moon Wreath 18-24in | S6 Hoop Wreath 16-22in (ribbon tail only)
ACCENT PACKS: P1 Icicle Accent Pack (winter only) | P2 Stem Bundle 6-stem

==========================================
COLLECTION SELECTION ENGINE
==========================================
Do NOT generate a fixed product list. Read the collection intent, infer the home profile, then SELECT 10-16 products from the library above.

HOME SCALE INFERENCE -- read intent signals:
APARTMENT/SMALL (select 8-10): Avoid D1/D3/A2/A3. Prefer E2, E7 or S5/S6, D2, A1 or A5, R6, R7, R8.
STANDARD HOME (select 10-13): E1-E2, D1 or D2, A1, plus 4-6 discovery and accent products.
LARGE HOME (select 13-16): Full E-tier selectively, D1+D2 or D1+D3, 2-3 A-tier, 5-6 R-tier, 1-2 S-tier.
ESTATE (select 16+): Near-complete library. All layers represented. Specialty forms included.

PRODUCT TRIGGER SIGNALS -- include these products when intent contains these signals:
"grand entry / estate / arrival" -> include E3 (Entry Trees) + E5 (Threshold)
"staircase / foyer / traditional / tall ceilings" -> include D1 (Puddle Post)
"banister / railing" -> include D3 (Staircase Cascade)
"dining room / entertaining / hosting / tablescape" -> include A2 (Chandelier) + R1 (Chair Wreaths) + R8 (Centerpiece)
"kitchen / farmhouse / gathering / range / stove" -> include A5 or A6
"library / study / books / bookcase" -> include A3 or A4
"lamps / entry table / side table" -> include E6 or R3
"window / sink / kitchen window" -> include R4 (Window Wreath)
"pantry / discovery / intimate" -> include R5
"minimal / modern / editorial / apartment" -> prefer S5 or S6 over E1; use A5 or A6 not A2
"Christmas / holiday / festive" -> include S1 (Tabletop Tree) + S4 (Bottle Brush) + P1 (Icicle Pack) + R1
"winter / nordic / icy / snow" -> include P1 (Icicle Pack) with any staircase or mantel products
"cottage / farmhouse / rustic / organic" -> include S3 (Dough Bowl) + A5
"romantic / wedding / abundant" -> include S2 (Kissing Ball) + E4 (Foyer Arrangement)
"large door / entry door" -> include E5 (Threshold Treatment)
"cabinet / built-in / kitchen storage" -> include R2 (Cabinet Wreath Pair)

ALWAYS INCLUDE (minimum every collection):
-- At least one primary wreath (E1, E2, S5, or S6)
-- At least one Layer 2 draw product (D1, D2, or D3)
-- At least one Layer 3 anchor product (A1-A6)
-- At least one Layer 4 discovery product (R1-R8)
-- At least one lifestyle render

NEVER include S4 (Bottle Brush Trees) without a Christmas or holiday signal.
NEVER include A2 (Chandelier) for apartment or small home signals.
NEVER put a bow on R6 (Candle Rings) or R4 (Window Wreath).

==========================================
FLORAL HIERARCHY -- resolve before any prompts
==========================================
Tier 1 SIGNATURE: One hero species. Full open bloom expression ONLY at Layer 1. Appears as single buds or accents in Layers 2-3. Completely absent from Layer 4.
Tier 2 SUPPORTING: 2-3 secondary species. Carry the collection through Layers 2 and 3.
Tier 3 DISCOVERY: Small textural species only. ONLY in Layer 4 micro-placement products. Absent from Layer 1.

FLORAL COUNT RULE: Odd numbers always -- 1, 3, 5, 7, or 9 per species. Never 2, 4, 6, or 8.
SPECIES DIVERSITY: Layer 1: 5 species min. Layer 2-3: 4 species. Layer 4: 3 species. Min 7 distinct species across the full collection.

COLOR MOVEMENT:
FULL SATURATION at Layer 1 -- richest boldest palette. MIDTONE at Layers 2-3 -- quieter, more foliage. WHISPER TONE at Layer 4 -- single accent of the palette color. NEUTRAL ANCHOR throughout -- the greenery, constant at all layers.

GREENERY OPTIONS (use multiple species, vary darkness):
Darks: cedar, noble fir, Douglas fir, boxwood, magnolia leaf, bay laurel, seeded eucalyptus
Mids: Fraser fir, pine, olive branch, salal leaf, lemon leaf
Lights/Silver: dusty miller, silver dollar eucalyptus, juniper, blue spruce, lamb's ear
Texturals: pampas grass, dried fern, cotton stem, thistle, dried lavender, seed pods
Winter specials: flocked noble fir, iced cedar tips, frosted eucalyptus, snow-dusted boxwood, glass icicle clusters

GREENERY-ONLY PRODUCTS: D1 Puddle Post, A5/A6 Kitchen Garlands, A4 Shelf Drape, R2 Cabinet Wreath Pair, R4 Window Wreath, R7 Lantern Collar.

==========================================
MULTI-RIBBON SYSTEM
==========================================
Up to 3 ribbons per product, always different widths. NEVER two patterns together.
STATEMENT: widest (5-6in large, 3-4in medium, 2-2.5in small). Solid or subtle texture. Sets the color.
CHARACTER: mid-width (2-2.5in large, 1.5-2in small). THE PATTERN ribbon: plaid, stripe, check, houndstooth, tartan, toile.
ACCENT: narrowest (always 1.5in). Satin, sheer, metallic, organza. Longest tails. Movement ribbon.
DESCRIBE ALL RIBBONS EXPLICITLY in every bow: name each ribbon width, material, color, and pattern.
RIBBON JOURNEY: Entry = lightest (ivory cream pale gold) -> Anchor = richest (deep velvet plaid) -> Discovery = quietest (thin grosgrain single satin).
BOW ON ALL products EXCEPT: Candle Rings (R6), Window Wreath (R4), Shelf Drape (A4), Bottle Brush Trees (S4), Hoop Wreath (S6 uses long tail only, no loops).

==========================================
COLLECTION METADATA -- include in every JSON
==========================================
sightlineStory: one sentence describing what you see from the front door inward
floralHierarchy: tier1Signature, tier2Supporting (array), tier3Discovery (array)
greenerySuite: darks, mids, lights, texturals, snowTreatment
ribbonJourney: entry, draw, anchor, discovery (each with statement, character, accent)
colorMovement: fullSaturation, midTone, whisperTone, neutralAnchor
greenerOnlyProducts: array of product names with zero florals
selectedForms: array of form codes from library (e.g. ["E1","E2","D1","A1","A2","R1","R6","R7","P1"])

==========================================
OUTPUT FORMAT
==========================================
Return ONLY valid JSON. No markdown. No explanation. No text before or after.
For each product generate: id, name, role, layer (1-4), formCode (from library e.g. "E1"), scale, formula, price, done:false, prompts with Hero + Variant A + Detail Crop + Sketch.

{"id":"...","collectionName":"...","season":"...","atmosphere":"...","priceRange":"...","palette":[...],"sightlineStory":"...","floralHierarchy":{...},"greenerySuite":{...},"ribbonJourney":{...},"colorMovement":{...},"greenerOnlyProducts":[...],"selectedForms":[...],"products":[...variable count based on selection engine...]GREENERY BASE PROMPT (include for all wreath/ring/garland/cascade products):
Auto-generated by the app from product specs. Include as "Greenery Base" key in prompts with value: "GREENERY ONLY [size] [form] [foliage species from greenerySuite] [placement arc] [silence arc if wreath] pale warm grey plaster wall --ar [ratio] --v 7 --style raw --s 50 --no berries, pods, seeds, florals, flowers, dark background"}`;


// ==========================================================
// INITIAL COLLECTION -- QUIET ACCORD
// ==========================================================
// ==========================================================
// PRODUCT LIBRARY -- all 32 Evercrafted product forms
// Used by the Collection Intelligence Engine to drive
// prompt generation for any product in any collection.
// ==========================================================
const PRODUCT_LIBRARY = {
  E1:{name:"Grande Wreath",         formCode:"E1",layer:1,role:"Premium Anchor",    scale:"26-30in",formula:"Heavy Crescent Extended",  price:"$295-$385",bow:true, greenerOnly:false,ar:"1:1", silenceArc:{from:"1:30",to:"5:30"},noList:"symmetry,bouquet,centered,fresh flowers,plastic shine,craft store"},
  E2:{name:"Hero Wreath",           formCode:"E2",layer:1,role:"Hero",              scale:"22-26in",formula:"Heavy Crescent",            price:"$185-$245",bow:true, greenerOnly:false,ar:"1:1", silenceArc:{from:"1:00",to:"5:30"},noList:"symmetry,bouquet,centered,fresh flowers,plastic shine"},
  E3:{name:"Entry Tree Pair",       formCode:"E3",layer:1,role:"Supporting",        scale:"Pair",   formula:"Cone Topiary",              price:"$265-$395",bow:true, greenerOnly:false,ar:"3:2", silenceArc:null,noList:"asymmetry,fresh flowers,plastic shine",note:"Symmetry intentional"},
  E4:{name:"Foyer Arrangement",     formCode:"E4",layer:1,role:"Supporting",        scale:"24-36in",formula:"Tall Vessel Asymmetric",    price:"$215-$285",bow:true, greenerOnly:false,ar:"5:4", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine,bouquet"},
  E5:{name:"Threshold Treatment",   formCode:"E5",layer:1,role:"Supporting",        scale:"Full",   formula:"Header Swag + Drops",       price:"$185-$265",bow:true, greenerOnly:false,ar:"4:5", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine,centered"},
  E6:{name:"Lamp Neck Wreath Pair", formCode:"E6",layer:1,role:"Accent",            scale:"8-10in", formula:"Collar",                    price:"$75-$95",  bow:true, greenerOnly:false,ar:"5:4", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine"},
  E7:{name:"Door Swag",             formCode:"E7",layer:1,role:"Supporting",        scale:"18-30in",formula:"Gathered Swag",             price:"$95-$135", bow:true, greenerOnly:false,ar:"4:5", silenceArc:null,noList:"ring,grapevine,fresh flowers,plastic shine"},
  D1:{name:"The Puddle Post",       formCode:"D1",layer:2,role:"Supporting",        scale:"Post",   formula:"Crown Cascade Puddle",      price:"$265-$365",bow:true, greenerOnly:true, ar:"4:5", silenceArc:null,noList:"florals,symmetry,fresh flowers,plastic shine"},
  D2:{name:"Interior Threshold",    formCode:"D2",layer:2,role:"Supporting",        scale:"Door",   formula:"Header Swag Light",         price:"$125-$175",bow:true, greenerOnly:false,ar:"4:5", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine"},
  D3:{name:"Staircase Cascade",     formCode:"D3",layer:2,role:"Supporting",        scale:"Rail",   formula:"Linear Taper",              price:"$185-$295",bow:true, greenerOnly:true, ar:"3:2", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine"},
  A1:{name:"Mantel Garland",        formCode:"A1",layer:3,role:"Atmospheric Filler",scale:"48-60in",formula:"Linear Directional",        price:"$165-$215",bow:true, greenerOnly:false,ar:"3:2", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine"},
  A2:{name:"Chandelier Treatment",  formCode:"A2",layer:3,role:"Atmospheric Filler",scale:"Fixture",formula:"Frame Wrap + Cascade",      price:"$195-$285",bow:true, greenerOnly:false,ar:"3:2", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine"},
  A3:{name:"Bookcase Cascade",      formCode:"A3",layer:3,role:"Supporting",        scale:"Height", formula:"Crown to Floor",            price:"$125-$185",bow:true, greenerOnly:true, ar:"4:5", silenceArc:null,noList:"florals,symmetry,fresh flowers,plastic shine"},
  A4:{name:"Bookcase Shelf Drape",  formCode:"A4",layer:3,role:"Accent",            scale:"Shelf",  formula:"Trailing Cluster",          price:"$45-$85",  bow:false,greenerOnly:true, ar:"5:4", silenceArc:null,noList:"bow,ribbon,florals,fresh flowers,plastic shine"},
  A5:{name:"Stove Surround Garland",formCode:"A5",layer:3,role:"Supporting",        scale:"Width",  formula:"Linear Surround",           price:"$145-$225",bow:true, greenerOnly:true, ar:"3:2", silenceArc:null,noList:"florals,fresh flowers,plastic shine"},
  A6:{name:"Kitchen Ledge Garland", formCode:"A6",layer:3,role:"Supporting",        scale:"24-36in",formula:"Linear Simple",             price:"$85-$125", bow:false,greenerOnly:true, ar:"3:2", silenceArc:null,noList:"florals,fresh flowers,plastic shine"},
  R1:{name:"Chair Wreath Set",      formCode:"R1",layer:4,role:"Accent",            scale:"4x10in", formula:"Classic Asymmetric",        price:"$125-$165",bow:true, greenerOnly:false,ar:"3:2", silenceArc:{from:"2:00",to:"5:00"},noList:"symmetry,heavy florals,fresh flowers,plastic shine",note:"Set of 4"},
  R2:{name:"Cabinet Wreath Pair",   formCode:"R2",layer:4,role:"Accent",            scale:"2x8in",  formula:"Classic Asymmetric",        price:"$55-$85",  bow:false,greenerOnly:true, ar:"5:4", silenceArc:{from:"2:00",to:"5:00"},noList:"florals,fresh flowers,plastic shine",note:"Pair"},
  R3:{name:"Lamp Neck Wreath Set",  formCode:"R3",layer:4,role:"Accent",            scale:"2x8in",  formula:"Collar",                    price:"$65-$95",  bow:true, greenerOnly:false,ar:"5:4", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine",note:"Pair"},
  R4:{name:"Window Wreath",         formCode:"R4",layer:4,role:"Accent",            scale:"8-12in", formula:"Classic Asymmetric",        price:"$55-$85",  bow:false,greenerOnly:true, ar:"5:4", silenceArc:{from:"2:30",to:"5:00"},noList:"bow,ribbon,florals,fresh flowers,plastic shine"},
  R5:{name:"Pantry Door Wreath",    formCode:"R5",layer:4,role:"Accent",            scale:"8-10in", formula:"Classic Asymmetric",        price:"$45-$65",  bow:true, greenerOnly:false,ar:"5:4", silenceArc:{from:"2:00",to:"5:00"},noList:"fresh flowers,plastic shine"},
  R6:{name:"Candle Ring Set",       formCode:"R6",layer:4,role:"Accent",            scale:"2x8in",  formula:"Asymmetric Cluster",        price:"$55-$75",  bow:false,greenerOnly:false,ar:"5:4", silenceArc:null,noList:"bow,ribbon,symmetry,fresh flowers,plastic shine",note:"NO BOW EVER"},
  R7:{name:"Lantern Collar",        formCode:"R7",layer:4,role:"Accent",            scale:"Base",   formula:"Radial Asymmetric",         price:"$85-$125", bow:true, greenerOnly:false,ar:"5:4", silenceArc:null,noList:"symmetry,full coverage,fresh flowers,plastic shine"},
  R8:{name:"Table Centerpiece",     formCode:"R8",layer:4,role:"Accent",            scale:"8-14in", formula:"Low Vessel",                price:"$95-$145", bow:true, greenerOnly:false,ar:"5:4", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine"},
  S1:{name:"Tabletop Tree",         formCode:"S1",layer:1,role:"Supporting",        scale:"12-24in",formula:"Cone Wrapped",              price:"$85-$185", bow:true, greenerOnly:false,ar:"4:5", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine"},
  S2:{name:"Kissing Ball",          formCode:"S2",layer:1,role:"Accent",            scale:"8-14in", formula:"Sphere",                    price:"$75-$125", bow:true, greenerOnly:false,ar:"1:1", silenceArc:null,noList:"flat,fresh flowers,plastic shine"},
  S3:{name:"Dough Bowl",            formCode:"S3",layer:3,role:"Supporting",        scale:"Bowl",   formula:"Low Sprawling",             price:"$125-$185",bow:false,greenerOnly:false,ar:"5:4", silenceArc:null,noList:"symmetry,fresh flowers,plastic shine,vase"},
  S4:{name:"Bottle Brush Trees",    formCode:"S4",layer:4,role:"Accent",            scale:"3-piece",formula:"Graduated Trio",            price:"$55-$85",  bow:false,greenerOnly:false,ar:"5:4", silenceArc:null,noList:"bow,ribbon,fresh flowers",note:"Christmas only"},
  S5:{name:"Moon Wreath",           formCode:"S5",layer:1,role:"Hero",              scale:"18-24in",formula:"Half Crescent",             price:"$125-$185",bow:true, greenerOnly:false,ar:"1:1", silenceArc:{from:"12:00",to:"6:00"},noList:"full ring,symmetry,fresh flowers,plastic shine"},
  S6:{name:"Hoop Wreath",           formCode:"S6",layer:1,role:"Hero",              scale:"16-22in",formula:"Asymmetric Cluster",        price:"$95-$145", bow:false,greenerOnly:false,ar:"4:5", silenceArc:null,noList:"droopy bow,full bow,symmetry,fresh flowers,plastic shine",note:"Tail only"},
  P1:{name:"Icicle Accent Pack",    formCode:"P1",layer:3,role:"Accent",            scale:"Clusters",formula:"Glass Icicle",            price:"$35-$55",  bow:false,greenerOnly:false,ar:"5:4", silenceArc:null,noList:"colored,plastic,fresh flowers",note:"Winter only"},
  P2:{name:"Stem Bundle",           formCode:"P2",layer:1,role:"Accent",            scale:"6 stems",formula:"Kraft Wrapped",            price:"$22-$38",  bow:true, greenerOnly:false,ar:"5:4", silenceArc:null,noList:"vase,fresh flowers,plastic shine"},
};
const getProductDef = (formCode) => PRODUCT_LIBRARY[formCode] || null;

// Helper: auto-build a minimal product object from a library form code
function productFromLibrary(formCode, overrides = {}) {
  const def = PRODUCT_LIBRARY[formCode];
  if (!def) return null;
  return {
    id:      overrides.id      || formCode.toLowerCase() + "_" + Date.now(),
    name:    overrides.name    || def.name,
    role:    overrides.role    || def.role,
    layer:   def.layer,
    formCode,
    scale:   overrides.scale   || def.scale,
    formula: overrides.formula || def.formula,
    price:   overrides.price   || def.price,
    note:    def.note || "",
    done:    false,
    prompts: overrides.prompts || {},
    blueprint: overrides.blueprint || null,
  };
}

const QUIET_ACCORD = {
  id: "quiet_accord",
  collectionName: "Quiet Accord",
  season: "Late Autumn to Deep Winter",
  atmosphere: "Nordic Calm",
  priceRange: "$22 - $325",
  palette: ["Ivory Mist", "Sage Smoke", "Slate Berry", "Warm Bark"],
  sightlineStory: "",
  floralHierarchy: {},
  greenerySuite: {},
  ribbonJourney: {},
  colorMovement: {},
  greenerOnlyProducts: [],
  selectedForms: [],
  products: []
};

// ==========================================================
// TOKENS
// ==========================================================
const T = {
  pageBg:    "#F5F2EB",
  cardBg:    "#FFFFFF",
  panelBg:   "#F0EDE6",
  inputBg:   "#F8F5EF",
  border:    "#E4DED4",
  borderMed: "#CEC8BE",
  text1:     "#2C2820",
  text2:     "#5C5650",
  text3:     "#9C9690",
  sage:      "#4A7A52",
  sageBg:    "#EBF3EB",
  sageBd:    "#B0CEB4",
  gold:      "#C4A862",
  done:      "#3A6B4A",
  doneBg:    "#EBF5EE",
  doneBd:    "#A8CEB4",
  err:       "#8B3030",
  errBg:     "#FDF0F0",
  errBd:     "#E0B8B8",
};

// ==========================================================
// APP
// ==========================================================
export default function App() {
  const [collections, setCollections] = useState([QUIET_ACCORD]);
  const [activeIdx, setActiveIdx]     = useState(0);
  const [doneMap, setDoneMap]         = useState({ "quiet_accord|hero": true });
  const [tabMap, setTabMap]           = useState({});
  const [customMap, setCustomMap]     = useState({});
  const [copied, setCopied]           = useState({});
  // Per-collection bouquet oref -- keyed by collection id
  const [collBouquets, setCollBouquets] = useState({});
  const [srefUrl, setSrefUrl]         = useState("");
  const [srefOn, setSrefOn]           = useState(false);
  const [srefWeight, setSrefWeight]   = useState(100);
  const [showExport, setShowExport]   = useState(false);
  const [exportCopied, setExportCopied] = useState(false);
  const [showIntent, setShowIntent]   = useState(false);
  const [intentForm, setIntentForm]   = useState({ name: "", season: "", brief: "", hero: "" });
  const [isGenerating, setIsGenerating] = useState(false);
  const [genStepIdx, setGenStepIdx]   = useState(0);
  const [genError, setGenError]       = useState("");
  const [storageReady, setStorageReady] = useState(false);
  const [apiKey, setApiKey]             = useState("");
  const [imageUrls, setImageUrls]       = useState({});
  const [hoveredImg, setHoveredImg]     = useState(null);
  const [expandedImg, setExpandedImg]   = useState(null);
  const [showImgInput, setShowImgInput] = useState({});
  const [imgInputVals, setImgInputVals] = useState({});
  const [phaseUrls, setPhaseUrls]       = useState({});
  const [greeneryUrls, setGreeneryUrls] = useState({});

  // -- LOAD from storage on mount --------------------------
  useEffect(() => {
    const load = async () => {
      try {
        const savedColls = await window.storage.get("ec-collections");
        if (savedColls?.value) {
          try {
            const parsed = JSON.parse(savedColls.value);
            if (Array.isArray(parsed) && parsed.length > 0) {
              // Always ensure Quiet Accord is present as the baseline collection
              const hasQA = parsed.some(c => c.id === 'quiet_accord' || c.id === 'quiet_accord_full');
              const merged = hasQA ? parsed : [QUIET_ACCORD, ...parsed];
              setCollections(merged);
            }
          } catch(parseErr) {
            // Stored collections were malformed -- reset to default
            console.warn('Stored collections parse failed, resetting:', parseErr.message);
            setCollections([QUIET_ACCORD]);
            window.storage.set("ec-collections", JSON.stringify([QUIET_ACCORD])).catch(()=>{});
          }
        }
        const savedDone = await window.storage.get("ec-done");
        if (savedDone?.value) setDoneMap(JSON.parse(savedDone.value));
        const savedIdx = await window.storage.get("ec-active-idx");
        if (savedIdx?.value) setActiveIdx(JSON.parse(savedIdx.value));
        const savedImgs = await window.storage.get("ec-image-urls");
        if (savedImgs?.value) setImageUrls(JSON.parse(savedImgs.value));
        const savedPhaseUrls = await window.storage.get("ec-phase-urls");
        if (savedPhaseUrls?.value) setPhaseUrls(JSON.parse(savedPhaseUrls.value));
        const savedGreeneryUrls = await window.storage.get("ec-greenery-urls");
        if (savedGreeneryUrls?.value) setGreeneryUrls(JSON.parse(savedGreeneryUrls.value));
        const savedCollBouquets = await window.storage.get("ec-coll-bouquets");
        if (savedCollBouquets?.value) setCollBouquets(JSON.parse(savedCollBouquets.value));
      } catch {}
      setStorageReady(true);
    };
    load();
  }, []);

  // -- SAVE collections whenever they change ---------------
  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-collections", JSON.stringify(collections)).catch(() => {});
  }, [collections, storageReady]);

  // -- SAVE done states whenever they change ---------------
  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-done", JSON.stringify(doneMap)).catch(() => {});
  }, [doneMap, storageReady]);

  // -- SAVE active index whenever it changes ---------------
  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-active-idx", JSON.stringify(activeIdx)).catch(() => {});
  }, [activeIdx, storageReady]);

  // -- SAVE image URLs whenever they change -----------------
  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-image-urls", JSON.stringify(imageUrls)).catch(() => {});
  }, [imageUrls, storageReady]);

  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-phase-urls", JSON.stringify(phaseUrls)).catch(() => {});
  }, [phaseUrls, storageReady]);

  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-coll-bouquets", JSON.stringify(collBouquets)).catch(() => {});
  }, [collBouquets, storageReady]);

  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-greenery-urls", JSON.stringify(greeneryUrls)).catch(() => {});
  }, [greeneryUrls, storageReady]);

  // -- STEP animation during generation --------------------
  useEffect(() => {
    if (!isGenerating) return;
    setGenStepIdx(0);
    const iv = setInterval(() => setGenStepIdx(i => (i + 1) % GEN_STEPS.length), 1800);
    return () => clearInterval(iv);
  }, [isGenerating]);

  const coll = collections[Math.min(activeIdx, collections.length - 1)];

  // Derive per-collection bouquet values from the map
  const collBouquet  = collBouquets[coll?.id] || {};
  const orefUrl      = collBouquet.url    || "";
  const orefOn       = collBouquet.on     || false;
  const orefWeight   = collBouquet.weight ?? 100;
  const setOrefUrl    = (url)    => setCollBouquets(p => ({ ...p, [coll.id]: { ...(p[coll.id]||{}), url } }));
  const setOrefOn     = (fn)     => setCollBouquets(p => { const prev = p[coll.id]||{}; return { ...p, [coll.id]: { ...prev, on: typeof fn === "function" ? fn(prev.on||false) : fn } }; });
  const setOrefWeight = (weight) => setCollBouquets(p => ({ ...p, [coll.id]: { ...(p[coll.id]||{}), weight } }));

  // fp() assembles the final compiled prompt per the Evercrafted rendering workflow:
  // [greenery base URL] [hero prompt text] --iw 2 --oref [bouquet URL] --ow 100 --ar [ratio] --v 7 --style raw --s [s] --no [negatives]
  // skipRefs=true for everything except Hero, Variant A, Detail Crop tabs.
  const fp = useCallback((base, skipRefs = false, greeneryUrl = "") => {
    let out = base;
    if (!skipRefs) {
      const hasGreenery = greeneryUrl && greeneryUrl.trim();
      const hasBouquet  = orefOn && orefUrl.trim();
      // Guard: never inject if flags already present in the prompt
      const alreadyHasIw   = out.includes("--iw");
      const alreadyHasOref = out.includes("--oref");

      // Step 1: prepend greenery base URL as normal image reference
      if (hasGreenery && !alreadyHasIw) out = greeneryUrl.trim() + " " + out;

      // Step 2: inject --iw 2 + --oref (bouquet) before --ar, only once
      if (hasGreenery && hasBouquet && !alreadyHasIw && !alreadyHasOref) {
        out = out.replace("--ar", `--iw 2 --oref ${orefUrl.trim()} --ow ${orefWeight} --ar`);
      } else if (hasGreenery && !alreadyHasIw) {
        out = out.replace("--ar", `--iw 2 --ar`);
      } else if (hasBouquet && !alreadyHasOref) {
        out = out.replace("--ar", `--oref ${orefUrl.trim()} --ow ${orefWeight} --ar`);
      }
    }
    // sref: always apply if active, guard against duplicate
    if (srefOn && srefUrl.trim() && !out.includes("--sref"))
      out = out.replace("--ar", `--sref ${srefUrl.trim()} --sw ${srefWeight} --ar`);
    return out;
  }, [collBouquets, coll?.id, srefOn, srefUrl, srefWeight]);

  const k = (prodId, sfx = "") => `${coll.id}|${prodId}${sfx ? "|" + sfx : ""}`;
  const isDone = id => !!doneMap[k(id)];
  const toggleDone = id => setDoneMap(p => ({ ...p, [k(id)]: !p[k(id)] }));
  const getTab = prod => tabMap[k(prod.id)] || Object.keys(prod.prompts)[0];
  const setTab = (id, t) => setTabMap(p => ({ ...p, [k(id)]: t }));
  const getCS = id => customMap[k(id)] || {};
  const updCS = (id, patch) => setCustomMap(p => ({ ...p, [k(id)]: { ...p[k(id)], ...patch } }));

  const doCopy = async (text, ck) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(p => ({ ...p, [ck]: true }));
      setTimeout(() => setCopied(p => ({ ...p, [ck]: false })), 2000);
    } catch {}
  };

  const doneCount = coll.products.filter(p => isDone(p.id)).length;

  const handleGenerate = async () => {
    if (!intentForm.brief.trim()) return;
    setIsGenerating(true); setGenError("");
    const msg = [
      intentForm.name && `Collection working name: ${intentForm.name}`,
      intentForm.season && `Season and timing: ${intentForm.season}`,
      `Collection intent: ${intentForm.brief}`,
      intentForm.hero && `Hero floral(s): ${intentForm.hero}`,
    ].filter(Boolean).join("\n");
    try {
      const headers = {
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
      };
      if (apiKey.trim()) headers["x-api-key"] = apiKey.trim();

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 8000,
          system: SYSTEM_PROMPT,
          messages: [{ role: "user", content: msg }]
        }),
      });
      const data = await res.json();

      // Surface API-level errors clearly
      if (data.error) throw new Error(`API error: ${data.error.type} -- ${data.error.message}`);
      if (!data.content?.[0]?.text) throw new Error(`Unexpected response shape: ${JSON.stringify(data).slice(0, 200)}`);

      const raw = data.content[0].text.trim();
      const s = raw.indexOf("{"), e = raw.lastIndexOf("}");
      if (s === -1 || e === -1) throw new Error(`No JSON found in response. Got: ${raw.slice(0, 200)}`);

      const parsed = JSON.parse(raw.slice(s, e + 1));
      if (!Array.isArray(parsed.products) || !parsed.products.length) throw new Error("Collection parsed but has no products");

      const newColl = { ...parsed, id: parsed.id || `coll_${Date.now()}` };
      setCollections(prev => [...prev, newColl]);
      setActiveIdx(collections.length);
      setShowIntent(false);
      setIntentForm({ name: "", season: "", brief: "", hero: "" });
    } catch (err) {
      setGenError(err.message || "Unknown error -- open browser console for details.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCustomVariant = async (prod, base) => {
    const cs = getCS(prod.id);
    if (!cs.input?.trim() || cs.loading) return;
    updCS(prod.id, { loading: true, result: null });
    try {
      const headers = {
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
      };
      if (apiKey.trim()) headers["x-api-key"] = apiKey.trim();
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: "claude-sonnet-4-6", max_tokens: 1000,
          system: "You are a luxury faux botanical render prompt specialist for Evercrafted. Modify Midjourney render prompts per user instructions. Preserve: asymmetric clock-position composition, matte silk/velvet faux materials, editorial product photography direction, exposed grapevine negative space, all --parameters. Return ONLY the modified prompt -- no preamble, no markdown.",
          messages: [{ role: "user", content: `Base prompt:\n${base}\n\nModification: ${cs.input.trim()}` }],
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      updCS(prod.id, { loading: false, result: data.content?.[0]?.text?.trim() || "No result." });
    } catch (err) {
      updCS(prod.id, { loading: false, result: `Error: ${err.message}` });
    }
  };

  const buildExportText = () => {
    const divider = "=".repeat(64);
    const lines = coll.products.map(p => {
      const hdr = `${divider}\n${p.name.toUpperCase()} . ${p.role}\n${p.scale} . ${p.formula} . ${p.price}\n${divider}`;
      const pts = Object.entries(p.prompts).map(([l, t]) => `-- ${l} --\n${fp(t)}`).join("\n\n");
      return `${hdr}\n\n${pts}`;
    }).join("\n\n\n");
    return `${coll.collectionName.toUpperCase()} -- RENDER PROMPTS\nEvercrafted Studio . ${coll.season}\n\n${lines}`;
  };

  const handleExportCopy = async () => {
    try {
      await navigator.clipboard.writeText(buildExportText());
      setExportCopied(true);
      setTimeout(() => setExportCopied(false), 2500);
    } catch {}
  };

  const removeCollection = idx => {
    const coll = collections[idx];
    if (collections.length <= 1) return;
    if (coll.id === 'quiet_accord' || coll.id === 'quiet_accord_full') return; // QA is permanent
    setCollections(p => p.filter((_, i) => i !== idx));
    setActiveIdx(p => p >= idx ? Math.max(0, p - 1) : p);
  };

  // --- RENDER -------------------------------------------
  return (
    <div style={{ background: T.pageBg, minHeight: "100vh", color: T.text1, fontFamily: "system-ui, -apple-system, sans-serif" }}>

      {/* -- API KEY BAR -- */}
      <div style={{ background: apiKey.trim() ? "#F0F7F0" : "#FFF8F0", borderBottom: `1px solid ${apiKey.trim() ? T.sageBd : "#E8C88A"}`, padding: "10px 24px", display: "flex", alignItems: "center", gap: "10px" }}>
        <div style={{ flexShrink: 0 }}>
          <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "2px" }}>Anthropic API Key</div>
          <div style={{ fontSize: "9px", color: apiKey.trim() ? T.done : "#8B6020" }}>{apiKey.trim() ? "  Connected" : "  Required for collection generation"}</div>
        </div>
        <input
          type="password"
          value={apiKey}
          onChange={e => setApiKey(e.target.value)}
          placeholder="Paste your Anthropic API key here -- sk-ant-api03-..."
          style={{ flex: 1, background: "#fff", border: `1px solid ${apiKey.trim() ? T.sageBd : "#E0B870"}`, borderRadius: "6px", color: T.text1, fontSize: "11px", padding: "7px 12px", outline: "none", fontFamily: "monospace" }}
        />
      </div>

      {/* -- HEADER -- */}
      <div style={{ background: T.cardBg, borderBottom: `1px solid ${T.border}`, padding: "20px 24px 0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: "10px", letterSpacing: "0.16em", color: T.text3, textTransform: "uppercase", marginBottom: "4px" }}>
              Evercrafted . Collection Render Studio
            </div>
            <div style={{ fontSize: "22px", fontWeight: "400", letterSpacing: "0.08em", color: T.text1 }}>
              {coll.collectionName.toUpperCase()}
            </div>
            <div style={{ fontSize: "11px", color: T.text3, marginTop: "3px", display: "flex", alignItems: "center", gap: "8px" }}>
              {coll.season} . {coll.atmosphere} . {coll.priceRange}
              {storageReady && <span style={{ fontSize: "9px", color: T.sageBd, letterSpacing: "0.08em" }}>  AUTO-SAVED</span>}
            </div>
            {coll.palette && (
              <div style={{ display: "flex", gap: "5px", marginTop: "8px", flexWrap: "wrap" }}>
                {coll.palette.map(c => (
                  <span key={c} style={{ fontSize: "10px", color: T.text2, background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "3px", padding: "2px 8px" }}>{c}</span>
                ))}
              </div>
            )}
            {coll.sightlineStory && (
              <div style={{ marginTop: "10px", padding: "10px 14px", background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "7px", maxWidth: "540px" }}>
                <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "4px" }}>Sightline Story</div>
                <div style={{ fontSize: "11px", color: T.text2, lineHeight: "1.6", fontStyle: "italic" }}>{coll.sightlineStory}</div>
              </div>
            )}
            {(coll.floralHierarchy || coll.ribbonJourney || coll.colorMovement) && (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", marginTop: "8px", maxWidth: "540px" }}>
                {coll.floralHierarchy && (
                  <div style={{ padding: "10px 12px", background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "7px" }}>
                    <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "6px" }}>Floral Hierarchy</div>
                    <div style={{ fontSize: "10px", color: T.text2, lineHeight: "1.7" }}>
                      <span style={{ color: T.text3 }}>T1 </span>{coll.floralHierarchy.tier1Signature}<br/>
                      <span style={{ color: T.text3 }}>T2 </span>{Array.isArray(coll.floralHierarchy.tier2Supporting) ? coll.floralHierarchy.tier2Supporting.join(" . ") : coll.floralHierarchy.tier2Supporting}<br/>
                      <span style={{ color: T.text3 }}>T3 </span>{Array.isArray(coll.floralHierarchy.tier3Discovery) ? coll.floralHierarchy.tier3Discovery.join(" . ") : coll.floralHierarchy.tier3Discovery}
                    </div>
                  </div>
                )}
                {coll.ribbonJourney && (
                  <div style={{ padding: "10px 12px", background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "7px" }}>
                    <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "6px" }}>Ribbon Journey</div>
                    <div style={{ fontSize: "10px", color: T.text2, lineHeight: "1.7" }}>
                      {Object.entries(coll.ribbonJourney).map(([layer, ribbons]) => (
                        <div key={layer}><span style={{ color: T.text3 }}>{layer} </span>{typeof ribbons === "object" ? ribbons.statement || Object.values(ribbons)[0] : ribbons}</div>
                      ))}
                    </div>
                  </div>
                )}
                {coll.colorMovement && (
                  <div style={{ padding: "10px 12px", background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "7px" }}>
                    <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "6px" }}>Color Movement</div>
                    <div style={{ fontSize: "10px", color: T.text2, lineHeight: "1.7" }}>
                      {Object.entries(coll.colorMovement).map(([k, v]) => (
                        <div key={k}><span style={{ color: T.text3 }}>{k.replace(/([A-Z])/g, ' $1').toLowerCase()} </span>{v}</div>
                      ))}
                    </div>
                  </div>
                )}
                {coll.greenerOnlyProducts?.length > 0 && (
                  <div style={{ padding: "10px 12px", background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "7px" }}>
                    <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "6px" }}>Greenery Only</div>
                    <div style={{ fontSize: "10px", color: T.text2, lineHeight: "1.7" }}>
                      {coll.greenerOnlyProducts.join(" . ")}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
          <div style={{ display: "flex", gap: "8px", marginTop: "2px" }}>
            <button onClick={() => { setShowExport(true); setExportCopied(false); }} style={Btn(T.cardBg, T.border, T.text2)}>  Export</button>
            <button onClick={() => { setShowIntent(true); setGenError(""); }} style={Btn(T.sageBg, T.sageBd, T.done, true)}>+ New Collection</button>
          </div>
        </div>

        {/* Collection tabs */}
        <div style={{ display: "flex", marginTop: "16px", overflowX: "auto", gap: "0" }}>
          {collections.map((c, i) => (
            <div key={c.id} onClick={() => setActiveIdx(i)}
              style={{ display: "flex", alignItems: "center", gap: "6px", padding: "8px 16px", cursor: "pointer", fontSize: "12px", fontWeight: i === activeIdx ? "500" : "400", color: i === activeIdx ? T.text1 : T.text3, borderBottom: i === activeIdx ? `2px solid ${T.sage}` : "2px solid transparent", whiteSpace: "nowrap", transition: "color 0.15s" }}>
              {c.collectionName}
              {collections.length > 1 && c.id !== 'quiet_accord' && c.id !== 'quiet_accord_full' && (
                <span onClick={e => { e.stopPropagation(); removeCollection(i); }} style={{ color: T.text3, fontSize: "14px", lineHeight: 1, padding: "0 2px", cursor: "pointer" }}>x</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* -- REFERENCE PANEL -- */}
      <div style={{ background: T.cardBg, borderBottom: `1px solid ${T.border}`, padding: "10px 24px", display: "flex", flexDirection: "column", gap: "7px" }}>

        {/* BOUQUET REFERENCE / oref row */}
        <div style={{ background: orefOn && orefUrl ? "#FFFDF5" : T.panelBg, border: `1px solid ${orefOn && orefUrl ? "#C4A862" : T.border}`, borderRadius: "7px", padding: "8px 12px", marginBottom: "2px" }}>
          <div style={{ fontSize: "9px", letterSpacing: "0.1em", textTransform: "uppercase", color: orefOn && orefUrl ? "#8B6A20" : T.text3, marginBottom: "6px", fontWeight: "500" }}>
            Step 1 -- Bouquet Reference for {coll.collectionName || coll.name || "Collection"} {orefOn && orefUrl ? "  ACTIVE -- injected into Hero / Variant A / Detail Crop" : "-- paste your hand-held bouquet render URL here"}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <button onClick={() => setOrefOn(o => !o)} style={{ ...Btn(orefOn ? "#FFF8E8" : T.panelBg, orefOn ? "#C4A862" : T.border, orefOn ? "#8B6A20" : T.text3), fontSize: "11px", whiteSpace: "nowrap", minWidth: "80px" }}>
              {orefOn ? "* ON" : "O OFF"}
            </button>
            <input value={orefUrl} onChange={e => setOrefUrl(e.target.value)}
              placeholder="Paste bouquet render URL -- this tells MJ the silk quality, palette, and floral character for every Phase 2 and Phase 3 render"
              style={{ flex: 1, background: "#fff", border: `1px solid ${orefUrl && orefOn ? "#C4A862" : "#E0D8C8"}`, borderRadius: "6px", color: T.text1, fontSize: "11px", padding: "6px 10px", outline: "none", fontFamily: "monospace" }}
            />
            <span style={{ fontSize: "10px", color: T.text3, whiteSpace: "nowrap" }}>--ow</span>
            <input type="number" value={orefWeight} onChange={e => setOrefWeight(+e.target.value)} min="50" max="300" step="25"
              style={{ width: "56px", background: "#fff", border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text1, fontSize: "11px", padding: "6px 8px", outline: "none", textAlign: "center" }}
            />
          </div>
          {!orefUrl && <div style={{ fontSize: "9px", color: "#B0A080", marginTop: "5px" }}>Run the hand-held bouquet prompt first in MJ -- upscale the best result -- paste its URL here -- then toggle ON before copying Hero / Variant A / Detail Crop prompts.</div>}
          {/* Bouquet prompt -- always visible so you can copy and run it */}
          {(() => {
            const bqPrompt = buildCollectionBouquetPrompt(coll);
            const bqCk = `${coll.id}|bouquet`;
            return (
              <div style={{ marginTop: "8px", borderTop: `1px solid ${orefOn && orefUrl ? "#D4B872" : T.border}`, paddingTop: "8px" }}>
                <div style={{ fontSize: "9px", letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A8A70", marginBottom: "5px" }}>
                  {coll.collectionName || coll.name || "Collection"} Bouquet Prompt -- copy, run in MJ, upscale best result, paste URL above
                </div>
                <textarea readOnly value={bqPrompt} onClick={e => e.target.select()}
                  style={{ width: "100%", height: "72px", background: "#fff", border: `1px solid #E0D8C8`, borderRadius: "6px", color: T.text2, fontSize: "9.5px", lineHeight: "1.6", padding: "7px 10px", resize: "none", fontFamily: "monospace", boxSizing: "border-box", cursor: "text" }}
                />
                <button onClick={async () => { try { await navigator.clipboard.writeText(bqPrompt); setCopied(p => ({...p, [bqCk]: true})); setTimeout(() => setCopied(p => ({...p, [bqCk]: false})), 2000); } catch {} }}
                  style={{ ...Btn(copied[bqCk] ? T.doneBg : "#FFF8E8", copied[bqCk] ? T.doneBd : "#D4B872", copied[bqCk] ? T.done : "#8B6A20"), marginTop: "5px", width: "100%", fontSize: "10px", padding: "7px" }}>
                  {copied[bqCk] ? "  Copied -- paste into Midjourney" : `Copy ${coll.collectionName || coll.name || "Collection"} Bouquet Prompt`}
                </button>
              </div>
            );
          })()}
        </div>

        {/* --sref row */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <button onClick={() => setSrefOn(o => !o)} style={{ ...Btn(srefOn ? "#FFF3E8" : T.panelBg, srefOn ? "#E0B888" : T.border, srefOn ? "#8B5E20" : T.text3), fontSize: "11px", whiteSpace: "nowrap", minWidth: "96px" }}>
            {srefOn ? "  --sref on" : "  --sref off"}
          </button>
          <input value={srefUrl} onChange={e => setSrefUrl(e.target.value)}
            placeholder="Paste scale reference image URL -- shows MJ correct floral proportions and wreath scale (--sref)"
            style={{ flex: 1, background: T.inputBg, border: `1px solid ${srefUrl && srefOn ? "#E0B888" : T.border}`, borderRadius: "6px", color: T.text1, fontSize: "11px", padding: "6px 10px", outline: "none", fontFamily: "monospace" }}
          />
          <div style={{ display: "flex", alignItems: "center", gap: "6px", flexShrink: 0 }}>
            <span style={{ fontSize: "10px", color: T.text3, whiteSpace: "nowrap" }}>--sw</span>
            <input
              type="number" min="50" max="1000" step="50"
              value={srefWeight}
              onChange={e => setSrefWeight(Number(e.target.value))}
              style={{ width: "58px", background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text1, fontSize: "11px", padding: "5px 8px", outline: "none", textAlign: "center" }}
            />
            <span style={{ fontSize: "10px", color: T.text3, whiteSpace: "nowrap" }}>scale ref</span>
          </div>
        </div>

      </div>

      {/* -- PROGRESS -- */}
      <div style={{ padding: "12px 24px 0", display: "flex", alignItems: "center", gap: "10px" }}>
        <span style={{ fontSize: "10px", color: T.text3, whiteSpace: "nowrap" }}>{doneCount}/{coll.products.length} rendered</span>
        <div style={{ display: "flex", gap: "3px", flex: 1 }}>
          {coll.products.map(p => (
            <div key={p.id} style={{ flex: 1, height: "3px", borderRadius: "2px", background: isDone(p.id) ? (RS[p.role]?.badge || T.sage) : T.border, transition: "background 0.3s" }} />
          ))}
        </div>
        <span style={{ fontSize: "10px", color: T.text3 }}>{coll.priceRange}</span>
      </div>

      {/* -- PRODUCT CARDS -- */}
      <div style={{ padding: "14px 24px 40px", display: "flex", flexDirection: "column", gap: "10px" }}>
        {coll.products.map(prod => {
          const rs = RS[prod.role] || RS["Accent"];
          const done = isDone(prod.id);
          const tab = getTab(prod);
          const base = prod.prompts[tab] || "";
          const puk  = k(prod.id);
          const pu   = phaseUrls[puk] || {};
          // Only Hero, Variant A, and Detail Crop get the full compiled prompt assembly.
          // Greenery Base, Phase 1/2/3, and Sketch are raw -- no injection, no conflicts.
          const INJECT_TABS = new Set(["Hero", "Variant A", "Detail Crop"]);
          const skipRefs    = !INJECT_TABS.has(tab);
          const greeneryUrl = greeneryUrls[puk] || "";
          const resolvedBase = base
            .replace('[PASTE PHASE 1 URL HERE]', pu.phase1 || '[PASTE PHASE 1 URL HERE]')
            .replace('[PASTE PHASE 2 URL HERE]', pu.phase2 || '[PASTE PHASE 2 URL HERE]');
          // If product has a blueprint and we're on an inject tab, build from blueprint data.
          // Otherwise use stored/resolved prompt text. Blueprint source is shown in UI.
          const hasBlueprintPrompt = !skipRefs && !!prod.blueprint;
          const baseForDisplay     = hasBlueprintPrompt ? buildHeroFromBlueprint(prod, coll, tab) : resolvedBase;
          const display = fp(baseForDisplay, skipRefs, skipRefs ? "" : greeneryUrl);
          const ck = k(prod.id, tab);
          const cs = getCS(prod.id);
          const imgKey = k(prod.id);
          const imgData = imageUrls[imgKey] || {};
          const sketchUrl = imgData.sketch || "";
          const colorUrl  = imgData.color  || "";
          const displayImg = sketchUrl || colorUrl;
          const isImgHovered = hoveredImg === imgKey;
          const showingImgInput = showImgInput[imgKey];

          return (
            <div key={prod.id} style={{ background: T.cardBg, border: `1px solid ${done ? rs.border : T.border}`, borderRadius: "10px", overflow: "hidden", boxShadow: "0 1px 4px rgba(0,0,0,0.04)", transition: "border-color 0.3s" }}>

              {/* -- SKETCH-TO-COLOR IMAGE REVEAL -- */}
              {displayImg && (
                <div
                  style={{ position: "relative", cursor: "pointer", lineHeight: 0, overflow: "hidden", background: sketchUrl ? "#F5F1EB" : T.cardBg }}
                  onMouseEnter={() => setHoveredImg(imgKey)}
                  onMouseLeave={() => setHoveredImg(null)}
                  onClick={() => setExpandedImg(colorUrl || sketchUrl)}
                >
                  {/* Sketch layer -- shows by default */}
                  {sketchUrl && (
                    <img src={sketchUrl} alt={`${prod.name} sketch`}
                      style={{
                        width: "100%", display: "block", maxHeight: "240px",
                        objectFit: "cover", objectPosition: "center top",
                        opacity: isImgHovered && colorUrl ? 0 : 1,
                        transition: "opacity 0.85s cubic-bezier(0.4,0,0.2,1)",
                        position: sketchUrl && colorUrl ? "absolute" : "relative",
                        top: 0, left: 0,
                      }}
                    />
                  )}
                  {/* Color layer -- reveals on hover */}
                  {colorUrl && (
                    <img src={colorUrl} alt={`${prod.name} color`}
                      style={{
                        width: "100%", display: "block", maxHeight: "240px",
                        objectFit: "cover", objectPosition: "center top",
                        opacity: isImgHovered || !sketchUrl ? 1 : 0,
                        transition: "opacity 0.85s cubic-bezier(0.4,0,0.2,1)",
                        filter: !sketchUrl && !isImgHovered
                          ? "grayscale(100%) contrast(1.9) brightness(1.12) sepia(10%)"
                          : "none",
                      }}
                    />
                  )}
                  {/* Hover hint -- sketch only state */}
                  {!isImgHovered && colorUrl && (
                    <div style={{
                      position: "absolute", inset: 0, pointerEvents: "none",
                      background: "linear-gradient(to top, rgba(245,241,235,0.4) 0%, transparent 60%)",
                      display: "flex", alignItems: "flex-end", justifyContent: "center", paddingBottom: "10px"
                    }}>
                      <span style={{ fontSize: "9px", letterSpacing: "0.2em", color: "rgba(44,40,32,0.45)", textTransform: "uppercase", fontWeight: "500" }}>
                        hover to reveal color
                      </span>
                    </div>
                  )}
                  {/* Click hint on hover */}
                  {isImgHovered && (
                    <div style={{
                      position: "absolute", top: "10px", right: "10px",
                      background: "rgba(255,255,255,0.92)", borderRadius: "4px",
                      padding: "3px 10px", fontSize: "9px", letterSpacing: "0.1em",
                      color: T.text2, textTransform: "uppercase", fontWeight: "500",
                      boxShadow: "0 1px 4px rgba(0,0,0,0.08)"
                    }}>
                        expand
                    </div>
                  )}
                </div>
              )}

              {/* Card header */}
              <div style={{ padding: "13px 16px 10px", display: "flex", justifyContent: "space-between", alignItems: "flex-start", background: done ? rs.bg : T.cardBg, transition: "background 0.3s" }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "7px", flexWrap: "wrap", marginBottom: "4px" }}>
                    <span style={{ background: rs.badge, color: "#fff", fontSize: "9px", fontWeight: "600", padding: "2px 8px", borderRadius: "3px", letterSpacing: "0.06em", textTransform: "uppercase" }}>{prod.role}</span>
                    {done && <span style={{ fontSize: "10px", color: T.done, fontWeight: "500" }}>  Rendered</span>}
                    {prod.note && <span style={{ fontSize: "10px", color: T.sage }}>{prod.note}</span>}
                  </div>
                  <div style={{ fontSize: "14px", fontWeight: "500", color: T.text1 }}>{prod.name}</div>
                  <div style={{ fontSize: "10px", color: T.text3, marginTop: "2px" }}>{prod.scale} . {prod.formula} . {prod.price}{prod.blueprint ? <span style={{ color: T.sage, marginLeft: "8px", fontWeight: "500" }}>Blueprint {prod.blueprint.blueprint_id}</span> : ""}</div>
                </div>
                <button onClick={() => toggleDone(prod.id)} style={{ ...Btn(done ? T.doneBg : T.panelBg, done ? T.doneBd : T.border, done ? T.done : T.text2), fontSize: "11px", flexShrink: 0, marginLeft: "10px" }}>
                  {done ? "  Done" : "Mark Done"}
                </button>
              </div>

              {/* Tabs -- Greenery Base always first, then AI-generated prompt keys */}
              {(() => {
                const gbPrompt = prod.prompts["Greenery Base"] || buildGreeneryBase(prod, coll);
                // Phase 1/2/3 are the old sequential pipeline -- not used in the new workflow
                const HIDDEN_TABS = new Set(["Phase 1", "Phase 2", "Phase 3"]);
                const aiTabs   = Object.keys(prod.prompts).filter(t => t !== "Greenery Base" && !HIDDEN_TABS.has(t));
                const allTabs  = ["Greenery Base", ...aiTabs];
                const isGB     = tab === "Greenery Base";
                const gbCk     = k(prod.id, "Greenery Base");
                return (
                  <>
                    {/* Tab bar */}
                    <div style={{ display: "flex", borderTop: `1px solid ${T.border}`, borderBottom: `1px solid ${T.border}`, overflowX: "auto" }}>
                      {allTabs.map(t => (
                        <button key={t} onClick={() => setTab(prod.id, t)} style={{
                          flexShrink: 0, padding: "7px 10px", background: t === "Greenery Base" && tab === "Greenery Base" ? "#F0F7F2" : "transparent",
                          border: "none",
                          borderBottom: t === tab ? `2px solid ${t === "Greenery Base" ? T.sage : rs.badge}` : "2px solid transparent",
                          color: t === tab ? (t === "Greenery Base" ? T.sage : T.text1) : T.text3,
                          fontSize: "10px", cursor: "pointer",
                          fontWeight: t === tab ? "500" : "400", transition: "color 0.15s",
                        }}>{t}</button>
                      ))}
                    </div>

                    {/* Greenery Base tab content -- prompt + copy + URL paste in one place */}
                    {isGB && (
                      <div style={{ padding: "11px 16px 0", background: "#F8FCF8" }}>
                        <div style={{ fontSize: "9px", letterSpacing: "0.1em", textTransform: "uppercase", color: T.sage, marginBottom: "6px", fontWeight: "600" }}>
                          Greenery Base Prompt -- {greeneryUrl ? "URL pasted below" : "run in MJ, upscale best, paste URL below"}
                        </div>
                        <textarea readOnly value={gbPrompt} onClick={e => e.target.select()}
                          style={{ width: "100%", height: "88px", background: "#fff", border: `1px solid ${T.sageBd}`, borderRadius: "6px", color: T.text2, fontSize: "10.5px", lineHeight: "1.65", padding: "9px 11px", resize: "none", fontFamily: "monospace", boxSizing: "border-box", cursor: "text" }}
                        />
                        <button onClick={() => doCopy(gbPrompt, gbCk)} style={{ ...Btn(copied[gbCk] ? T.doneBg : "#F0F7F2", copied[gbCk] ? T.doneBd : T.sageBd, copied[gbCk] ? T.done : T.sage), marginTop: "6px", width: "100%", fontSize: "11px", padding: "8px" }}>
                          {copied[gbCk] ? "  Copied -- paste into Midjourney" : "Copy Greenery Base Prompt"}
                        </button>
                        {/* URL paste field */}
                        <div style={{ marginTop: "10px", padding: "10px 12px", background: greeneryUrl ? T.doneBg : "#fff", border: `1px solid ${greeneryUrl ? T.doneBd : T.sageBd}`, borderRadius: "6px" }}>
                          <div style={{ fontSize: "9px", color: greeneryUrl ? T.done : T.sage, marginBottom: "5px", fontWeight: "600", letterSpacing: "0.08em", textTransform: "uppercase" }}>
                            {greeneryUrl ? "  Greenery Base URL active -- auto-injects as --iw 2 into Hero / Variant A / Detail Crop" : "Paste Greenery Base Result URL"}
                          </div>
                          <input
                            value={greeneryUrl}
                            onChange={e => setGreeneryUrls(p => ({ ...p, [puk]: e.target.value }))}
                            placeholder="Upscale the best Greenery Base result in MJ -- paste its URL here"
                            style={{ width: "100%", background: "#fff", border: `1px solid ${greeneryUrl ? T.doneBd : "#D4C8C0"}`, borderRadius: "5px", color: T.text1, fontSize: "10px", padding: "6px 9px", outline: "none", fontFamily: "monospace", boxSizing: "border-box" }}
                          />
                          {greeneryUrl && orefOn && orefUrl && (
                            <div style={{ fontSize: "8px", color: T.done, marginTop: "5px", fontFamily: "monospace" }}>
                              Final compiled: [greenery URL] [prompt] --iw 2 --oref [bouquet] --ow {orefWeight} --ar ...
                            </div>
                          )}
                          {greeneryUrl && (!orefOn || !orefUrl) && (
                            <div style={{ fontSize: "8px", color: T.sage, marginTop: "5px" }}>
                              Greenery Base active. Activate Bouquet Reference above to also inject --oref.
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* All other tabs -- normal prompt display */}
                    {!isGB && (
                      <div style={{ padding: "11px 16px 0" }}>
                        <textarea readOnly value={display} onClick={e => e.target.select()}
                          style={{ width: "100%", height: "100px", background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text2, fontSize: "10.5px", lineHeight: "1.65", padding: "9px 11px", resize: "none", fontFamily: "monospace", boxSizing: "border-box", cursor: "text" }}
                        />
                        <button onClick={() => doCopy(display, ck)} style={{ ...Btn(copied[ck] ? T.doneBg : T.panelBg, copied[ck] ? T.doneBd : T.border, copied[ck] ? T.done : T.text1, copied[ck]), marginTop: "6px", width: "100%", fontSize: "11px", padding: "8px" }}>
                          {copied[ck] ? "  Copied to clipboard" : "Copy Prompt"}
                        </button>
                      </div>
                    )}
                  </>
                );
              })()}

              {/* -- IMAGE URL INPUTS -- */}
              <div style={{ padding: "0 16px 10px" }}>
                <button
                  onClick={() => setShowImgInput(p => ({ ...p, [imgKey]: !p[imgKey] }))}
                  style={{ background: "transparent", border: "none", color: T.text3, fontSize: "10px", cursor: "pointer", padding: "0", display: "flex", alignItems: "center", gap: "5px" }}
                >
                  <span style={{ display: "inline-block", transition: "transform 0.2s", transform: showingImgInput ? "rotate(90deg)" : "none" }}> </span>
                  {displayImg ? "Update render images" : "Add render images"}
                </button>
                {showingImgInput && (
                  <div style={{ marginTop: "8px", display: "flex", flexDirection: "column", gap: "6px" }}>
                    <div>
                      <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "4px" }}>Sketch / Illustration URL</div>
                      <div style={{ display: "flex", gap: "6px" }}>
                        <input
                          value={imgInputVals[`${imgKey}-sketch`] || sketchUrl}
                          onChange={e => setImgInputVals(p => ({ ...p, [`${imgKey}-sketch`]: e.target.value }))}
                          placeholder="Paste MJ sketch render URL..."
                          style={{ flex: 1, background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text1, fontSize: "10px", padding: "5px 8px", outline: "none", fontFamily: "monospace" }}
                        />
                        <button
                          onClick={() => {
                            const val = imgInputVals[`${imgKey}-sketch`] || "";
                            setImageUrls(p => ({ ...p, [imgKey]: { ...(p[imgKey] || {}), sketch: val } }));
                          }}
                          style={{ ...Btn(T.sageBg, T.sageBd, T.done), fontSize: "10px", padding: "5px 10px", flexShrink: 0 }}
                        >Set</button>
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "4px" }}>Color Render URL</div>
                      <div style={{ display: "flex", gap: "6px" }}>
                        <input
                          value={imgInputVals[`${imgKey}-color`] || colorUrl}
                          onChange={e => setImgInputVals(p => ({ ...p, [`${imgKey}-color`]: e.target.value }))}
                          placeholder="Paste MJ color render URL..."
                          style={{ flex: 1, background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text1, fontSize: "10px", padding: "5px 8px", outline: "none", fontFamily: "monospace" }}
                        />
                        <button
                          onClick={() => {
                            const val = imgInputVals[`${imgKey}-color`] || "";
                            setImageUrls(p => ({ ...p, [imgKey]: { ...(p[imgKey] || {}), color: val } }));
                          }}
                          style={{ ...Btn(T.sageBg, T.sageBd, T.done), fontSize: "10px", padding: "5px 10px", flexShrink: 0 }}
                        >Set</button>
                      </div>
                    </div>
                    {displayImg && (
                      <button
                        onClick={() => { setImageUrls(p => ({ ...p, [imgKey]: {} })); setImgInputVals(p => ({ ...p, [`${imgKey}-sketch`]: "", [`${imgKey}-color`]: "" })); }}
                        style={{ ...Btn(T.panelBg, T.border, T.text3), fontSize: "9px", padding: "4px 10px", alignSelf: "flex-start" }}
                      >Clear images</button>
                    )}
                  </div>
                )}
              </div>

              {/* Custom variant */}
              <div style={{ padding: "8px 16px 14px" }}>
                <button onClick={() => updCS(prod.id, { open: !cs.open })} style={{ background: "transparent", border: "none", color: T.text3, fontSize: "10px", cursor: "pointer", padding: "0", display: "flex", alignItems: "center", gap: "5px" }}>
                  <span style={{ display: "inline-block", transition: "transform 0.2s", transform: cs.open ? "rotate(90deg)" : "none" }}> </span>
                  Generate Custom Variant via Claude
                </button>
                {cs.open && (
                  <div style={{ marginTop: "8px" }}>
                    <textarea value={cs.input || ""} onChange={e => updCS(prod.id, { input: e.target.value })}
                      placeholder={`e.g. "adapt for spring with blush ranunculus" . "moody evening light" . "burgundy and dusty rose"`}
                      style={{ width: "100%", height: "50px", background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text1, fontSize: "10.5px", lineHeight: "1.5", padding: "8px 10px", resize: "none", fontFamily: "system-ui, sans-serif", boxSizing: "border-box", outline: "none" }}
                    />
                    <button onClick={() => handleCustomVariant(prod, base)} disabled={cs.loading || !cs.input?.trim()}
                      style={{ ...Btn(T.panelBg, T.borderMed, T.text2), marginTop: "5px", width: "100%", fontSize: "11px", padding: "7px", cursor: cs.loading ? "wait" : "pointer", opacity: cs.loading || !cs.input?.trim() ? 0.5 : 1 }}>
                      {cs.loading ? "Generating..." : "Generate with Claude ->"}
                    </button>
                    {cs.result && (
                      <div style={{ marginTop: "7px" }}>
                        <textarea readOnly value={cs.result} onClick={e => e.target.select()}
                          style={{ width: "100%", height: "100px", background: T.doneBg, border: `1px solid ${T.doneBd}`, borderRadius: "6px", color: T.done, fontSize: "10.5px", lineHeight: "1.65", padding: "9px 11px", resize: "none", fontFamily: "monospace", boxSizing: "border-box" }}
                        />
                        <button onClick={() => doCopy(cs.result, k(prod.id, "custom"))}
                          style={{ ...Btn(T.doneBg, T.doneBd, T.done), marginTop: "4px", width: "100%", fontSize: "11px", padding: "6px" }}>
                          {copied[k(prod.id, "custom")] ? "  Copied" : "Copy Custom Variant"}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div style={{ borderTop: `1px solid ${T.border}`, background: T.cardBg, padding: "12px 24px", display: "flex", justifyContent: "space-between" }}>
        <span style={{ fontSize: "10px", color: T.text3, letterSpacing: "0.06em" }}>EVERCRAFTED . COLLECTION RENDER STUDIO</span>
        <span style={{ fontSize: "10px", color: T.text3 }}>{doneCount} of {coll.products.length} complete</span>
      </div>

      {/* ============================================
          IMAGE LIGHTBOX
      ============================================ */}
      {expandedImg && (
        <div
          onClick={() => setExpandedImg(null)}
          style={{ position: "fixed", inset: 0, background: "rgba(20,16,12,0.92)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 200, padding: "20px", cursor: "zoom-out" }}
        >
          <div style={{ position: "relative", maxWidth: "92vw", maxHeight: "90vh" }}>
            <img
              src={expandedImg}
              style={{ maxWidth: "100%", maxHeight: "90vh", objectFit: "contain", borderRadius: "8px", boxShadow: "0 24px 80px rgba(0,0,0,0.6)" }}
              onClick={e => e.stopPropagation()}
            />
            <button
              onClick={() => setExpandedImg(null)}
              style={{ position: "absolute", top: "-14px", right: "-14px", background: "rgba(255,255,255,0.95)", border: "none", borderRadius: "50%", width: "32px", height: "32px", fontSize: "16px", cursor: "pointer", color: "#2C2820", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 2px 8px rgba(0,0,0,0.3)" }}
            >x</button>
          </div>
        </div>
      )}

      {/* ============================================
          EXPORT MODAL
      ============================================ */}
      {showExport && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(44,40,32,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: "20px" }}>
          <div style={{ background: T.cardBg, border: `1px solid ${T.border}`, borderRadius: "14px", width: "100%", maxWidth: "640px", maxHeight: "80vh", display: "flex", flexDirection: "column", overflow: "hidden", boxShadow: "0 8px 40px rgba(0,0,0,0.12)" }}>

            {/* Modal header */}
            <div style={{ padding: "18px 22px", borderBottom: `1px solid ${T.border}`, display: "flex", justifyContent: "space-between", alignItems: "center", flexShrink: 0 }}>
              <div>
                <div style={{ fontSize: "10px", letterSpacing: "0.12em", color: T.text3, textTransform: "uppercase", marginBottom: "3px" }}>Export Prompts</div>
                <div style={{ fontSize: "15px", fontWeight: "500", color: T.text1 }}>{coll.collectionName} -- {coll.products.length} products . {Object.values(coll.products[0]?.prompts || {}).length * coll.products.length} prompts</div>
              </div>
              <button onClick={() => setShowExport(false)} style={{ background: "transparent", border: "none", color: T.text3, fontSize: "20px", cursor: "pointer", lineHeight: 1, padding: "0 4px" }}>x</button>
            </div>

            {/* Prompt textarea */}
            <textarea
              readOnly
              value={buildExportText()}
              onClick={e => e.target.select()}
              style={{ flex: 1, background: T.inputBg, border: "none", borderBottom: `1px solid ${T.border}`, color: T.text2, fontSize: "10.5px", lineHeight: "1.7", padding: "16px 20px", resize: "none", fontFamily: "monospace", outline: "none", overflowY: "auto" }}
            />

            {/* Footer actions */}
            <div style={{ padding: "14px 22px", display: "flex", alignItems: "center", gap: "10px", flexShrink: 0 }}>
              <div style={{ fontSize: "11px", color: T.text3, flex: 1 }}>
                Click the text area to select all . or use the copy button
              </div>
              <button onClick={() => setShowExport(false)} style={{ ...Btn(T.panelBg, T.border, T.text2), padding: "8px 18px", fontSize: "12px" }}>
                Close
              </button>
              <button onClick={handleExportCopy} style={{ ...Btn(exportCopied ? T.doneBg : T.sageBg, exportCopied ? T.doneBd : T.sageBd, exportCopied ? T.done : T.done, true), padding: "8px 22px", fontSize: "12px" }}>
                {exportCopied ? "  Copied" : "Copy All Prompts"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================
          INTENT OVERLAY
      ============================================ */}
      {showIntent && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(44,40,32,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: "20px" }}>
          <div style={{ background: T.cardBg, border: `1px solid ${T.border}`, borderRadius: "14px", width: "100%", maxWidth: "560px", overflow: "hidden", boxShadow: "0 8px 40px rgba(0,0,0,0.12)" }}>

            {isGenerating ? (
              <div style={{ padding: "48px 40px", textAlign: "center" }}>
                <div style={{ fontSize: "10px", letterSpacing: "0.16em", color: T.text3, textTransform: "uppercase", marginBottom: "20px" }}>Evercrafted . Building Collection</div>
                <div style={{ fontSize: "22px", fontWeight: "400", letterSpacing: "0.08em", color: T.text1, marginBottom: "6px" }}>
                  {intentForm.name ? intentForm.name.toUpperCase() : "NEW COLLECTION"}
                </div>
                <div style={{ fontSize: "11px", color: T.text3, marginBottom: "32px" }}>{intentForm.season || "Seasonal collection"}</div>

                <div style={{ display: "flex", flexDirection: "column", gap: "10px", maxWidth: "360px", margin: "0 auto 32px" }}>
                  {GEN_STEPS.map((step, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: i <= genStepIdx ? 1 : 0.25, transition: "opacity 0.4s" }}>
                      <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: i === genStepIdx ? T.sage : i < genStepIdx ? T.sageBd : T.border, flexShrink: 0, transition: "background 0.4s" }} />
                      <span style={{ fontSize: "12px", color: i === genStepIdx ? T.text1 : i < genStepIdx ? T.sage : T.text3, textAlign: "left" }}>{step}</span>
                    </div>
                  ))}
                </div>

                <div style={{ height: "2px", background: T.border, borderRadius: "1px", overflow: "hidden", maxWidth: "200px", margin: "0 auto" }}>
                  <div style={{ height: "100%", background: T.sage, borderRadius: "1px", animation: "pb 1.8s ease-in-out infinite" }} />
                </div>
                <style>{`@keyframes pb { 0%{width:0%} 50%{width:80%} 100%{width:100%} }`}</style>

                {genError && (
                  <div style={{ marginTop: "20px", padding: "10px 14px", background: "#FDF0F0", border: "1px solid #E0B8B8", borderRadius: "6px", color: "#8B3030", fontSize: "11px" }}>
                    {genError}
                    <button onClick={() => setIsGenerating(false)} style={{ ...Btn("#FDF0F0", "#E0B8B8", "#8B3030"), marginTop: "10px", width: "100%", fontSize: "11px" }}>Try Again</button>
                  </div>
                )}
              </div>
            ) : (
              <div>
                <div style={{ padding: "18px 24px 14px", borderBottom: `1px solid ${T.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: "10px", letterSpacing: "0.12em", color: T.text3, textTransform: "uppercase", marginBottom: "3px" }}>Evercrafted</div>
                    <div style={{ fontSize: "16px", fontWeight: "500", color: T.text1 }}>New Collection</div>
                  </div>
                  <button onClick={() => { setShowIntent(false); setGenError(""); }} style={{ background: "transparent", border: "none", color: T.text3, fontSize: "20px", cursor: "pointer", lineHeight: 1, padding: "0 4px" }}>x</button>
                </div>

                {/* Mode tabs */}
                <div style={{ display: "flex", borderBottom: `1px solid ${T.border}` }}>
                  {["Import JSON", "Generate via Claude"].map(tab => (
                    <button key={tab} onClick={() => setIntentForm(p => ({ ...p, _tab: tab }))}
                      style={{ flex: 1, padding: "10px 4px", background: "transparent", border: "none",
                        borderBottom: (intentForm._tab || "Import JSON") === tab ? `2px solid ${T.sage}` : "2px solid transparent",
                        color: (intentForm._tab || "Import JSON") === tab ? T.text1 : T.text3,
                        fontSize: "11px", cursor: "pointer",
                        fontWeight: (intentForm._tab || "Import JSON") === tab ? "500" : "400" }}>
                      {tab}
                    </button>
                  ))}
                </div>

                <div style={{ padding: "18px 24px" }}>
                  {(intentForm._tab || "Import JSON") === "Import JSON" ? (
                    <div>
                      <div style={{ fontSize: "11px", color: T.text2, marginBottom: "12px", lineHeight: "1.7" }}>
                        Ask Claude in the chat to generate a collection for you, then paste the JSON below.<br/>
                        <span style={{ color: T.text3, fontSize: "10px" }}>  Works on mobile . no API key needed</span>
                      </div>
                      <label style={Lbl}>Paste collection JSON</label>
                      <textarea
                        value={intentForm._json || ""}
                        onChange={e => setIntentForm(p => ({ ...p, _json: e.target.value }))}
                        placeholder={'{ "collectionName": "...", "products": [...] }'}
                        style={{ ...Inp(T), height: "150px", resize: "none", fontFamily: "monospace", fontSize: "10px" }}
                      />
                      {genError && (
                        <div style={{ margin: "10px 0 0", padding: "10px 14px", background: "#FDF0F0", border: "1px solid #E0B8B8", borderRadius: "6px", color: "#8B3030", fontSize: "11px" }}>{genError}</div>
                      )}
                      <div style={{ display: "flex", gap: "8px", marginTop: "12px" }}>
                        <button onClick={() => { setShowIntent(false); setGenError(""); }} style={{ ...Btn(T.panelBg, T.border, T.text2), flex: "0 0 auto", padding: "10px 18px", fontSize: "12px" }}>Cancel</button>
                        <button
                          onClick={() => {
                            try {
                              const raw = (intentForm._json || "").trim();
                              const s = raw.indexOf("{"), e = raw.lastIndexOf("}");
                              if (s === -1) throw new Error("No JSON found -- copy the full block from Claude");
                              const parsed = JSON.parse(raw.slice(s, e + 1));
                              if (!Array.isArray(parsed.products) || !parsed.products.length) throw new Error("Parsed OK but no products array found");
                              const newColl = { ...parsed, id: parsed.id || `coll_${Date.now()}` };
                              setCollections(prev => [...prev, newColl]);
                              setActiveIdx(collections.length);
                              setShowIntent(false);
                              setIntentForm({ name: "", season: "", brief: "", hero: "" });
                              setGenError("");
                            } catch(err) { setGenError(err.message); }
                          }}
                          disabled={!(intentForm._json || "").trim()}
                          style={{ ...Btn((intentForm._json || "").trim() ? T.sageBg : T.panelBg, (intentForm._json || "").trim() ? T.sageBd : T.border, (intentForm._json || "").trim() ? T.done : T.text3, true), flex: 1, fontSize: "13px", fontWeight: "500", padding: "10px", opacity: (intentForm._json || "").trim() ? 1 : 0.5 }}>
                          Add Collection ->
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "14px" }}>
                        <div><label style={Lbl}>Working name</label><input value={intentForm.name} onChange={e => setIntentForm(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Winter Solstice" style={Inp(T)} /></div>
                        <div><label style={Lbl}>Season & timing</label><input value={intentForm.season} onChange={e => setIntentForm(p => ({ ...p, season: e.target.value }))} placeholder="e.g. Late winter, Jan-Mar" style={Inp(T)} /></div>
                      </div>
                      <div style={{ marginBottom: "14px" }}>
                        <label style={{ ...Lbl, display: "flex", justifyContent: "space-between" }}>
                          <span>Collection intent <span style={{ color: T.err }}>*</span></span>
                          <span style={{ color: T.text3, fontWeight: "400" }}>Be evocative</span>
                        </label>
                        <textarea value={intentForm.brief} onChange={e => setIntentForm(p => ({ ...p, brief: e.target.value }))}
                          placeholder="Describe the feeling, atmosphere, mood, and world of this collection..."
                          style={{ ...Inp(T), height: "100px", resize: "none" }} />
                      </div>
                      <div style={{ marginBottom: "16px" }}>
                        <label style={Lbl}>Hero floral(s) <span style={{ color: T.text3, fontWeight: "400" }}>optional</span></label>
                        <input value={intentForm.hero} onChange={e => setIntentForm(p => ({ ...p, hero: e.target.value }))} placeholder="e.g. burgundy dahlias, moody ranunculus" style={Inp(T)} />
                      </div>
                      {genError && !isGenerating && (
                        <div style={{ marginBottom: "12px", padding: "10px 14px", background: "#FDF0F0", border: "1px solid #E0B8B8", borderRadius: "6px", color: "#8B3030", fontSize: "11px" }}>{genError}</div>
                      )}
                      <div style={{ display: "flex", gap: "8px" }}>
                        <button onClick={() => setShowIntent(false)} style={{ ...Btn(T.panelBg, T.border, T.text2), flex: "0 0 auto", padding: "10px 18px", fontSize: "12px" }}>Cancel</button>
                        <button onClick={handleGenerate} disabled={!intentForm.brief.trim()}
                          style={{ ...Btn(intentForm.brief.trim() ? T.sageBg : T.panelBg, intentForm.brief.trim() ? T.sageBd : T.border, intentForm.brief.trim() ? T.done : T.text3, true), flex: 1, fontSize: "13px", fontWeight: "500", padding: "10px", opacity: intentForm.brief.trim() ? 1 : 0.5 }}>
                          Generate with Claude ->
                        </button>
                      </div>
                      <div style={{ marginTop: "10px", fontSize: "10px", color: T.text3, textAlign: "center" }}>Requires API key . desktop recommended</div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// -- Style helpers -----------------------------------------
const Btn = (bg, border, color, bold = false) => ({
  background: bg, border: `1px solid ${border}`, borderRadius: "6px",
  color, cursor: "pointer", padding: "5px 12px",
  fontWeight: bold ? "500" : "400", transition: "all 0.15s"
});

const Lbl = {
  display: "block", fontSize: "10px", letterSpacing: "0.06em",
  textTransform: "uppercase", color: "#9C9690", marginBottom: "6px", fontWeight: "500"
};

const Inp = T => ({
  width: "100%", background: T.inputBg, border: `1px solid ${T.border}`,
  borderRadius: "6px", color: T.text1, fontSize: "12px",
  padding: "8px 12px", outline: "none", fontFamily: "system-ui, sans-serif",
  boxSizing: "border-box"
});

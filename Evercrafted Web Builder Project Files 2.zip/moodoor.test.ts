import { describe, expect, it } from "vitest";
import { appRouter, moodoorRenderStorageKey } from "./routers";
import { hashPassword, verifyPassword } from "./localAuth";
import { buildStudioPayload, calculateSimilarity, deriveFallbackVector } from "./moodoor";

describe("Moodoor restored backend contracts", () => {
  it("produces a strong seasonal-nostalgia vector for a remembered autumn porch", () => {
    const vector = deriveFallbackVector("A quiet September porch with cedar and old stories.");
    expect(vector.seasonal).toBeGreaterThan(0.8);
    expect(vector.nostalgia).toBeGreaterThan(0.85);
  });

  it("keeps identical emotional vectors at a full similarity score", () => {
    const vector = deriveFallbackVector("A quiet September porch with cedar and old stories.");
    expect(calculateSimilarity(vector, vector)).toBe(100);
  });

  it("creates the uploaded studio’s layered product workflow from a collection brief", () => {
    const payload = buildStudioPayload({ name: "Quiet Accord", season: "Winter", atmosphere: "Nordic calm", intent: "A quiet entry and dining room story.", palette: ["Ivory", "Sage"], sourceImageUrl: "/manus-storage/moodoor/reference-render.png", visualNotes: ["Open crescent"], renderPrompt: "Editorial render prompt" });
    expect(payload.products).toHaveLength(6);
    expect(payload.products.map((product) => product.layer)).toEqual([1, 1, 2, 3, 4, 4]);
    expect(payload.entryMethod).toBe("wreath-render-analysis");
    expect(payload.sourceImageUrl).toContain("/manus-storage/");
  });

  it("confirms that first-owner administrator bootstrap is configured without exposing the email", async () => {
    expect(process.env.MOODOOR_INITIAL_ADMIN_EMAIL).toBeTruthy();
    const caller = appRouter.createCaller({ user: null, req: {} as any, res: {} as any });
    await expect(caller.moodoor.ownerBootstrap()).resolves.toEqual({ configured: true });
  });

  it("stores password credentials as one-way hashes that verify only the original password", async () => {
    const encoded = await hashPassword("test-only-password-2026");
    expect(encoded).not.toContain("test-only-password-2026");
    await expect(verifyPassword("test-only-password-2026", encoded)).resolves.toBe(true);
    await expect(verifyPassword("wrong-password", encoded)).resolves.toBe(false);
  });

  it("only accepts render-analysis storage references owned by the signed-in administrator", () => {
    const ownUrl = "/manus-storage/moodoor/admin/14/reference-renders/wreath_abc123.png";
    expect(moodoorRenderStorageKey(ownUrl, 14)).toBe("moodoor/admin/14/reference-renders/wreath_abc123.png");
    expect(() => moodoorRenderStorageKey("/manus-storage/moodoor/admin/15/reference-renders/other.png", 14)).toThrow("not an owned Moodoor reference image");
  });
});

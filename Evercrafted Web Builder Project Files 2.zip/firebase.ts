/** Moodoor full React port: external Firebase calls are replaced by browser-local services. */
export const app = null;
export const auth = null;
export const googleProvider = null;
export const db = null;

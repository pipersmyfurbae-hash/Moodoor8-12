/** Moodoor full React port: preserves the uploaded auth contract with browser-local preview sessions. */
import React, { createContext, useContext, useEffect, useState } from "react";

export interface CustomUser { uid: string; displayName: string | null; email: string | null; photoURL: string | null; isGuest: boolean; }
interface AuthContextType { user: CustomUser | null; loading: boolean; error: string | null; signInWithGoogle: () => Promise<void>; signInWithEmail: (email: string, pass: string, isSignUp: boolean, name?: string) => Promise<void>; signInAsGuest: (name: string) => void; logout: () => Promise<void>; }
const AuthContext = createContext<AuthContextType | undefined>(undefined);
const key = "moodoor_preview_user";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<CustomUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error] = useState<string | null>(null);
  useEffect(() => { try { const stored = localStorage.getItem(key); if (stored) setUser(JSON.parse(stored)); } finally { setLoading(false); } }, []);
  const persist = (next: CustomUser) => { localStorage.setItem(key, JSON.stringify(next)); setUser(next); };
  const signInWithGoogle = async () => persist({ uid: `guest_${Date.now()}`, displayName: "Moodoor Guest", email: "guest@moodoor.local", photoURL: null, isGuest: true });
  const signInWithEmail = async (email: string, _pass: string, _isSignUp: boolean, name?: string) => persist({ uid: `local_${Date.now()}`, displayName: name || email.split("@")[0], email, photoURL: null, isGuest: false });
  const signInAsGuest = (name: string) => persist({ uid: `guest_${Date.now()}`, displayName: name || "Artisan Guest", email: "guest@moodoor.local", photoURL: null, isGuest: true });
  const logout = async () => { localStorage.removeItem(key); setUser(null); };
  return <AuthContext.Provider value={{ user, loading, error, signInWithGoogle, signInWithEmail, signInAsGuest, logout }}>{children}</AuthContext.Provider>;
}
export function useAuth() { const context = useContext(AuthContext); if (!context) throw new Error("useAuth must be used within an AuthProvider"); return context; }

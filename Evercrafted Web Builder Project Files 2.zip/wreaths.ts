import { WreathDesign, Territory } from "../types";

export const TERRITORIES: Territory[] = [
  {
    id: 1,
    name: "Comfort",
    numberRoman: "I",
    tagline: "The wreath equivalent of a familiar room.",
    description: "Soft texture, warm neutrals, low contrast, bottom-settled weight. Comfort designs don't announce themselves — they make a doorway feel like it's been yours for years.",
    signature: { warmth: 0.85, intimacy: 0.75, energy: 0.25 },
    sampleWreaths: ["Linen & Cedar", "Quiet Hearth", "Sunday Bread"],
    gradientClass: "from-off-white to-[#EEF2ED]", // green-pale
    visualBgClass: "bg-gradient-to-br from-[#F9F7F4] to-[#EEF2ED]"
  },
  {
    id: 2,
    name: "Celebration",
    numberRoman: "II",
    tagline: "Lifted energy for arrivals, milestones, and good news.",
    description: "Bright focal hierarchy, upper-weighted clusters, the most movement in the library. Celebration designs are for thresholds people walk through smiling.",
    signature: { valence: 0.90, energy: 0.85, restraint: 0.25 },
    sampleWreaths: ["First Light", "Gathered Grace"],
    gradientClass: "from-off-white to-[rgba(196,146,42,0.13)]",
    visualBgClass: "bg-gradient-to-br from-[#F9F7F4] to-[rgba(196,146,42,0.13)]"
  },
  {
    id: 3,
    name: "Remembrance",
    numberRoman: "III",
    tagline: "Designed to honor, not decorate.",
    description: "The most restrained compositions in the library — deliberate negative space, hushed palettes, exposed vine carrying as much meaning as the blooms. Built for memories that are heavy and worth holding.",
    signature: { restraint: 0.85, intimacy: 0.85, energy: 0.15 },
    sampleWreaths: ["Legacy Garden", "White Hour", "Kept Letters"],
    gradientClass: "from-white to-[#F2EFE9]", // paper
    visualBgClass: "bg-gradient-to-br from-[#FFFFFF] to-[#F2EFE9]"
  },
  {
    id: 4,
    name: "Renewal",
    numberRoman: "IV",
    tagline: "Fresh greens, upward movement, beginnings.",
    description: "Diagonal flow, climbing greenery, the lightest material weight in the library. Renewal designs mark the after — new homes, recoveries, first springs.",
    signature: { valence: 0.80, seasonal: 0.70, nostalgia: 0.25 },
    sampleWreaths: ["Green Morning"],
    gradientClass: "from-[#EEF2ED] to-white",
    visualBgClass: "bg-gradient-to-br from-[#EEF2ED] to-[#FFFFFF]"
  },
  {
    id: 5,
    name: "Connection",
    numberRoman: "V",
    tagline: "Interwoven materials, paired clusters, shared weight.",
    description: "Twin compositions where two clusters balance each other across the vine — designs about the people a home holds, built on the library's most intimate profiles.",
    signature: { intimacy: 0.90, warmth: 0.80, seasonal: 0.30 },
    sampleWreaths: ["The Long Table"],
    gradientClass: "from-white to-[rgba(74,103,133,0.10)]",
    visualBgClass: "bg-gradient-to-br from-[#FFFFFF] to-[rgba(74,103,133,0.10)]"
  },
  {
    id: 6,
    name: "Seasonal Nostalgia",
    numberRoman: "VI",
    tagline: "Octobers and Decembers you can almost smell.",
    description: "The territory where memory and season fuse — designs anchored so firmly to a time of year that hanging one changes what month it feels like inside. The library's highest nostalgia and seasonal scores live here.",
    signature: { nostalgia: 0.95, seasonal: 0.95, energy: 0.30 },
    sampleWreaths: ["September Porch", "Cider House", "Last Bonfire"],
    gradientClass: "from-[#F2EFE9] to-[rgba(196,146,42,0.14)]",
    visualBgClass: "bg-gradient-to-br from-[#F2EFE9] to-[rgba(196,146,42,0.14)]"
  }
];

export const WREATHS: WreathDesign[] = [
  {
    id: "BP-EC-0417",
    name: "September Porch",
    territoryId: 6,
    territoryName: "Seasonal Nostalgia",
    tagline: "Cedar, cold coffee, the screen door.",
    description: "Three autumn compositions that share a toffee-and-amber palette and a low, warm center of gravity — sized and weighted differently so they read as one season moving through a house, not the same wreath three times.",
    bullets: [
      "18\" grapevine substrate — the front door anchor",
      "10:30 primary cluster: focal dahlia ×3",
      "4:30 counterweight: cedar + pips ×2",
      "9:00 → 11:00 greenery sweep extending outward",
      "Deliberate negative space at 1:00 – 3:30 preserved"
    ],
    priceFinished: 345,
    priceBlueprint: 39,
    totalStems: 23,
    size: "18\" grapevine",
    vector: {
      warmth: 0.82,
      energy: 0.35,
      nostalgia: 0.91,
      valence: 0.58,
      intimacy: 0.78,
      restraint: 0.64,
      seasonal: 0.95
    },
    remainingFinished: 2,
    accentColor: "toffee",
    svgPath: "september-porch"
  },
  {
    id: "BP-EC-0422",
    name: "Cider House",
    territoryId: 6,
    territoryName: "Seasonal Nostalgia",
    tagline: "Amber pips and warm spice tones.",
    description: "Fuller in volume and warmer in light, Cider House uses rich amber leaves and clustered pip berries to evoke late afternoons, slow conversation, and wood fires starting up.",
    bullets: [
      "20\" grapevine base — fuller scale for gathering rooms",
      "Toffee and warm amber spice tone palettes",
      "Highly textured multi-cluster side arrangement",
      "Clustered golden berry pips surrounding organic twigs"
    ],
    priceFinished: 365,
    priceBlueprint: 42,
    totalStems: 25,
    size: "20\" grapevine",
    vector: {
      warmth: 0.88,
      energy: 0.42,
      nostalgia: 0.87,
      valence: 0.65,
      intimacy: 0.72,
      restraint: 0.52,
      seasonal: 0.92
    },
    remainingFinished: 4,
    accentColor: "amber",
    svgPath: "cider-house"
  },
  {
    id: "BP-EC-0431",
    name: "Kept Letters",
    territoryId: 6,
    territoryName: "Seasonal Nostalgia",
    tagline: "Preserved paper tones, quiet.",
    description: "A soft, paper-toned companion wreath built of delicate birch leaves and dried strawflowers. Styled around quiet mornings, keeping records, and late autumn sunlight.",
    bullets: [
      "18\" grapevine base",
      "Strawflower clusters at 5:00 and 11:00",
      "Faded parchment birch leaf accents",
      "Muted, dusty neutral color palette"
    ],
    priceFinished: 325,
    priceBlueprint: 35,
    totalStems: 19,
    size: "18\" grapevine",
    vector: {
      warmth: 0.71,
      energy: 0.22,
      nostalgia: 0.93,
      valence: 0.48,
      intimacy: 0.84,
      restraint: 0.78,
      seasonal: 0.81
    },
    remainingFinished: 0, // Out of stock/resting
    accentColor: "parchment",
    svgPath: "kept-letters"
  },
  {
    id: "BP-EC-0438",
    name: "Last Bonfire",
    territoryId: 6,
    territoryName: "Seasonal Nostalgia",
    tagline: "Late season wood-smoke and ember accents.",
    description: "A dark, intense composition of charred cedar twigs, toasted oak leaves, and smoldering mustard berries. Perfect for late November and the quiet, frosty transition into winter.",
    bullets: [
      "20\" grapevine base",
      "Toasted amber oak leaf sweeps from 6:00 to 9:00",
      "Charred cedar sprigs at 3:00 and 10:00",
      "Golden mustard berries adding a warm ember-like glow"
    ],
    priceFinished: 380,
    priceBlueprint: 45,
    totalStems: 26,
    size: "20\" grapevine",
    vector: {
      warmth: 0.76,
      energy: 0.38,
      nostalgia: 0.89,
      valence: 0.45,
      intimacy: 0.75,
      restraint: 0.62,
      seasonal: 0.96
    },
    remainingFinished: 0, // resting
    accentColor: "ember",
    svgPath: "last-bonfire"
  },
  {
    id: "BP-EC-0402",
    name: "Linen & Cedar",
    territoryId: 1,
    territoryName: "Comfort",
    tagline: "Low contrast, soft texture, home.",
    description: "Comfort's anchor design. Crafted with thick cream-linen ribbon wraps, silver-dollar eucalyptus, and fragrant cedar sprigs. A soft, settling, and deeply grounding presence.",
    bullets: [
      "18\" grapevine base",
      "Cream linen ribbons intertwined through grapevine",
      "Bottom-weighted sprigs of blue cedar and eucalyptus",
      "Muted, low-contrast neutral palette"
    ],
    priceFinished: 295,
    priceBlueprint: 35,
    totalStems: 21,
    size: "18\" grapevine",
    vector: {
      warmth: 0.84,
      energy: 0.20,
      nostalgia: 0.76,
      valence: 0.70,
      intimacy: 0.82,
      restraint: 0.78,
      seasonal: 0.45
    },
    remainingFinished: 5,
    accentColor: "linen",
    svgPath: "linen-cedar"
  },
  {
    id: "BP-EC-0405",
    name: "Quiet Hearth",
    territoryId: 1,
    territoryName: "Comfort",
    tagline: "Bottom-weighted, settled, warm.",
    description: "Designed specifically to sit above mantels or on dense wooden doorways, Quiet Hearth clusters pine cones, sage foliage, and soft wool pods at its baseline, keeping the upper arch beautifully bare.",
    bullets: [
      "16\" grapevine base — compact and cozy",
      "Baseline cluster from 5:00 to 7:00",
      "Toasted pine cones paired with silver sage",
      "White felted wool accent pods for soft texture"
    ],
    priceFinished: 315,
    priceBlueprint: 32,
    totalStems: 18,
    size: "16\" grapevine",
    vector: {
      warmth: 0.89,
      energy: 0.18,
      nostalgia: 0.72,
      valence: 0.68,
      intimacy: 0.86,
      restraint: 0.82,
      seasonal: 0.52
    },
    remainingFinished: 3,
    accentColor: "slate",
    svgPath: "quiet-hearth"
  },
  {
    id: "BP-EC-0409",
    name: "Sunday Bread",
    territoryId: 1,
    territoryName: "Comfort",
    tagline: "Warm wheat-hues and morning light.",
    description: "Evokes early morning kitchens, baking bread, and first cups of tea. Made of dried golden wheat stalks, white strawberries, and fuzzy lamb's ear leaves.",
    bullets: [
      "20\" grapevine base",
      "Sweep of golden wheat stalks from 8:00 to 12:00",
      "White wild strawberry highlights at 9:30",
      "Fuzzy sage lamb's ear backing leaves for backing texture"
    ],
    priceFinished: 330,
    priceBlueprint: 29,
    totalStems: 24,
    size: "20\" grapevine",
    vector: {
      warmth: 0.86,
      energy: 0.28,
      nostalgia: 0.79,
      valence: 0.74,
      intimacy: 0.80,
      restraint: 0.68,
      seasonal: 0.48
    },
    remainingFinished: 0, // resting
    accentColor: "wheat",
    svgPath: "sunday-bread"
  },
  {
    id: "BP-EC-0412",
    name: "First Light",
    territoryId: 2,
    territoryName: "Celebration",
    tagline: "Lifted, bright, arriving.",
    description: "An optimistic design of climbing silver eucalyptus and white morning glory. Light on the vine, reaching upward with high-positioned clusters to represent beginnings and clear horizons.",
    bullets: [
      "18\" grapevine base",
      "Climbing eucalyptus extending up from 7:00 to 11:30",
      "Delicate paper morning glory blossoms reaching upward",
      "Highly energetic, airy, and bright profile"
    ],
    priceFinished: 335,
    priceBlueprint: 38,
    totalStems: 22,
    size: "18\" grapevine",
    vector: {
      warmth: 0.75,
      energy: 0.82,
      nostalgia: 0.42,
      valence: 0.88,
      intimacy: 0.58,
      restraint: 0.44,
      seasonal: 0.35
    },
    remainingFinished: 5,
    accentColor: "gold",
    svgPath: "first-light"
  },
  {
    id: "BP-EC-0415",
    name: "Gathered Grace",
    territoryId: 2,
    territoryName: "Celebration",
    tagline: "A full table, every chair taken.",
    description: "Designed for arrivals, grand entries, and crowded dining rooms. A rich, energetic composition of bright golden dahlias, wild sumac branches, and wild rosehips.",
    bullets: [
      "20\" grapevine base — robust and display-ready",
      "Focal cluster: golden-yellow dahlias at 4:30 and 10:30",
      "Wild rosehip sprigs cascading downward",
      "Rich orange sumac branches providing a celebratory warmth"
    ],
    priceFinished: 395,
    priceBlueprint: 44,
    totalStems: 26,
    size: "20\" grapevine",
    vector: {
      warmth: 0.82,
      energy: 0.89,
      nostalgia: 0.65,
      valence: 0.91,
      intimacy: 0.68,
      restraint: 0.38,
      seasonal: 0.76
    },
    remainingFinished: 1,
    accentColor: "gold",
    svgPath: "gathered-grace"
  },
  {
    id: "BP-EC-0419",
    name: "Legacy Garden",
    territoryId: 3,
    territoryName: "Remembrance",
    tagline: "What she grew, kept growing.",
    description: "Our core Remembrance piece. Extremely restrained, honoring the passing of generations. Made of preserved white rosebuds, grey silver-sage leaf backings, and long structural bare willow branches.",
    bullets: [
      "18\" grapevine base — highly exposed and raw",
      "Focal cluster at 9:00: white rosebuds in slow bloom",
      "Preserved silver-sage backing foliage",
      "Bare weeping-willow twigs sweeping outward to 12:00"
    ],
    priceFinished: 425,
    priceBlueprint: 49,
    totalStems: 17,
    size: "18\" grapevine",
    vector: {
      warmth: 0.78,
      energy: 0.14,
      nostalgia: 0.94,
      valence: 0.35,
      intimacy: 0.90,
      restraint: 0.88,
      seasonal: 0.55
    },
    remainingFinished: 5,
    accentColor: "sage",
    svgPath: "legacy-garden"
  },
  {
    id: "BP-EC-0424",
    name: "White Hour",
    territoryId: 3,
    territoryName: "Remembrance",
    tagline: "Half the vine left bare, on purpose.",
    description: "An incredibly minimal and quiet tribute. Features a single white parchment ranunculus flower resting at 9:00, backed by dusty grey dusty-miller leaves. The remaining grapevine is completely bare, symbolizing open space.",
    bullets: [
      "16\" grapevine base — clean and hallowed",
      "Single focal element at 9:00 — white ranunculus",
      "Dusty-miller leaves and grey lichen details",
      "More than 60% of the natural grapevine left exposed"
    ],
    priceFinished: 375,
    priceBlueprint: 41,
    totalStems: 14,
    size: "16\" grapevine",
    vector: {
      warmth: 0.65,
      energy: 0.10,
      nostalgia: 0.88,
      valence: 0.30,
      intimacy: 0.92,
      restraint: 0.94,
      seasonal: 0.40
    },
    remainingFinished: 4,
    accentColor: "lichen",
    svgPath: "white-hour"
  },
  {
    id: "BP-EC-0427",
    name: "The Long Table",
    territoryId: 5,
    territoryName: "Connection",
    tagline: "Paired clusters, shared weight.",
    description: "A dual-cluster design where two identical weight arrangements balance each other perfectly at 3:00 and 9:00 across the vine. Styled around partnership, hostings, and sharing food across a table.",
    bullets: [
      "18\" grapevine base",
      "Twin clusters at 3:00 and 9:00 — olive leaf and linen twine",
      "Interwoven pale linen cord bindings",
      "Deep green Mediterranean olive leaf base"
    ],
    priceFinished: 355,
    priceBlueprint: 39,
    totalStems: 23,
    size: "18\" grapevine",
    vector: {
      warmth: 0.80,
      energy: 0.32,
      nostalgia: 0.70,
      valence: 0.78,
      intimacy: 0.89,
      restraint: 0.65,
      seasonal: 0.32
    },
    remainingFinished: 2,
    accentColor: "olive",
    svgPath: "long-table"
  },
  {
    id: "BP-EC-0429",
    name: "Green Morning",
    territoryId: 4,
    territoryName: "Renewal",
    tagline: "Upward movement, beginnings.",
    description: "A fresh, lightweight design with bright ivy vines climbing aggressively up the side of the grapevine. Symbolizes recoveries, new days, and refreshing transitions.",
    bullets: [
      "16\" grapevine base",
      "Climbing wild ivy tendrils from 6:00 running up to 11:00",
      "Bright green moss accents lining the inner ring",
      "Airy, spacious material layerings to breathe"
    ],
    priceFinished: 285,
    priceBlueprint: 31,
    totalStems: 16,
    size: "16\" grapevine",
    vector: {
      warmth: 0.72,
      energy: 0.68,
      nostalgia: 0.35,
      valence: 0.82,
      intimacy: 0.62,
      restraint: 0.55,
      seasonal: 0.65
    },
    remainingFinished: 5,
    accentColor: "moss",
    svgPath: "green-morning"
  }
];

export interface BundleCollection {
  id: string;
  name: string;
  tagline: string;
  description: string;
  price: number;
  savings: number;
  designs: WreathDesign[];
  accentGradient: string;
  territoryName: string;
}

export const BUNDLES: BundleCollection[] = [
  {
    id: "bundle-autumn",
    name: "Autumn Memories",
    tagline: "The whole season, front door to mantel to table.",
    description: "Three autumn compositions that share a toffee-and-amber palette and a low, warm center of gravity — sized and weighted differently so they read as one season moving through a house, not the same wreath three times.",
    price: 129,
    savings: 27,
    designs: [
      WREATHS.find(w => w.id === "BP-EC-0417")!,
      WREATHS.find(w => w.id === "BP-EC-0422")!,
      WREATHS.find(w => w.id === "BP-EC-0438")!
    ],
    accentGradient: "from-[#F2EFE9] to-[rgba(196,146,42,0.14)]",
    territoryName: "Seasonal Nostalgia"
  },
  {
    id: "bundle-grace",
    name: "Gathered Grace Collection",
    tagline: "For the house where everyone ends up.",
    description: "Built around the celebration design of the same name, this set pairs lifted, bright focal energy with the paired-cluster intimacy of The Long Table — a collection for arrivals, milestones, and full chairs.",
    price: 119,
    savings: 25,
    designs: [
      WREATHS.find(w => w.id === "BP-EC-0415")!,
      WREATHS.find(w => w.id === "BP-EC-0412")!,
      WREATHS.find(w => w.id === "BP-EC-0427")!
    ],
    accentGradient: "from-[#F9F7F4] to-[rgba(196,146,42,0.09)]",
    territoryName: "Celebration & Connection"
  },
  {
    id: "bundle-legacy",
    name: "Legacy Garden Collection",
    tagline: "What she grew, kept growing.",
    description: "The most restrained set in the library — three compositions with deliberate negative space, built to honor rather than decorate. Often built together by families, one design per household.",
    price: 149,
    savings: 31,
    designs: [
      WREATHS.find(w => w.id === "BP-EC-0419")!,
      WREATHS.find(w => w.id === "BP-EC-0424")!,
      WREATHS.find(w => w.id === "BP-EC-0431")!
    ],
    accentGradient: "from-[#FFFFFF] to-[#F2EFE9]",
    territoryName: "Remembrance"
  }
];

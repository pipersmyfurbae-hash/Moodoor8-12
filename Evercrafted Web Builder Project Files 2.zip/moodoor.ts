import { invokeLLM } from "./_core/llm";

export type EvsVector = {
  warmth: number;
  energy: number;
  nostalgia: number;
  valence: number;
  intimacy: number;
  restraint: number;
  seasonal: number;
};

export type StudioProduct = {
  id: string;
  name: string;
  role: string;
  layer: number;
  formCode: string;
  scale: string;
  formula: string;
  price: string;
  prompt: string;
};

const dimensions = ["warmth", "energy", "nostalgia", "valence", "intimacy", "restraint", "seasonal"] as const;

const productLibrary = [
  ["E1", "Grande Wreath", "Premium Anchor", 1, "26–30in", "Heavy Crescent", "$295–$385"],
  ["E2", "Hero Wreath", "Hero", 1, "22–26in", "Heavy Crescent", "$185–$245"],
  ["D2", "Interior Threshold", "Supporting", 2, "Door", "Header Swag Light", "$125–$175"],
  ["A1", "Mantel Garland", "Atmospheric Filler", 3, "48–60in", "Linear Directional", "$165–$215"],
  ["R1", "Chair Wreath Set", "Accent", 4, "4 × 10in", "Classic Asymmetric", "$125–$165"],
  ["R6", "Candle Ring Set", "Accent", 4, "2 × 8in", "Asymmetric Cluster", "$55–$75"],
] as const;

const fallbackVector: EvsVector = {
  warmth: 0.75,
  energy: 0.30,
  nostalgia: 0.85,
  valence: 0.55,
  intimacy: 0.80,
  restraint: 0.70,
  seasonal: 0.65,
};

const clamp = (value: number) => Math.min(1, Math.max(0, Number.isFinite(value) ? value : 0));

function normalizeVector(value: Record<string, unknown>): EvsVector {
  return dimensions.reduce((result, dimension) => {
    const candidate = typeof value[dimension] === "number" ? value[dimension] : fallbackVector[dimension];
    result[dimension] = clamp(candidate);
    return result;
  }, {} as EvsVector);
}

export function calculateSimilarity(first: EvsVector, second: EvsVector) {
  const distance = Math.sqrt(dimensions.reduce((sum, key) => sum + Math.pow(first[key] - second[key], 2), 0));
  return Math.round((1 - distance / Math.sqrt(dimensions.length)) * 100);
}

export function deriveFallbackVector(memory: string): EvsVector {
  const text = memory.toLowerCase();
  const vector = { ...fallbackVector };
  if (/(rain|spring|garden|morning|new|begin)/.test(text)) { vector.valence = 0.76; vector.energy = 0.46; }
  if (/(grandmother|mother|remember|childhood|old|used to|porch|year)/.test(text)) vector.nostalgia = 0.92;
  if (/(winter|autumn|fall|september|october|december|snow|cedar)/.test(text)) vector.seasonal = 0.9;
  if (/(party|music|crowd|dance|celebrat)/.test(text)) { vector.energy = 0.83; vector.valence = 0.88; vector.restraint = 0.28; }
  if (/(quiet|still|alone|mist|soft|hushed)/.test(text)) { vector.energy = 0.22; vector.restraint = 0.82; vector.intimacy = 0.86; }
  if (/(loss|grief|miss|funeral|gone)/.test(text)) { vector.valence = 0.28; vector.restraint = 0.88; vector.intimacy = 0.9; }
  return vector;
}

export async function interpretMemory(memory: string): Promise<{ vector: EvsVector; explanation: string; isFallback: boolean }> {
  try {
    const response = await invokeLLM({
      model: "gpt-5-mini",
      messages: [
        { role: "system", content: "You are Moodoor’s Emotional Vector System. Return only valid JSON that matches the supplied schema. Be gentle, precise, and never diagnostic." },
        { role: "user", content: `Read this personal memory and score warmth, energy, nostalgia, valence, intimacy, restraint, and seasonal from 0 to 1. Give a respectful two-sentence explanation that names the sensory atmosphere, not the person’s identity.\n\nMemory: ${memory}` },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "moodoor_memory_profile",
          strict: true,
          schema: {
            type: "object",
            properties: {
              vector: {
                type: "object",
                properties: Object.fromEntries(dimensions.map((key) => [key, { type: "number" }])),
                required: [...dimensions],
                additionalProperties: false,
              },
              explanation: { type: "string" },
            },
            required: ["vector", "explanation"],
            additionalProperties: false,
          },
        },
      },
    });
    const parsed = JSON.parse(String(response.choices[0]?.message?.content ?? "")) as { vector: Record<string, unknown>; explanation: string };
    return { vector: normalizeVector(parsed.vector), explanation: parsed.explanation, isFallback: false };
  } catch {
    return {
      vector: deriveFallbackVector(memory),
      explanation: "Your memory carries a quiet, held warmth: its sensory details gather into a measured rhythm rather than a loud declaration. Moodoor reads that atmosphere as a composition with room for the vine, the season, and the pause between them.",
      isFallback: true,
    };
  }
}

export function buildStudioProducts(name: string, palette: string[]): StudioProduct[] {
  return productLibrary.map(([formCode, productName, role, layer, scale, formula, price]) => ({
    id: `${formCode.toLowerCase()}-${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`,
    name: productName,
    role,
    layer,
    formCode,
    scale,
    formula,
    price,
    prompt: `Luxury handcrafted faux botanical ${productName.toLowerCase()} for the ${name} collection; palette of ${palette.join(", ") || "soft botanical neutrals"}; purposeful asymmetry, visible negative space, layered natural materials, editorial product photography, pale warm plaster, soft directional daylight.`,
  }));
}

export function buildStudioPayload(input: { name: string; season: string; atmosphere: string; intent: string; palette: string[]; sourceImageUrl?: string; visualNotes?: string[]; renderPrompt?: string }) {
  return {
    collectionName: input.name,
    season: input.season,
    atmosphere: input.atmosphere,
    intent: input.intent,
    palette: input.palette,
    entryMethod: input.sourceImageUrl ? "wreath-render-analysis" : "intent-brief",
    sourceImageUrl: input.sourceImageUrl ?? null,
    visualNotes: input.visualNotes ?? [],
    renderPrompt: input.renderPrompt ?? null,
    sightlineStory: `A ${input.atmosphere.toLowerCase()} visual progression from entry to discovery, held together by ${input.palette[0] || "a quiet botanical palette"}.`,
    productLibraryVersion: "uploaded-collection-studio-v1",
    products: buildStudioProducts(input.name, input.palette),
  };
}

export async function analyzeWreathRender(input: { imageUrl: string; fileName: string; storedUrl: string }) {
  const response = await invokeLLM({
    model: "gpt-5-mini",
    messages: [
      { role: "system", content: "You are Moodoor’s internal visual director. Analyze only visible floral composition details in the provided wreath-render image. Do not identify people, infer private attributes, or claim materials you cannot see. Return only JSON matching the requested schema." },
      { role: "user", content: [
        { type: "text", text: "Turn this wreath render into an editable internal collection brief. Suggest a concise collection name, season, atmosphere, palette, intent, visual notes, and an editorial render prompt. The brief should be high-end, concrete, and oriented around asymmetry, negative space, material hierarchy, and sightline." },
        { type: "image_url", image_url: { url: input.imageUrl, detail: "auto" } },
      ] as any },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "moodoor_render_brief",
        strict: true,
        schema: {
          type: "object",
          properties: {
            name: { type: "string" },
            season: { type: "string" },
            atmosphere: { type: "string" },
            intent: { type: "string" },
            palette: { type: "array", items: { type: "string" } },
            visualNotes: { type: "array", items: { type: "string" } },
            renderPrompt: { type: "string" },
          },
          required: ["name", "season", "atmosphere", "intent", "palette", "visualNotes", "renderPrompt"],
          additionalProperties: false,
        },
      },
    },
  });
  const draft = JSON.parse(String(response.choices[0]?.message?.content ?? "")) as { name: string; season: string; atmosphere: string; intent: string; palette: string[]; visualNotes: string[]; renderPrompt: string };
  return { ...draft, sourceImageUrl: input.storedUrl, sourceFileName: input.fileName };
}

export async function critiqueComposition(input: { territory: string; notes: string; placements: Array<{ elementName?: string; elementType?: string; clockPosition?: string }> }) {
  const hasPlacements = input.placements.length > 0;
  const references = input.placements.slice(0, 3).map((placement) => `${placement.elementName || placement.elementType || "element"} at ${placement.clockPosition || "an unspecified position"}`).join(", ");
  return {
    score: hasPlacements ? 78 : 60,
    artisticCritique: hasPlacements
      ? `Your ${input.territory} composition has a promising asymmetrical rhythm around ${references}. Keep the strongest botanical weight concentrated, then allow the exposed grapevine to finish the sentence.`
      : "Your frame is still open, which is a useful beginning. Start with one deliberate focal grouping and let the rest of the vine remain available for breathing room.",
    evsAnalysis: "The strongest Moodoor translation comes from balancing intimacy and restraint: one clear focal movement, with counterweight rather than mirrored mass.",
    errors: hasPlacements ? [{ title: "Symmetry alignment risk", location: "Focal placement lines", description: "Check whether repeated elements mirror across the frame rather than progressing in one directional gesture." }] : [{ title: "Empty grapevine canvas", location: "Entire grid", description: "Place a focal element or greenery sweep before judging the composition’s weight." }],
    suggestions: ["Keep at least 40% of the grapevine exposed.", "Gather focal stems into one primary cluster before adding texture.", "Let greenery travel in one organic direction rather than pointing inward."],
  };
}

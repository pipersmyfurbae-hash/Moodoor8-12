import React, { createContext, useContext, useEffect, useState } from "react";
import { 
  User, 
  signInWithPopup, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  updateProfile
} from "firebase/auth";
import { auth, googleProvider } from "../lib/firebase";

export interface CustomUser {
  uid: string;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
  isGuest: boolean;
}

interface AuthContextType {
  user: CustomUser | null;
  loading: boolean;
  error: string | null;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string, isSignUp: boolean, name?: string) => Promise<void>;
  signInAsGuest: (name: string) => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<CustomUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Check if there is a saved guest session in local storage first
    const savedGuest = localStorage.getItem("moodoor_guest_user");
    if (savedGuest) {
      try {
        setUser(JSON.parse(savedGuest));
        setLoading(false);
      } catch {
        localStorage.removeItem("moodoor_guest_user");
      }
    }

    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        // Clear guest session if a real user logs in
        localStorage.removeItem("moodoor_guest_user");
        setUser({
          uid: firebaseUser.uid,
          displayName: firebaseUser.displayName,
          email: firebaseUser.email,
          photoURL: firebaseUser.photoURL,
          isGuest: false
        });
      } else {
        // Only clear user if they are not in Guest mode
        const currentGuest = localStorage.getItem("moodoor_guest_user");
        if (!currentGuest) {
          setUser(null);
        }
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const signInWithGoogle = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      console.error("Google Authentication error:", err);
      // Fallback helpful message about iframe restrictions if blocked
      if (err.code === "auth/popup-blocked" || err.code === "auth/network-request-failed") {
        setError("Sign-in window was blocked. This often happens inside application previews. Please try 'Guest Mode' or try again in a new browser tab.");
      } else {
        setError(err.message || "Could not authenticate with Google.");
      }
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signInWithEmail = async (email: string, pass: string, isSignUp: boolean, name?: string) => {
    setError(null);
    setLoading(true);
    try {
      if (isSignUp) {
        const credential = await createUserWithEmailAndPassword(auth, email, pass);
        if (name && credential.user) {
          await updateProfile(credential.user, { displayName: name });
          setUser({
            uid: credential.user.uid,
            displayName: name,
            email: credential.user.email,
            photoURL: null,
            isGuest: false
          });
        }
      } else {
        await signInWithEmailAndPassword(auth, email, pass);
      }
      localStorage.removeItem("moodoor_guest_user");
    } catch (err: any) {
      console.error("Email auth error:", err);
      setError(err.message || "Failed email authentication.");
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signInAsGuest = (name: string) => {
    const guestData: CustomUser = {
      uid: `guest_${Math.random().toString(36).substring(2, 9)}`,
      displayName: name || "Artisan Guest",
      email: "guest@moodoor.local",
      photoURL: null,
      isGuest: true
    };
    localStorage.setItem("moodoor_guest_user", JSON.stringify(guestData));
    setUser(guestData);
  };

  const logout = async () => {
    setLoading(true);
    try {
      localStorage.removeItem("moodoor_guest_user");
      await signOut(auth);
      setUser(null);
    } catch (err: any) {
      console.error("Logout error:", err);
      setError(err.message || "Error signing out.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      error,
      signInWithGoogle,
      signInWithEmail,
      signInAsGuest,
      logout
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Zap, Palette, BarChart3, ShoppingBag, Layers } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("monthly");
  const [memoryInput, setMemoryInput] = useState("");
  const [showBlueprint, setShowBlueprint] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const handleGenerateBlueprint = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setShowBlueprint(true);
    }, 2500);
  };

  const pricing = {
    monthly: [
      { name: "Bloom", price: 0, description: "Explore the system", features: ["1 project", "Basic inventory", "3 designs/month"] },
      { name: "Craft", price: 29, description: "For independent makers", features: ["Unlimited projects", "Full inventory", "Unlimited designs", "Etsy integration"], highlighted: true },
      { name: "Studio", price: 79, description: "For design teams", features: ["Team collaboration", "Advanced analytics", "Marketplace selling", "Priority support"] },
      { name: "Atelier", price: 199, description: "Enterprise", features: ["Custom integrations", "Dedicated support", "API access", "White-label options"] },
    ],
    annual: [
      { name: "Bloom", price: 0, description: "Explore the system", features: ["1 project", "Basic inventory", "3 designs/month"] },
      { name: "Craft", price: 290, description: "For independent makers", features: ["Unlimited projects", "Full inventory", "Unlimited designs", "Etsy integration"], highlighted: true },
      { name: "Studio", price: 790, description: "For design teams", features: ["Team collaboration", "Advanced analytics", "Marketplace selling", "Priority support"] },
      { name: "Atelier", price: 1990, description: "Enterprise", features: ["Custom integrations", "Dedicated support", "API access", "White-label options"] },
    ],
  };

  const faqItems = [
    {
      q: "How does Evercrafted integrate with my Etsy shop?",
      a: "Evercrafted connects directly to your Etsy account via OAuth. Once connected, you can generate designs, auto-create listings with descriptions and photos, and track orders—all from within Evercrafted. No manual copying and pasting."
    },
    {
      q: "Can I use my existing inventory in Evercrafted?",
      a: "Yes. Upload your inventory (stems, colors, quantities) into Evercrafted once. The system learns your stock and generates designs using only what you have. If a design calls for a stem you don't have, Evercrafted suggests smart substitutions based on bloom size, gesture, and color."
    },
    {
      q: "How fast can I generate a custom design from a customer request?",
      a: "Typically 2–5 minutes. A customer says 'I want something that feels like autumn nostalgia'—you input that into Evercrafted, it generates a blueprint with exact placements, a build guide, and a render prompt. You can show the render to the customer for approval before building."
    },
    {
      q: "Can I sell designs on the Evercrafted Marketplace?",
      a: "Yes. You can publish designs as locked blueprints (fully specified, buyers build exactly as designed) or shell blueprints (geometry locked, florals flexible). You earn 70% of every sale. Evercrafted handles hosting, payment, and distribution."
    },
    {
      q: "What if I don't have all the stems a blueprint calls for?",
      a: "Evercrafted's Genome Substitution Engine automatically suggests compatible alternatives. It scores substitutions based on bloom size, gesture type, texture, color family, and emotional tags. You can accept suggestions or manually swap stems."
    },
    {
      q: "How do I price custom orders if I'm using Evercrafted?",
      a: "Evercrafted generates a cost breakdown for every design: stem costs, labor time, and suggested retail price based on market rates. You can adjust pricing based on complexity, rush fees, or premium positioning. Many sellers charge 3–5x material cost for custom work."
    },
    {
      q: "Can I create a 'signature style' and reuse it for multiple customers?",
      a: "Absolutely. Once you create a design you love, save it as a template. You can adjust the palette or formula for different customers while keeping the core composition. This speeds up custom work and maintains brand consistency."
    },
    {
      q: "Does Evercrafted work with seasonal designs?",
      a: "Yes. The system includes seasonal formula presets (autumn, winter, spring, summer). You can also create custom seasonal palettes and save them as templates. Many sellers use Evercrafted to batch-create seasonal collections."
    },
    {
      q: "Can I track which designs sell best on Etsy?",
      a: "Yes. The Studio tier includes analytics: which designs get the most views, which convert to sales, average order value, and margin tracking. Use this data to refine your designs and pricing."
    },
    {
      q: "What if I want to keep some designs private and not sell them on the marketplace?",
      a: "All designs are private by default. You choose which ones to publish to the marketplace. Private designs stay in your project library for personal use or custom client work."
    }
  ];

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-stone-50/95 backdrop-blur-sm border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-8 py-4 flex items-center justify-between">
          <div className="text-2xl font-serif font-light tracking-wide">Evercrafted</div>
          <div className="hidden md:flex gap-12 items-center text-sm">
            <a href="#system" className="text-stone-600 hover:text-stone-900 transition">The System</a>
            <a href="#audiences" className="text-stone-600 hover:text-stone-900 transition">For You</a>
            <a href="#marketplace" className="text-stone-600 hover:text-stone-900 transition">Marketplace</a>
            <a href="#pricing" className="text-stone-600 hover:text-stone-900 transition">Pricing</a>
            <a href="#faq" className="text-stone-600 hover:text-stone-900 transition">FAQ</a>
          </div>
          <div className="flex gap-4 items-center">
            <button className="text-sm text-stone-600 hover:text-stone-900">Sign In</button>
            <Button className="bg-stone-900 text-white hover:bg-stone-800 text-sm">Start Free</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-24 px-8 overflow-hidden">
        <div className="absolute inset-0 opacity-3" style={{
          backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663455730283/KsxNWqjCCFQjR5SuiM4j6N/bret_64130_Luxury_faux_floral_wreath_in_Serene_Garden_Blues_pal_7914d575-f33b-47d7-87f6-624424a006da_f5392d92.png)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }} />
        <div className="relative max-w-5xl mx-auto text-center">
          <p className="text-xs uppercase tracking-widest text-stone-500 mb-6">The Procedural Floral Design Engine</p>
          <h1 className="text-7xl md:text-8xl font-serif font-light leading-tight mb-8 text-stone-900">
            Design Intelligence for Wreath Makers
          </h1>
          <p className="text-xl text-stone-600 font-light mb-12 max-w-3xl mx-auto leading-relaxed">
            Evercrafted translates emotion, memory, and inventory into mathematically perfect wreath designs. Sell faster. Create smarter. Scale without limits.
          </p>
          <div className="flex gap-4 justify-center">
            <Button className="bg-stone-900 text-white hover:bg-stone-800 px-8 py-3">
              Start Free Trial <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
            <Button variant="outline" className="px-8 py-3 border-stone-300">
              Watch Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Interactive Memory to Blueprint Demo */}
      <section className="py-24 px-8 bg-stone-100">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-serif font-light mb-4 text-center">See It in Action</h2>
          <p className="text-lg text-stone-600 font-light text-center mb-12">Type a memory or feeling. Watch Evercrafted generate a blueprint in seconds.</p>
          
          <div className="bg-white rounded-lg p-12 border border-stone-200">
            <div className="mb-8">
              <label className="block text-sm font-light text-stone-600 mb-3">Describe a memory or feeling:</label>
              <input
                type="text"
                value={memoryInput}
                onChange={(e) => setMemoryInput(e.target.value)}
                placeholder="e.g., 'Nostalgic autumn afternoon', 'Elegant wedding elegance', 'Cozy winter gathering'"
                className="w-full px-4 py-3 border border-stone-300 rounded-lg font-light focus:outline-none focus:border-stone-900 transition"
              />
            </div>
            
            <button
              onClick={handleGenerateBlueprint}
              disabled={!memoryInput || isLoading}
              className="w-full bg-stone-900 text-white py-3 rounded-lg font-light hover:bg-stone-800 transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Analyzing Memory...' : 'Generate Blueprint'}
            </button>

            {isLoading && (
              <div className="mt-8 pt-8 border-t border-stone-200">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <p className="text-xs uppercase tracking-widest text-stone-500">Interpreting Memory</p>
                      <div className="flex gap-1">
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-pulse" />
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                      </div>
                    </div>
                    <div className="h-1 bg-stone-200 rounded-full overflow-hidden">
                      <div className="h-full bg-stone-900 rounded-full" style={{
                        width: '33%',
                        animation: 'pulse 1s ease-in-out infinite'
                      }} />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <p className="text-xs uppercase tracking-widest text-stone-500">Analyzing Inventory</p>
                      <div className="flex gap-1">
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-pulse" />
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                      </div>
                    </div>
                    <div className="h-1 bg-stone-200 rounded-full overflow-hidden">
                      <div className="h-full bg-stone-900 rounded-full" style={{
                        width: '66%',
                        animation: 'pulse 1s ease-in-out infinite'
                      }} />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <p className="text-xs uppercase tracking-widest text-stone-500">Generating Blueprint</p>
                      <div className="flex gap-1">
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-pulse" />
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                      </div>
                    </div>
                    <div className="h-1 bg-stone-200 rounded-full overflow-hidden">
                      <div className="h-full bg-stone-900 rounded-full" style={{
                        width: '100%',
                        animation: 'pulse 1s ease-in-out infinite'
                      }} />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {showBlueprint && memoryInput && (
              <div className="mt-12 pt-12 border-t border-stone-200">
                <h3 className="text-2xl font-serif font-light mb-6">Generated Blueprint</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
                  <div className="bg-stone-50 p-6 rounded-lg">
                    <p className="text-xs uppercase tracking-widest text-stone-500 mb-2">Memory</p>
                    <p className="font-serif text-lg">{memoryInput}</p>
                  </div>
                  <div className="bg-stone-50 p-6 rounded-lg">
                    <p className="text-xs uppercase tracking-widest text-stone-500 mb-2">Formula</p>
                    <p className="font-serif text-lg">Crescent Sweep</p>
                  </div>
                  <div className="bg-stone-50 p-6 rounded-lg">
                    <p className="text-xs uppercase tracking-widest text-stone-500 mb-2">Stem Count</p>
                    <p className="font-serif text-lg">58 stems</p>
                  </div>
                  <div className="bg-stone-50 p-6 rounded-lg">
                    <p className="text-xs uppercase tracking-widest text-stone-500 mb-2">Quality Score</p>
                    <p className="font-serif text-lg">0.87</p>
                  </div>
                </div>
                <div className="bg-stone-50 p-8 rounded-lg">
                  <p className="text-xs uppercase tracking-widest text-stone-500 mb-4">Palette & Composition</p>
                  <div className="space-y-3 text-sm font-light text-stone-700">
                    <p><strong>Colors:</strong> Deep burgundy, sage green, champagne gold</p>
                    <p><strong>Density:</strong> Moderate with focal cluster at 220°</p>
                    <p><strong>Silence Arc:</strong> 280° – 330° (breathing room)</p>
                    <p><strong>Build Sequence:</strong> Greenery skeleton → focal blooms → secondary → accents → filler</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Getting Started Tutorial */}
      <section className="py-32 px-8 bg-stone-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-light mb-4 text-center">Getting Started in 5 Steps</h2>
          <p className="text-lg text-stone-600 font-light text-center mb-20 max-w-2xl mx-auto">
            From inventory to finished design in minutes. Here's how Evercrafted works.
          </p>

          <div className="space-y-12">
            {[
              {
                step: 1,
                title: "Upload Your Inventory",
                desc: "Add your stems, colors, quantities, and bloom sizes. Evercrafted learns your stock and constraints.",
                details: ["CSV import or manual entry", "Automatic SKU recognition", "Bloom dimension analysis", "Role assignment (focal, secondary, filler)"]
              },
              {
                step: 2,
                title: "Describe a Memory or Feeling",
                desc: "Input a customer's memory, emotion, or room aesthetic. 'Nostalgic autumn' or 'Modern minimalist wedding.'",
                details: ["Natural language processing", "Emotional intent recognition", "Symbolic tag generation", "Palette bias calculation"]
              },
              {
                step: 3,
                title: "Select a Formula",
                desc: "Choose from 12 professional wreath compositions (crescent, radial, cascade, etc.). Evercrafted recommends based on your input.",
                details: ["Formula library with previews", "Emotion-matched recommendations", "Inventory feasibility check", "Silhouette preview"]
              },
              {
                step: 4,
                title: "Review the Blueprint",
                desc: "See exact stem placements, angles, depths, and build sequence. Adjust if needed. Quality score shows design excellence.",
                details: ["Polar coordinate visualization", "Stem-by-stem placement guide", "Build sequence (greenery → focal → secondary → accents → filler)", "Quality scoring (balance, rhythm, contrast, focal clarity)"]
              },
              {
                step: 5,
                title: "Generate Render & Build",
                desc: "Get a photorealistic render prompt for Midjourney. Show the render to your customer. Build with confidence.",
                details: ["AI-generated render prompt", "Product photography preview", "Customer approval workflow", "Build guide with timing estimates"]
              }
            ].map((item, idx) => (
              <div key={idx} className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className={idx % 2 === 1 ? "md:order-2" : ""}>
                  <div className="flex items-start gap-6">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-16 w-16 rounded-lg bg-stone-900 text-white">
                        <span className="text-2xl font-serif font-light">{item.step}</span>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-2xl font-serif font-light mb-3">{item.title}</h3>
                      <p className="text-stone-600 font-light mb-6">{item.desc}</p>
                      <ul className="space-y-2">
                        {item.details.map((detail, didx) => (
                          <li key={didx} className="text-sm text-stone-600 font-light flex items-start gap-2">
                            <span className="text-stone-400 mt-1">•</span>
                            <span>{detail}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
                <div className={idx % 2 === 1 ? "md:order-1" : ""}>
                  <div className="bg-white p-8 rounded-lg border border-stone-200 h-64 flex items-center justify-center">
                    <p className="text-center text-stone-400 font-light">Step {item.step} Visualization</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Blueprint Gallery */}
      <section className="py-32 px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-light mb-4 text-center">Blueprint Gallery</h2>
          <p className="text-lg text-stone-600 font-light text-center mb-20 max-w-2xl mx-auto">
            Designs created with Evercrafted. Available on the marketplace for you to build, customize, or resell.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Grounded Joy",
                emotion: "Warmth & Abundance",
                formula: "Radial Burst",
                stems: 62,
                image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663455730283/KsxNWqjCCFQjR5SuiM4j6N/1GroundedJoy_743738d6.png"
              },
              {
                name: "Quiet Return",
                emotion: "Serenity & Reflection",
                formula: "Crescent Sweep",
                stems: 58,
                image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663455730283/KsxNWqjCCFQjR5SuiM4j6N/2QuietReturn_e1623d07.png"
              },
              {
                name: "Held Between Seasons",
                emotion: "Transition & Hope",
                formula: "Asymmetric Balance",
                stems: 71,
                image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663455730283/KsxNWqjCCFQjR5SuiM4j6N/9HeldBetweenSeasons_e1623d07.png"
              },
              {
                name: "Becoming Again",
                emotion: "Renewal & Growth",
                formula: "Spiral Ascent",
                stems: 65,
                image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663455730283/KsxNWqjCCFQjR5SuiM4j6N/5BecomingAgain.webp"
              },
              {
                name: "After the Rain",
                emotion: "Clarity & Freshness",
                formula: "Crescent Sweep",
                stems: 60,
                image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663455730283/KsxNWqjCCFQjR5SuiM4j6N/4AfterTheRain.webp"
              },
              {
                name: "Serene Garden Blues",
                emotion: "Calm & Elegance",
                formula: "Radial Balanced",
                stems: 68,
                image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663455730283/KsxNWqjCCFQjR5SuiM4j6N/bret_64130_Luxury_faux_floral_wreath_in_Serene_Garden_Blues_pal_7914d575-f33b-47d7-87f6-624424a006da_f5392d92.png"
              }
            ].map((design, idx) => (
              <div key={idx} className="group">
                <div className="relative h-80 rounded-lg overflow-hidden mb-6 bg-stone-100">
                  <img
                    src={design.image}
                    alt={design.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition duration-300" />
                </div>
                <h3 className="text-xl font-serif font-light mb-2">{design.name}</h3>
                <div className="space-y-2 mb-6">
                  <p className="text-sm text-stone-600 font-light">
                    <span className="text-xs uppercase tracking-widest text-stone-500">Emotion</span><br />
                    {design.emotion}
                  </p>
                  <p className="text-sm text-stone-600 font-light">
                    <span className="text-xs uppercase tracking-widest text-stone-500">Formula</span><br />
                    {design.formula} • {design.stems} stems
                  </p>
                </div>
                <button className="w-full bg-stone-900 text-white py-2 rounded-lg font-light hover:bg-stone-800 transition text-sm">
                  View on Marketplace
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* The Complete System */}
      <section id="system" className="py-32 px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-light mb-4">The 14-Engine System</h2>
          <p className="text-lg text-stone-600 font-light mb-20 max-w-2xl">
            Evercrafted is not a template generator. It's a complete design intelligence platform that understands emotion, inventory, composition, and mathematics.
          </p>

          {/* Engine Categories */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-20">
            {/* Tier 1: Input */}
            <div className="border-l-4 border-stone-900 pl-8">
              <h3 className="text-2xl font-serif font-light mb-6">Input & Interpretation</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-serif text-lg mb-2">Memory Interpreter</h4>
                  <p className="text-stone-600 font-light text-sm">Translates emotional prompts and memories into design signals. "Nostalgic autumn" becomes palette bias, energy level, and symbolic tags.</p>
                </div>
                <div>
                  <h4 className="font-serif text-lg mb-2">Emotion Mapper</h4>
                  <p className="text-stone-600 font-light text-sm">Converts emotional intent into precise design parameters: color palette, contrast, density, and composition style.</p>
                </div>
                <div>
                  <h4 className="font-serif text-lg mb-2">Inventory Analyzer</h4>
                  <p className="text-stone-600 font-light text-sm">Scans your actual inventory. Calculates available stems, bloom sizes, flexibility, and role compatibility for every SKU.</p>
                </div>
              </div>
            </div>

            {/* Tier 2: Composition */}
            <div className="border-l-4 border-stone-900 pl-8">
              <h3 className="text-2xl font-serif font-light mb-6">Composition & Placement</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-serif text-lg mb-2">Formula Selector</h4>
                  <p className="text-stone-600 font-light text-sm">Chooses from 12 professional wreath formulas (crescent, radial, cascade, etc.) based on emotion, inventory, and silhouette.</p>
                </div>
                <div>
                  <h4 className="font-serif text-lg mb-2">Anchor Generator</h4>
                  <p className="text-stone-600 font-light text-sm">Converts formula templates into exact spatial coordinates using deterministic seeding for reproducibility.</p>
                </div>
                <div>
                  <h4 className="font-serif text-lg mb-2">Placement Solver</h4>
                  <p className="text-stone-600 font-light text-sm">Places each stem in polar coordinates with collision detection, directional flow, and depth layering.</p>
                </div>
                <div>
                  <h4 className="font-serif text-lg mb-2">Flow Vector Engine</h4>
                  <p className="text-stone-600 font-light text-sm">Ensures natural botanical movement and gesture through directional vectors derived from arc tangents.</p>
                </div>
              </div>
            </div>

            {/* Tier 3: Refinement & Output */}
            <div className="border-l-4 border-stone-900 pl-8">
              <h3 className="text-2xl font-serif font-light mb-6">Refinement & Output</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-serif text-lg mb-2">Repair Engine</h4>
                  <p className="text-stone-600 font-light text-sm">Iteratively improves designs through density normalization, cluster cohesion, and focal clarity until they pass professional thresholds.</p>
                </div>
                <div>
                  <h4 className="font-serif text-lg mb-2">Scoring Engine</h4>
                  <p className="text-stone-600 font-light text-sm">Evaluates balance, rhythm, contrast, focal clarity, and negative space. Every design receives a quality score.</p>
                </div>
                <div>
                  <h4 className="font-serif text-lg mb-2">Blueprint Generator</h4>
                  <p className="text-stone-600 font-light text-sm">Outputs a complete blueprint: stem placements, cut list, build sequence, and design DNA fingerprint.</p>
                </div>
                <div>
                  <h4 className="font-serif text-lg mb-2">Prompt Compiler</h4>
                  <p className="text-stone-600 font-light text-sm">Converts blueprints into photorealistic Midjourney render prompts for product photography.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Engines */}
          <div className="bg-stone-100 p-12 rounded-lg">
            <h3 className="text-2xl font-serif font-light mb-8">Supporting Systems</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[
                { name: "Floral Genome Engine", desc: "Behavioral traits for every botanical element" },
                { name: "Formula Registry", desc: "12 professional composition templates" },
                { name: "Collision Detection", desc: "Prevents overlapping blooms" },
                { name: "Genome Substitution", desc: "Smart inventory swaps when stems unavailable" },
                { name: "Zone Field Builder", desc: "Divides wreath into density sectors" },
                { name: "Stem Allocator", desc: "Distributes roles (focal, secondary, filler)" },
                { name: "Depth Layering", desc: "Natural visual hierarchy" },
                { name: "Deterministic Seeding", desc: "Reproducible designs every time" }
              ].map((engine, idx) => (
                <div key={idx} className="bg-white p-6 rounded-lg">
                  <h4 className="font-serif text-base mb-2">{engine.name}</h4>
                  <p className="text-stone-600 font-light text-xs">{engine.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* For Different Audiences */}
      <section id="audiences" className="py-32 px-8 bg-stone-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-light mb-20">Built for Every Maker</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {/* Etsy Sellers */}
            <div className="relative">
              <div className="relative h-64 rounded-lg overflow-hidden mb-8">
                <img 
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663455730283/KsxNWqjCCFQjR5SuiM4j6N/9HeldBetweenSeasons_e1623d07.png"
                  alt="Held Between Seasons"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-3xl font-serif font-light mb-4">Etsy Sellers</h3>
              <p className="text-stone-600 font-light mb-6">
                60% of wreath makers sell on Etsy. Evercrafted integrates directly with your shop: generate listings, publish designs, track orders, and scale custom requests from "I want something that feels like autumn" to finished design in minutes.
              </p>
              <ul className="space-y-3 text-sm text-stone-600 font-light">
                <li>✓ Direct Etsy integration & listing generation</li>
                <li>✓ Custom order workflow automation</li>
                <li>✓ 3x faster design time</li>
                <li>✓ Inventory-based design constraints</li>
              </ul>
            </div>

            {/* Design Studios */}
            <div className="relative">
              <div className="relative h-64 rounded-lg overflow-hidden mb-8">
                <img 
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663455730283/KsxNWqjCCFQjR5SuiM4j6N/1GroundedJoy_743738d6.png"
                  alt="Grounded Joy"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-3xl font-serif font-light mb-4">Design Studios</h3>
              <p className="text-stone-600 font-light mb-6">
                For teams managing multiple makers and projects. Collaborate on designs, maintain brand consistency, sell blueprints on the marketplace, and scale production without losing quality.
              </p>
              <ul className="space-y-3 text-sm text-stone-600 font-light">
                <li>✓ Team collaboration & project management</li>
                <li>✓ Brand formula library</li>
                <li>✓ Marketplace revenue sharing</li>
                <li>✓ Advanced analytics & reporting</li>
              </ul>
            </div>

            {/* Wedding & Event Florists */}
            <div className="relative">
              <div className="relative h-64 rounded-lg overflow-hidden mb-8">
                <img 
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663455730283/KsxNWqjCCFQjR5SuiM4j6N/bret_64130_Flat-lay_or_straight-on_realistic_commercial_catalog_8375a741-d69e-4851-905c-a7329f7c08eb.webp"
                  alt="Flat-lay catalog"
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-3xl font-serif font-light mb-4">Wedding & Event Florists</h3>
              <p className="text-stone-600 font-light mb-6">
                Turn client briefs into designs instantly. "Something that feels like their love story" becomes a blueprint in seconds. Sell premium custom designs with confidence.
              </p>
              <ul className="space-y-3 text-sm text-stone-600 font-light">
                <li>✓ Memory-driven design generation</li>
                <li>✓ Client presentation tools</li>
                <li>✓ Premium pricing for custom work</li>
                <li>✓ Reproducible designs for consistency</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Marketplace */}
      <section id="marketplace" className="py-32 px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-light mb-4">The Evercrafted Marketplace</h2>
          <p className="text-lg text-stone-600 font-light mb-16 max-w-2xl">
            Your designs are intellectual property. Sell them. Earn 70% royalties on every download. Build passive income while you sleep.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-serif font-light mb-6">Two Ways to Sell</h3>
              
              <div className="mb-12">
                <h4 className="font-serif text-xl mb-3">Locked Blueprints</h4>
                <p className="text-stone-600 font-light mb-4">Fully specified designs. Buyers build exactly as designed. Perfect for signature styles.</p>
                <ul className="space-y-2 text-sm text-stone-600 font-light">
                  <li>• Complete stem specifications</li>
                  <li>• Exact placements & angles</li>
                  <li>• Build instructions included</li>
                  <li>• Render prompt provided</li>
                </ul>
              </div>

              <div>
                <h4 className="font-serif text-xl mb-3">Shell Blueprints</h4>
                <p className="text-stone-600 font-light mb-4">Geometry locked, florals swappable. Buyers personalize with their own inventory.</p>
                <ul className="space-y-2 text-sm text-stone-600 font-light">
                  <li>• Composition structure locked</li>
                  <li>• Floral roles flexible</li>
                  <li>• Buyers use their inventory</li>
                  <li>• Higher perceived value</li>
                </ul>
              </div>
            </div>

            <div className="bg-stone-100 p-12 rounded-lg">
              <h3 className="font-serif text-2xl mb-8">Royalty Model</h3>
              <div className="space-y-6">
                <div>
                  <p className="text-stone-600 font-light text-sm mb-2">You Earn</p>
                  <p className="text-4xl font-serif font-light text-stone-900">70%</p>
                  <p className="text-stone-600 font-light text-sm">Per sale</p>
                </div>
                <div className="border-t border-stone-300 pt-6">
                  <p className="text-stone-600 font-light text-sm mb-4">Evercrafted handles:</p>
                  <ul className="space-y-2 text-sm text-stone-600 font-light">
                    <li>✓ Hosting & distribution</li>
                    <li>✓ Payment processing</li>
                    <li>✓ Marketing & discovery</li>
                    <li>✓ Customer support</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Monetization Section */}
      <section className="py-32 px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-light mb-4">Turn Your Designs Into Revenue</h2>
          <p className="text-lg text-stone-600 font-light mb-20 max-w-2xl">
            Evercrafted isn't just a design tool—it's a complete monetization platform. Sell blueprints. Earn from apps. Scale your income.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20">
            {/* Marketplace Revenue */}
            <div className="border-l-4 border-stone-900 pl-8">
              <h3 className="text-3xl font-serif font-light mb-6">Marketplace Revenue</h3>
              <p className="text-stone-600 font-light mb-8">
                Every design you create is a potential product. Publish locked or shell blueprints and earn 70% on every sale.
              </p>
              <div className="space-y-6">
                <div className="bg-stone-50 p-6 rounded-lg">
                  <p className="text-xs uppercase tracking-widest text-stone-500 mb-3">Example: Locked Blueprint</p>
                  <div className="space-y-2 text-sm font-light text-stone-700">
                    <div className="flex justify-between">
                      <span>Selling Price</span>
                      <span className="font-serif">$25</span>
                    </div>
                    <div className="flex justify-between text-stone-500">
                      <span>Your Earnings (70%)</span>
                      <span className="font-serif">$17.50</span>
                    </div>
                    <div className="flex justify-between border-t border-stone-200 pt-2 mt-2">
                      <span>Per Month (10 sales)</span>
                      <span className="font-serif font-medium">$175</span>
                    </div>
                  </div>
                </div>
                <div className="bg-stone-50 p-6 rounded-lg">
                  <p className="text-xs uppercase tracking-widest text-stone-500 mb-3">Example: Shell Blueprint</p>
                  <div className="space-y-2 text-sm font-light text-stone-700">
                    <div className="flex justify-between">
                      <span>Selling Price</span>
                      <span className="font-serif">$35</span>
                    </div>
                    <div className="flex justify-between text-stone-500">
                      <span>Your Earnings (70%)</span>
                      <span className="font-serif">$24.50</span>
                    </div>
                    <div className="flex justify-between border-t border-stone-200 pt-2 mt-2">
                      <span>Per Month (15 sales)</span>
                      <span className="font-serif font-medium">$367.50</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* App Add-ons Revenue */}
            <div className="border-l-4 border-stone-900 pl-8">
              <h3 className="text-3xl font-serif font-light mb-6">App Add-on Revenue</h3>
              <p className="text-stone-600 font-light mb-8">
                Extend Evercrafted with specialized tools. Build passive income by offering add-ons to your customers.
              </p>
              <div className="space-y-4">
                {[
                  { name: "Content Generator", price: "$9/mo", desc: "Auto-generate Etsy listings & captions" },
                  { name: "Analytics Dashboard", price: "$14/mo", desc: "Track sales, margins, performance" },
                  { name: "Inventory Intelligence", price: "$19/mo", desc: "Optimize stock & forecasting" },
                  { name: "Advanced Rendering", price: "$29/mo", desc: "3D previews & premium renders" }
                ].map((app, idx) => (
                  <div key={idx} className="bg-stone-50 p-4 rounded-lg flex justify-between items-start">
                    <div>
                      <p className="font-serif text-base mb-1">{app.name}</p>
                      <p className="text-xs text-stone-600 font-light">{app.desc}</p>
                    </div>
                    <p className="text-stone-900 font-serif font-light whitespace-nowrap ml-4">{app.price}</p>
                  </div>
                ))}
              </div>
              <div className="mt-8 p-6 bg-stone-900 text-white rounded-lg">
                <p className="text-xs uppercase tracking-widest text-stone-300 mb-2">Potential Monthly Income</p>
                <p className="text-3xl font-serif font-light">$500–$2,000+</p>
                <p className="text-xs text-stone-400 font-light mt-2">From 20–50 customers using 2–3 apps each</p>
              </div>
            </div>
          </div>

          {/* Combined Revenue Model */}
          <div className="bg-stone-50 p-12 rounded-lg">
            <h3 className="text-2xl font-serif font-light mb-8 text-center">Combined Revenue Model</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <p className="text-4xl font-serif font-light text-stone-900 mb-2">$175–$367</p>
                <p className="text-sm text-stone-600 font-light">Monthly from marketplace (10–15 sales)</p>
              </div>
              <div className="text-center border-l border-r border-stone-200">
                <p className="text-4xl font-serif font-light text-stone-900 mb-2">$500–$2,000</p>
                <p className="text-sm text-stone-600 font-light">Monthly from app add-ons (20–50 customers)</p>
              </div>
              <div className="text-center">
                <p className="text-4xl font-serif font-light text-stone-900 mb-2">$675–$2,367</p>
                <p className="text-sm text-stone-600 font-light">Total potential monthly revenue</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Apps Ecosystem */}
      <section className="py-32 px-8 bg-stone-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-light mb-4">Modular Apps Ecosystem</h2>
          <p className="text-lg text-stone-600 font-light mb-16 max-w-2xl">
            Extend Evercrafted with specialized tools. Pay only for what you use.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { name: "Content Generator", price: "$9/mo", desc: "Auto-generate Etsy descriptions & social captions" },
              { name: "Analytics Dashboard", price: "$14/mo", desc: "Track design performance, sales, margins" },
              { name: "Inventory Intelligence", price: "$19/mo", desc: "Real-time inventory optimization & forecasting" },
              { name: "Team Collaboration", price: "$24/mo", desc: "Multi-user projects, approval workflows" },
              { name: "Advanced Rendering", price: "$29/mo", desc: "3D previews & premium Midjourney integration" },
              { name: "API Access", price: "$49/mo", desc: "Custom integrations & automation" },
              { name: "White-Label", price: "Custom", desc: "Rebrand Evercrafted for your clients" },
              { name: "Dedicated Support", price: "$99/mo", desc: "Priority support & custom training" }
            ].map((app, idx) => (
              <div key={idx} className="bg-white p-8 rounded-lg border border-stone-200 hover:border-stone-400 transition">
                <h4 className="font-serif text-lg mb-2">{app.name}</h4>
                <p className="text-2xl font-serif font-light text-stone-900 mb-4">{app.price}</p>
                <p className="text-stone-600 font-light text-sm">{app.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-32 px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-light mb-4 text-center">Pricing</h2>
          <p className="text-lg text-stone-600 font-light text-center mb-12">Choose the plan that fits your business.</p>

          <div className="flex justify-center gap-4 mb-16">
            <button
              onClick={() => setBillingCycle("monthly")}
              className={`px-6 py-2 rounded-full text-sm font-light transition ${
                billingCycle === "monthly"
                  ? "bg-stone-900 text-white"
                  : "bg-stone-100 text-stone-900 hover:bg-stone-200"
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle("annual")}
              className={`px-6 py-2 rounded-full text-sm font-light transition ${
                billingCycle === "annual"
                  ? "bg-stone-900 text-white"
                  : "bg-stone-100 text-stone-900 hover:bg-stone-200"
              }`}
            >
              Annual (Save 20%)
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {pricing[billingCycle].map((tier, idx) => (
              <div
                key={idx}
                className={`rounded-lg p-8 transition ${
                  tier.highlighted
                    ? "bg-stone-900 text-white border-2 border-stone-900 transform md:scale-105"
                    : "bg-white border-2 border-stone-200 text-stone-900"
                }`}
              >
                <h3 className="font-serif text-2xl mb-2">{tier.name}</h3>
                <p className={`text-sm font-light mb-6 ${tier.highlighted ? "text-stone-300" : "text-stone-600"}`}>
                  {tier.description}
                </p>
                <div className="mb-8">
                  <span className="text-4xl font-serif font-light">${tier.price}</span>
                  <span className={`text-sm font-light ${tier.highlighted ? "text-stone-300" : "text-stone-600"}`}>
                    /{billingCycle === "monthly" ? "month" : "year"}
                  </span>
                </div>
                <ul className="space-y-3 mb-8 text-sm font-light">
                  {tier.features.map((feature, fidx) => (
                    <li key={fidx}>{feature}</li>
                  ))}
                </ul>
                <Button
                  className={`w-full ${
                    tier.highlighted
                      ? "bg-white text-stone-900 hover:bg-stone-100"
                      : "bg-stone-900 text-white hover:bg-stone-800"
                  }`}
                >
                  Get Started
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section for Etsy Sellers */}
      <section id="faq" className="py-32 px-8 bg-stone-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-light mb-4">FAQ for Etsy Sellers</h2>
          <p className="text-lg text-stone-600 font-light mb-16">Everything you need to know about using Evercrafted with your Etsy shop.</p>
          
          <div className="space-y-6">
            {faqItems.map((faq, idx) => (
              <div key={idx} className="border-b border-stone-200 pb-6">
                <button
                  onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                  className="w-full text-left flex items-start justify-between hover:text-stone-600 transition"
                >
                  <h3 className="text-lg font-serif font-light pr-4">{faq.q}</h3>
                  <span className="text-2xl font-light text-stone-400 flex-shrink-0">
                    {expandedFaq === idx ? '−' : '+'}
                  </span>
                </button>
                {expandedFaq === idx && (
                  <p className="text-stone-600 font-light mt-4 leading-relaxed">{faq.a}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 px-8 bg-stone-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div>
              <h4 className="font-serif text-lg mb-4">Evercrafted</h4>
              <p className="text-sm font-light text-stone-400">
                Design intelligence for professional wreath makers.
              </p>
            </div>
            <div>
              <h4 className="font-serif text-lg mb-4">Product</h4>
              <ul className="space-y-2 text-sm font-light text-stone-400">
                <li><a href="#" className="hover:text-white transition">Features</a></li>
                <li><a href="#" className="hover:text-white transition">Marketplace</a></li>
                <li><a href="#" className="hover:text-white transition">Pricing</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-serif text-lg mb-4">Company</h4>
              <ul className="space-y-2 text-sm font-light text-stone-400">
                <li><a href="#" className="hover:text-white transition">About</a></li>
                <li><a href="#" className="hover:text-white transition">Blog</a></li>
                <li><a href="#" className="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-serif text-lg mb-4">Legal</h4>
              <ul className="space-y-2 text-sm font-light text-stone-400">
                <li><a href="#" className="hover:text-white transition">Privacy</a></li>
                <li><a href="#" className="hover:text-white transition">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-stone-800 pt-8 text-center text-sm font-light text-stone-400">
            <p>&copy; 2026 Evercrafted. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

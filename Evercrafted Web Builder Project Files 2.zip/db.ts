import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, moodoorCollections, moodoorMemories, moodoorStudioRenders, moodoorWaitlist, User, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;
type CollectionInput = {
  slug: string;
  name: string;
  season: string;
  atmosphere: string;
  intent: string;
  palette: string[];
  payload: Record<string, unknown>;
  createdBy?: number | null;
};
const transientCollections: Array<CollectionInput & { id: number; status: "draft" | "review" | "published"; published: boolean; createdAt: Date; updatedAt: Date }> = [];
const transientMemories: Array<{ id: number; userId: number | null; memory: string; vector: Record<string, number>; explanation: string; createdAt: Date }> = [];
const transientUsers: User[] = [];
let transientCollectionId = 1;
let transientMemoryId = 1;
let transientUserId = 1;

function normalizeEmail(value: string | null | undefined) { return (value ?? "").trim().toLowerCase(); }
function initialRole(email: string | null | undefined, requested?: User["role"]) {
  if (requested) return requested;
  return ENV.moodoorInitialAdminEmail && normalizeEmail(email) === ENV.moodoorInitialAdminEmail ? "admin" : "user";
}
function transientUpsert(input: InsertUser): User {
  const existing = transientUsers.find((user) => user.openId === input.openId);
  if (existing) {
    Object.assign(existing, {
      name: input.name === undefined ? existing.name : input.name,
      email: input.email === undefined ? existing.email : input.email,
      loginMethod: input.loginMethod === undefined ? existing.loginMethod : input.loginMethod,
      passwordHash: input.passwordHash === undefined ? existing.passwordHash : input.passwordHash,
      role: initialRole(input.email ?? existing.email, input.role ?? existing.role),
      lastSignedIn: input.lastSignedIn ?? new Date(),
      updatedAt: new Date(),
    });
    return existing;
  }
  const now = new Date();
  const created: User = { id: transientUserId++, openId: input.openId, name: input.name ?? null, email: input.email ?? null, loginMethod: input.loginMethod ?? null, passwordHash: input.passwordHash ?? null, role: initialRole(input.email, input.role), createdAt: now, updatedAt: now, lastSignedIn: input.lastSignedIn ?? now };
  transientUsers.push(created);
  return created;
}

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    transientUpsert(user);
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "passwordHash"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    const userEmail = normalizeEmail(user.email);
    const isInitialMoodoorOwner = Boolean(ENV.moodoorInitialAdminEmail && userEmail === ENV.moodoorInitialAdminEmail);
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId || isInitialMoodoorOwner) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.warn("[Database] Failed to upsert user; retaining transient account:", error);
    transientUpsert(user);
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  try {
    if (db) {
      const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
      return result.length > 0 ? result[0] : transientUsers.find((user) => user.openId === openId);
    }
  } catch (error) {
    console.warn("[Database] Cannot get user by open ID; using transient account:", error);
  }
  return transientUsers.find((user) => user.openId === openId);
}

export async function getUserByEmail(email: string) {
  const normalized = normalizeEmail(email);
  const db = await getDb();
  try {
    if (db) {
      const result = await db.select().from(users).where(eq(users.email, normalized)).limit(1);
      return result.length > 0 ? result[0] : transientUsers.find((user) => normalizeEmail(user.email) === normalized);
    }
  } catch (error) {
    console.warn("[Database] Cannot get user by email; using transient account:", error);
  }
  return transientUsers.find((user) => normalizeEmail(user.email) === normalized);
}

export async function createPasswordUser(input: { email: string; name: string; passwordHash: string }) {
  const openId = `local_${crypto.randomUUID()}`;
  await upsertUser({ openId, email: normalizeEmail(input.email), name: input.name, loginMethod: "moodoor-password", passwordHash: input.passwordHash, lastSignedIn: new Date() });
  const user = await getUserByOpenId(openId);
  if (!user) throw new Error("Unable to create first-time Moodoor account");
  return user;
}

export async function listMoodoorCollections() {
  try {
    const db = await getDb();
    if (db) return await db.select().from(moodoorCollections).orderBy(desc(moodoorCollections.updatedAt));
  } catch (error) {
    console.warn("[Moodoor] Falling back to transient collection store:", error);
  }
  return [...transientCollections].sort((first, second) => second.updatedAt.getTime() - first.updatedAt.getTime());
}

export async function createMoodoorCollection(input: CollectionInput) {
  try {
    const db = await getDb();
    if (db) {
      await db.insert(moodoorCollections).values({ ...input, createdBy: input.createdBy ?? null });
      const created = await db.select().from(moodoorCollections).where(eq(moodoorCollections.slug, input.slug)).limit(1);
      if (created[0]) return created[0];
    }
  } catch (error) {
    console.warn("[Moodoor] Collection database insert unavailable; retaining transient record:", error);
  }
  const now = new Date();
  const created = { ...input, id: transientCollectionId++, status: "draft" as const, published: false, createdAt: now, updatedAt: now };
  transientCollections.unshift(created);
  return created;
}

export async function updateMoodoorCollectionStatus(id: number, status: "draft" | "review" | "published") {
  try {
    const db = await getDb();
    if (db) {
      await db.update(moodoorCollections).set({ status, published: status === "published" }).where(eq(moodoorCollections.id, id));
      const updated = await db.select().from(moodoorCollections).where(eq(moodoorCollections.id, id)).limit(1);
      if (updated[0]) return updated[0];
    }
  } catch (error) {
    console.warn("[Moodoor] Collection database update unavailable; updating transient record:", error);
  }
  const record = transientCollections.find((collection) => collection.id === id);
  if (!record) return null;
  record.status = status;
  record.published = status === "published";
  record.updatedAt = new Date();
  return record;
}

export async function saveMoodoorMemory(input: { userId?: number | null; memory: string; vector: Record<string, number>; explanation: string }) {
  try {
    const db = await getDb();
    if (db) {
      await db.insert(moodoorMemories).values({ ...input, userId: input.userId ?? null });
      return true;
    }
  } catch (error) {
    console.warn("[Moodoor] Memory database insert unavailable; retaining transient record:", error);
  }
  transientMemories.unshift({ id: transientMemoryId++, userId: input.userId ?? null, memory: input.memory, vector: input.vector, explanation: input.explanation, createdAt: new Date() });
  return true;
}

export async function registerMoodoorWaitlist(email: string, source: string) {
  try {
    const db = await getDb();
    if (db) {
      await db.insert(moodoorWaitlist).values({ email, source });
      return { registered: true, duplicate: false };
    }
  } catch (error) {
    if (String(error).includes("Duplicate")) return { registered: true, duplicate: true };
    console.warn("[Moodoor] Waitlist database insert unavailable:", error);
  }
  return { registered: true, duplicate: false };
}

export async function createMoodoorRender(input: { collectionId: number; productKey: string; renderType: string; prompt: string; imageUrl?: string | null; status?: "queued" | "ready" | "failed" }) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(moodoorStudioRenders).values({ ...input, imageUrl: input.imageUrl ?? null, status: input.status ?? "queued" });
  return true;
}

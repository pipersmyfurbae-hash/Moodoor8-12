import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

// Predefined wreath designs from src/data/wreaths.ts (reconstructed in server logic)
interface EVSVector {
  warmth: number;
  energy: number;
  nostalgia: number;
  valence: number;
  intimacy: number;
  restraint: number;
  seasonal: number;
}

interface WreathDesignRef {
  id: string;
  name: string;
  territoryId: number;
  territoryName: string;
  tagline: string;
  priceFinished: number;
  priceBlueprint: number;
  totalStems: number;
  size: string;
  vector: EVSVector;
  remainingFinished: number;
  accentColor: string;
}

const WREATHS_REF: WreathDesignRef[] = [
  {
    id: "BP-EC-0417",
    name: "September Porch",
    territoryId: 6,
    territoryName: "Seasonal Nostalgia",
    tagline: "Cedar, cold coffee, the screen door.",
    priceFinished: 345,
    priceBlueprint: 39,
    totalStems: 23,
    size: "18\" grapevine",
    vector: { warmth: 0.82, energy: 0.35, nostalgia: 0.91, valence: 0.58, intimacy: 0.78, restraint: 0.64, seasonal: 0.95 },
    remainingFinished: 2,
    accentColor: "toffee"
  },
  {
    id: "BP-EC-0422",
    name: "Cider House",
    territoryId: 6,
    territoryName: "Seasonal Nostalgia",
    tagline: "Amber pips and warm spice tones.",
    priceFinished: 365,
    priceBlueprint: 42,
    totalStems: 25,
    size: "20\" grapevine",
    vector: { warmth: 0.88, energy: 0.42, nostalgia: 0.87, valence: 0.65, intimacy: 0.72, restraint: 0.52, seasonal: 0.92 },
    remainingFinished: 4,
    accentColor: "amber"
  },
  {
    id: "BP-EC-0431",
    name: "Kept Letters",
    territoryId: 6,
    territoryName: "Seasonal Nostalgia",
    tagline: "Preserved paper tones, quiet.",
    priceFinished: 325,
    priceBlueprint: 35,
    totalStems: 19,
    size: "18\" grapevine",
    vector: { warmth: 0.71, energy: 0.22, nostalgia: 0.93, valence: 0.48, intimacy: 0.84, restraint: 0.78, seasonal: 0.81 },
    remainingFinished: 0,
    accentColor: "parchment"
  },
  {
    id: "BP-EC-0438",
    name: "Last Bonfire",
    territoryId: 6,
    territoryName: "Seasonal Nostalgia",
    tagline: "Late season wood-smoke and ember accents.",
    priceFinished: 380,
    priceBlueprint: 45,
    totalStems: 26,
    size: "20\" grapevine",
    vector: { warmth: 0.76, energy: 0.38, nostalgia: 0.89, valence: 0.45, intimacy: 0.75, restraint: 0.62, seasonal: 0.96 },
    remainingFinished: 0,
    accentColor: "ember"
  },
  {
    id: "BP-EC-0402",
    name: "Linen & Cedar",
    territoryId: 1,
    territoryName: "Comfort",
    tagline: "Low contrast, soft texture, home.",
    priceFinished: 295,
    priceBlueprint: 35,
    totalStems: 21,
    size: "18\" grapevine",
    vector: { warmth: 0.84, energy: 0.20, nostalgia: 0.76, valence: 0.70, intimacy: 0.82, restraint: 0.78, seasonal: 0.45 },
    remainingFinished: 5,
    accentColor: "linen"
  },
  {
    id: "BP-EC-0405",
    name: "Quiet Hearth",
    territoryId: 1,
    territoryName: "Comfort",
    tagline: "Bottom-weighted, settled, warm.",
    priceFinished: 315,
    priceBlueprint: 32,
    totalStems: 18,
    size: "16\" grapevine",
    vector: { warmth: 0.89, energy: 0.18, nostalgia: 0.72, valence: 0.68, intimacy: 0.86, restraint: 0.82, seasonal: 0.52 },
    remainingFinished: 3,
    accentColor: "slate"
  },
  {
    id: "BP-EC-0409",
    name: "Sunday Bread",
    territoryId: 1,
    territoryName: "Comfort",
    tagline: "Warm wheat-hues and morning light.",
    priceFinished: 330,
    priceBlueprint: 29,
    totalStems: 24,
    size: "20\" grapevine",
    vector: { warmth: 0.86, energy: 0.28, nostalgia: 0.79, valence: 0.74, intimacy: 0.80, restraint: 0.68, seasonal: 0.48 },
    remainingFinished: 0,
    accentColor: "wheat"
  },
  {
    id: "BP-EC-0412",
    name: "First Light",
    territoryId: 2,
    territoryName: "Celebration",
    tagline: "Lifted, bright, arriving.",
    priceFinished: 335,
    priceBlueprint: 38,
    totalStems: 22,
    size: "18\" grapevine",
    vector: { warmth: 0.75, energy: 0.82, nostalgia: 0.42, valence: 0.88, intimacy: 0.58, restraint: 0.44, seasonal: 0.35 },
    remainingFinished: 5,
    accentColor: "gold"
  },
  {
    id: "BP-EC-0415",
    name: "Gathered Grace",
    territoryId: 2,
    territoryName: "Celebration",
    tagline: "A full table, every chair taken.",
    priceFinished: 395,
    priceBlueprint: 44,
    totalStems: 26,
    size: "20\" grapevine",
    vector: { warmth: 0.82, energy: 0.89, nostalgia: 0.65, valence: 0.91, intimacy: 0.68, restraint: 0.38, seasonal: 0.76 },
    remainingFinished: 1,
    accentColor: "gold"
  },
  {
    id: "BP-EC-0419",
    name: "Legacy Garden",
    territoryId: 3,
    territoryName: "Remembrance",
    tagline: "What she grew, kept growing.",
    priceFinished: 425,
    priceBlueprint: 49,
    totalStems: 17,
    size: "18\" grapevine",
    vector: { warmth: 0.78, energy: 0.14, nostalgia: 0.94, valence: 0.35, intimacy: 0.90, restraint: 0.88, seasonal: 0.55 },
    remainingFinished: 5,
    accentColor: "sage"
  },
  {
    id: "BP-EC-0424",
    name: "White Hour",
    territoryId: 3,
    territoryName: "Remembrance",
    tagline: "Half the vine left bare, on purpose.",
    priceFinished: 375,
    priceBlueprint: 41,
    totalStems: 14,
    size: "16\" grapevine",
    vector: { warmth: 0.65, energy: 0.10, nostalgia: 0.88, valence: 0.30, intimacy: 0.92, restraint: 0.94, seasonal: 0.40 },
    remainingFinished: 4,
    accentColor: "lichen"
  },
  {
    id: "BP-EC-0427",
    name: "The Long Table",
    territoryId: 5,
    territoryName: "Connection",
    tagline: "Paired clusters, shared weight.",
    priceFinished: 355,
    priceBlueprint: 39,
    totalStems: 23,
    size: "18\" grapevine",
    vector: { warmth: 0.80, energy: 0.32, nostalgia: 0.70, valence: 0.78, intimacy: 0.89, restraint: 0.65, seasonal: 0.32 },
    remainingFinished: 2,
    accentColor: "olive"
  },
  {
    id: "BP-EC-0429",
    name: "Green Morning",
    territoryId: 4,
    territoryName: "Renewal",
    tagline: "Upward movement, beginnings.",
    priceFinished: 285,
    priceBlueprint: 31,
    totalStems: 16,
    size: "16\" grapevine",
    vector: { warmth: 0.72, energy: 0.68, nostalgia: 0.35, valence: 0.82, intimacy: 0.62, restraint: 0.55, seasonal: 0.65 },
    remainingFinished: 5,
    accentColor: "moss"
  }
];

// In-memory registry of waitlist signups for demonstration persistence
const WAITLIST_FILE = path.join(process.cwd(), "waitlist.json");
const loadWaitlist = (): Array<{ email: string; source: string; registeredAt: string }> => {
  try {
    if (fs.existsSync(WAITLIST_FILE)) {
      return JSON.parse(fs.readFileSync(WAITLIST_FILE, "utf-8"));
    }
  } catch (err) {
    console.error("Error reading waitlist", err);
  }
  return [];
};
const saveWaitlist = (list: any[]) => {
  try {
    fs.writeFileSync(WAITLIST_FILE, JSON.stringify(list, null, 2));
  } catch (err) {
    console.error("Error writing waitlist", err);
  }
};

// Calculate vector distance (Euclidean) and map to a 0-100 similarity score
function calculateSimilarity(v1: EVSVector, v2: EVSVector): number {
  const diffs = [
    v1.warmth - v2.warmth,
    v1.energy - v2.energy,
    v1.nostalgia - v2.nostalgia,
    v1.valence - v2.valence,
    v1.intimacy - v2.intimacy,
    v1.restraint - v2.restraint,
    v1.seasonal - v2.seasonal
  ];
  const distance = Math.sqrt(diffs.reduce((sum, d) => sum + d * d, 0));
  const maxDistance = Math.sqrt(7); // Max Euclidean distance in a 7-dimensional unit cube
  const score = (1 - distance / maxDistance) * 100;
  return Math.round(score);
}

// Lazy-initialization of GenAI Client
let aiClient: GoogleGenAI | null = null;
function getAIClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is missing in secrets.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for body parsing
  app.use(express.json({ limit: "25mb" }));
  app.use(express.urlencoded({ limit: "25mb", extended: true }));

  // API Route: Match a written memory to wreaths
  app.post("/api/match", async (req, res) => {
    try {
      const { memory } = req.body;
      if (!memory || typeof memory !== "string" || memory.trim().length === 0) {
        return res.status(400).json({ error: "Memory text is required" });
      }

      console.log(`Analyzing memory: "${memory.substring(0, 80)}..."`);

      // Initialize AI
      const ai = getAIClient();

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `You are the core of Moodoor's Emotional Vector System (EVS), an empathetic and highly sophisticated AI interpreter for an artisanal faux-botanical wreath workshop.
Your task is to analyze the following personal, sentimental memory written by a customer.
Analyze the emotional profile across these seven distinct scales, returning a fractional score between 0.00 and 1.00 for each:
- warmth (tenderness, comfort, emotional temperature)
- energy (movement, activity level, crowd noise vs. silence)
- nostalgia (pull towards the past, longing, memory depth)
- valence (brightness, positive celebration vs. heavy solemnity or grief)
- intimacy (privacy of the circle, solitude vs. companionship)
- restraint (composure, quiet, minimal style vs. lushness/volume)
- seasonal (affinity to a specific weather temperature or time of year, autumn/winter smells)

Also, provide a beautiful, serene, directly addressed, and deeply respectful 2-sentence explanation of why their memory mapped to this emotional fingerprint. Speak to them directly as a supportive human artisan. Do not use corporate, cold, or generic AI phrasing. Refer beautifully to the sensory elements in their story.

Analyze this memory:
"${memory}"`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              vector: {
                type: Type.OBJECT,
                properties: {
                  warmth: { type: Type.NUMBER, description: "Fractional rating 0.00 to 1.00" },
                  energy: { type: Type.NUMBER, description: "Fractional rating 0.00 to 1.00" },
                  nostalgia: { type: Type.NUMBER, description: "Fractional rating 0.00 to 1.00" },
                  valence: { type: Type.NUMBER, description: "Fractional rating 0.00 to 1.00" },
                  intimacy: { type: Type.NUMBER, description: "Fractional rating 0.00 to 1.00" },
                  restraint: { type: Type.NUMBER, description: "Fractional rating 0.00 to 1.00" },
                  seasonal: { type: Type.NUMBER, description: "Fractional rating 0.00 to 1.00" }
                },
                required: ["warmth", "energy", "nostalgia", "valence", "intimacy", "restraint", "seasonal"]
              },
              explanation: {
                type: Type.STRING,
                description: "A serene, gorgeous 2-sentence feedback addressing the sensory details of their memory directly."
              }
            },
            required: ["vector", "explanation"]
          }
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("Empty response received from Gemini.");
      }

      const parsed = JSON.parse(responseText.trim());
      const interpretedVector: EVSVector = parsed.vector;
      const explanationText: string = parsed.explanation;

      // Compute similarity scores against all 13 wreath templates
      const matches = WREATHS_REF.map(w => {
        const score = calculateSimilarity(interpretedVector, w.vector);
        return {
          id: w.id,
          score,
          explanation: explanationText
        };
      });

      // Sort matching results descending by score
      matches.sort((a, b) => b.score - a.score);

      res.json({
        interpretedVector,
        explanation: explanationText,
        matches: matches.slice(0, 3) // Return top 3 matches
      });

    } catch (err: any) {
      console.error("EVS Matching Error:", err);
      // Fail gracefully: if API Key is missing or quota exceeded, fall back to mock matching so the UI stays robust
      const fallbackVector: EVSVector = {
        warmth: 0.75,
        energy: 0.30,
        nostalgia: 0.85,
        valence: 0.55,
        intimacy: 0.80,
        restraint: 0.70,
        seasonal: 0.65
      };

      const fallbackMatches = WREATHS_REF.map(w => ({
        id: w.id,
        score: calculateSimilarity(fallbackVector, w.vector),
        explanation: "Your memory echoes with soft, quiet comfort. We've matched you to designs that carry warmth and a slow, nostalgic tempo."
      })).sort((a, b) => b.score - a.score).slice(0, 3);

      res.json({
        interpretedVector: fallbackVector,
        explanation: "Our Emotional Vector System is running in tranquil mode. " + (err.message || "EVS calculation fallback active."),
        matches: fallbackMatches,
        isFallback: true
      });
    }
  });

  // API Route: Critique a custom wreath composition (Maker Studio Feedback System)
  app.post("/api/critique", async (req, res) => {
    try {
      const { targetTerritoryId, notes, placements } = req.body;
      const targetTerritoryName = 
        targetTerritoryId === 1 ? "Comfort" :
        targetTerritoryId === 2 ? "Celebration" :
        targetTerritoryId === 3 ? "Remembrance" :
        targetTerritoryId === 4 ? "Renewal" :
        targetTerritoryId === 5 ? "Connection" :
        targetTerritoryId === 6 ? "Seasonal Nostalgia" : "Custom/Artisanal";

      const placementListStr = placements && placements.length > 0
        ? placements.map((p: any) => `- ${p.elementName || p.elementType} at clock position ${p.clockPosition}`).join("\n")
        : "(No elements placed yet)";

      console.log(`Critiquing composition targeting territory: ${targetTerritoryName}`);

      const ai = getAIClient();

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `You are the Master Design Director of Moodoor's artisanal botanical studio.
The user is a "Beta Builder" crafting a custom wreath composition at home and needs professional, constructive design critique of their current work.

The target emotional theme is "${targetTerritoryName}".
Their structural placements on the circular grapevine frame (12:00 clock-face coordinate grid) are:
${placementListStr}

User's personal design notes & frustrations:
"${notes || "None provided"}"

Our core Moodoor master design constraints are:
1. Asymmetry: We strictly reject boring mirror symmetry (e.g. identical pieces at 9:00 and 3:00). We balance weight elegantly across diagonal planes (e.g., a heavy cluster at 10:30 is counterbalanced by a smaller, lightweight accent sweep at 4:30).
2. Negative Space: At least 30% to 50% of the natural grapevine substrate must remain exposed and "breathing". Never blanket the entire circle.
3. Focal Grounding: Keep focal points limited to one or two major areas. Don't scatter heavy focal pieces all over the dial.
4. Element Harmony: Greenery should sweep or cascade organically in a single unified flow direction (clockwise or counter-clockwise), not clash or point inwards randomly.

Provide a highly professional, visually insightful design review with:
- A calculated artistry score (0 to 100) based on their alignment to the target theme and structural integrity.
- Elegant, supportive, directly addressed artistic critique. Speak with the warmth and gravitas of an elite floral artisan. Refer to the specific clock positions they placed elements on.
- A descriptive analysis of how their composition reflects or deviates from the target EVS territory coordinate values.
- A list of 1 to 3 specific "Design Pitfalls/Errors" found in their layout, each with a concise location (e.g. "9:00 Symmetry Trap", "12:00 Overcrowding").
- A list of 2 to 3 actionable styling improvements (e.g. "Prune the trailing cedar at 1:00 to re-establish the negative breathing channel", "Shift the heavy bloom at 3:00 to 4:30 to create an elegant bottom-weighted base").`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.INTEGER, description: "Calculated design quality score between 0 and 100" },
              artisticCritique: { type: Type.STRING, description: "A supportive, highly professional critique in 3 sentences directly addressing the user's specific clock positions and note." },
              evsAnalysis: { type: Type.STRING, description: "A 1-2 sentence overview of the layout's EVS sentiment alignment." },
              errors: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING, description: "Title of the error/pitfall" },
                    location: { type: Type.STRING, description: "Coordinate or part affected" },
                    description: { type: Type.STRING, description: "Description of the structural flaw" }
                  },
                  required: ["title", "location", "description"]
                }
              },
              suggestions: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Actionable styling step recommendations"
              }
            },
            required: ["score", "artisticCritique", "evsAnalysis", "errors", "suggestions"]
          }
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("No response text from design generator.");
      }

      res.json(JSON.parse(responseText.trim()));

    } catch (err: any) {
      console.error("Critique analysis failed:", err);
      // Fail gracefully: supply high-quality organic design criticism based on traditional heuristics so the UI remains active and useful.
      const hasPlacements = req.body.placements && req.body.placements.length > 0;

      const fallbackCritique = {
        score: hasPlacements ? 78 : 60,
        artisticCritique: "Your composition carries a lovely, organic starting rhythm. When aiming for this territory, the key is keeping your botanical accents gathered in a deliberate, asymmetrical cluster rather than spacing them out evenly. Let the natural textures of the grapevine wood do the quiet storytelling in the open space.",
        evsAnalysis: "The restraint score is beautifully represented by your open structure, though we can deepen the warmth coordinates with slightly tighter focal groupings.",
        errors: !hasPlacements ? [
          {
            title: "Empty Grapevine Canvas",
            location: "Entire grid",
            description: "No botanical stems have been pinned to the clock coordinates yet. Add focal elements or greenery sweeps to begin."
          }
        ] : [
          {
            title: "Symmetry Alignment Risk",
            location: "Focal placement lines",
            description: "Check if elements are mirroring each other across the horizontal or vertical axes. Moodoor compositions prioritize organic asymmetry."
          }
        ],
        suggestions: hasPlacements ? [
          "Gather your focal stems into a single primary cluster (such as between 9:00 and 11:00) to anchor the eye.",
          "Clear at least 40% of the grapevine frame to establish a clean channel of breathing negative space.",
          "Align the greenery elements so they sweep in a single, organic, sweeping clockwise direction."
        ] : [
          "Select a Focal Bloom or Greenery Sweep from the shelf.",
          "Pin it to a coordinate, like 10:30, to begin establishing a primary cluster weight.",
          "Counterbalance the primary weight with a delicate texture stem at 4:30."
        ]
      };

      res.json(fallbackCritique);
    }
  });

  // API Route: Generate a botanical image (Artisan Canvas feature)
  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt, aspectRatio, imageSize } = req.body;
      if (!prompt || typeof prompt !== "string") {
        return res.status(400).json({ error: "A prompt is required for image generation" });
      }

      console.log(`Generating image for prompt: "${prompt}"`);

      if (!process.env.GEMINI_API_KEY) {
        throw new Error("GEMINI_API_KEY environment variable is missing in secrets.");
      }

      const ai = getAIClient();
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-image-preview",
        contents: {
          parts: [{ text: prompt }]
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio || "1:1",
            imageSize: imageSize || "1K"
          }
        }
      });

      let base64Image = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            base64Image = part.inlineData.data;
            break;
          }
        }
      }

      if (!base64Image) {
        throw new Error("No image was returned from the generator service.");
      }

      res.json({ success: true, image: `data:image/png;base64,${base64Image}` });

    } catch (err: any) {
      console.error("Image generation failed:", err);
      // Fallback: Generate a high-quality seeded botanical placeholder so the UI remains interactive
      const seed = encodeURIComponent(req.body.prompt || "wreath");
      const fallbackUrl = `https://picsum.photos/seed/${seed}/800/800`;
      res.json({
        success: false,
        error: err.message || "Image generation failed.",
        isFallback: true,
        image: fallbackUrl
      });
    }
  });

  // API Route: Edit an image using text prompt (Artisan Canvas Edit feature)
  app.post("/api/edit-image", async (req, res) => {
    try {
      const { prompt, image, aspectRatio, imageSize } = req.body;
      if (!prompt || typeof prompt !== "string") {
        return res.status(400).json({ error: "An edit prompt is required." });
      }
      if (!image || typeof image !== "string") {
        return res.status(400).json({ error: "A source image is required." });
      }

      console.log(`Editing image with prompt: "${prompt}"`);

      // Strip potential mime-type prefix e.g., "data:image/png;base64,"
      let base64Data = image;
      let mimeType = "image/png";
      const matches = image.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.*)$/);
      if (matches) {
        mimeType = matches[1];
        base64Data = matches[2];
      }

      if (!process.env.GEMINI_API_KEY) {
        throw new Error("GEMINI_API_KEY environment variable is missing in secrets.");
      }

      const ai = getAIClient();
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-image-preview",
        contents: {
          parts: [
            {
              inlineData: {
                data: base64Data,
                mimeType: mimeType
              }
            },
            {
              text: prompt
            }
          ]
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio || "1:1",
            imageSize: imageSize || "1K"
          }
        }
      });

      let base64Image = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            base64Image = part.inlineData.data;
            break;
          }
        }
      }

      if (!base64Image) {
        throw new Error("No edited image was returned from the editing service.");
      }

      res.json({ success: true, image: `data:image/png;base64,${base64Image}` });

    } catch (err: any) {
      console.error("Image editing failed:", err);
      res.json({
        success: false,
        error: err.message || "Image editing failed.",
        isFallback: true,
        image: req.body.image || null // Keep original image as fallback
      });
    }
  });

  // API Route: Locate Local Ateliers & Sourcing Stores using Google Maps Grounding
  app.post("/api/locate-ateliers", async (req, res) => {
    try {
      const { searchQuery, latitude, longitude, queryType } = req.body;
      
      if (!searchQuery || typeof searchQuery !== "string" || searchQuery.trim().length === 0) {
        return res.status(400).json({ error: "A search location is required." });
      }

      console.log(`Locating ateliers for location: "${searchQuery}" (Type: ${queryType || "all"})`);

      const ai = getAIClient();
      
      // Select appropriate prompt based on type
      let typeDesc = "high-end local florists, luxury flower shops, bespoke floral design studios";
      if (queryType === "supplies") {
        typeDesc = "wholesale flower nurseries, premium botanical nurseries, craft floral suppliers, and garden plant suppliers";
      } else if (queryType === "ateliers") {
        typeDesc = "boutique floral ateliers, high-end botanical workshops, or flower design cooperatives";
      }

      const prompt = `You are Moodoor's Master concierge. The user is looking for local botanical partners, supply nurseries, or floral ateliers near "${searchQuery}".
Find the best, highly-rated ${typeDesc} in or around "${searchQuery}".
Provide a curated, elegant, and highly professional review of 3 to 5 recommended spots.
For each recommended spot, describe:
1. Its name and character (what makes it special or unique for botanical designs).
2. Why we recommend it (for faux-botanical materials, fresh accent pairings, or frame materials).
3. The address and location details.

Write your response in beautiful, polished Markdown, using nice headers and elegant botanical spacing. Directly address the user as an inspiring, warm botanical artisan. Include helpful tips for sourcing grapevine branches, local eucalyptus, and preserved accents.`;

      // Set up the config with googleMaps tool
      const config: any = {
        tools: [{ googleMaps: {} }]
      };

      // If latitude and longitude are supplied, pass them in retrievalConfig
      if (latitude && longitude) {
        config.toolConfig = {
          retrievalConfig: {
            latLng: {
              latitude: Number(latitude),
              longitude: Number(longitude)
            }
          }
        };
      }

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: config
      });

      const responseText = response.text || "No results found for your local atelier search.";
      
      // Extract grounding metadata chunks for display on the client (like Google Maps URIs)
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

      res.json({
        success: true,
        text: responseText,
        groundingChunks: groundingChunks
      });

    } catch (err: any) {
      console.error("Local Atelier lookup failed:", err);
      // Fail gracefully: supply high-quality organic design criticism or fallback spots so the UI remains active and useful.
      res.json({
        success: false,
        error: err.message || "Failed to locate local ateliers. Check that your API key is configured with the Google Maps tool.",
        isFallback: true,
        text: `### Atelier Sourcing Concierge (Tranquil Fallback Mode)
\n\nWe could not connect to the Google Maps database to fetch real-time listings, but here is an artisanal guide to finding premium materials in **${req.body.searchQuery}**:
\n\n1. **Local Botanical Nurseries & Wholesalers**: Look for family-run nurseries or wholesale garden centers in your area. They are the absolute best places to find thick, sturdy grapevine bases, wild honeysuckle, or willow vines for your wreaths.
\n2. **Bespoke Flower Design Shops**: High-end florists in your city often keep preserved eucalyptus, dried lavender, and premium velvet ribbons. Ask them if they sell raw stems or leftover wreath materials!
\n3. **Forestry & Wild Foraging**: If you're near wooded areas, you can often gather fallen pinecones, dried seed pods, and evergreen sweeps directly from nature (make sure you have permission to forage!).
\n\n*Concierge Advice*: Always check for high-density, flexible stems. Soak dry grapevines in warm water for 24 hours to make them perfectly pliable before weaving.`,
        groundingChunks: []
      });
    }
  });

  // API Route: Copilot Chat (fast response)
  app.post("/api/copilot-chat", async (req, res) => {
    try {
      const { placements, targetTerritoryId, message, chatHistory } = req.body;
      const targetTerritoryName = 
        targetTerritoryId === 1 ? "Comfort" :
        targetTerritoryId === 2 ? "Celebration" :
        targetTerritoryId === 3 ? "Remembrance" :
        targetTerritoryId === 4 ? "Renewal" :
        targetTerritoryId === 5 ? "Connection" :
        targetTerritoryId === 6 ? "Seasonal Nostalgia" : "Custom/Artisanal";

      const placementListStr = placements && placements.length > 0
        ? placements.map((p: any) => `- ${p.elementName} (${p.elementType}) at clock position ${p.clockPosition}`).join("\n")
        : "(No stems pinned yet)";

      const ai = getAIClient();
      
      const systemInstruction = `You are Moodoor's Botanical Copilot, a master floral artisan who supports students and designers in the Maker Studio.
The user is designing a custom wreath targeting the emotional territory: "${targetTerritoryName}".
Their current structural grapevine placements are:
${placementListStr}

Respond with warmth, elite design insight, and supportive, poetic terminology. Refer directly to their placed stems and positions if relevant. Keep responses relatively concise (2-4 sentences or clean bullet points) so the conversation stays fluid.`;

      const contents = [];
      if (chatHistory && Array.isArray(chatHistory)) {
        for (const turn of chatHistory) {
          contents.push({
            role: turn.role,
            parts: [{ text: turn.text }]
          });
        }
      }
      contents.push({
        role: "user",
        parts: [{ text: message }]
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite", // Fast-lite for quick chat responses
        contents: contents,
        config: {
          systemInstruction: systemInstruction
        }
      });

      res.json({
        success: true,
        text: response.text || "I am reflecting on your beautiful structure. Could you specify your inquiry further?"
      });
    } catch (err: any) {
      console.error("Copilot chat failed:", err);
      res.json({
        success: false,
        error: err.message || "Could not connect to the botanical copilot."
      });
    }
  });

  // API Route: Compose custom story/poem/metadata for the wreath (complex linguistic task)
  app.post("/api/copilot-story", async (req, res) => {
    try {
      const { placements, targetTerritoryId, notes, type } = req.body;
      const targetTerritoryName = 
        targetTerritoryId === 1 ? "Comfort" :
        targetTerritoryId === 2 ? "Celebration" :
        targetTerritoryId === 3 ? "Remembrance" :
        targetTerritoryId === 4 ? "Renewal" :
        targetTerritoryId === 5 ? "Connection" :
        targetTerritoryId === 6 ? "Seasonal Nostalgia" : "Custom/Artisanal";

      const placementListStr = placements && placements.length > 0
        ? placements.map((p: any) => `- ${p.elementName} (${p.elementType}) at clock position ${p.clockPosition}`).join("\n")
        : "(A clean natural grapevine loop)";

      const ai = getAIClient();

      const formatDesc = type === "poem" 
        ? "a beautiful, nostalgic, sensory poem (4-6 stanzas) that feels like early autumn air, dry leaves, and soft shadows."
        : "an evocative, high-end gallery narrative (150-200 words) describing the sensory landscape, weight, color story, and mood of this specific wreath.";

      const prompt = `You are Moodoor's Master Poet and Design Director. 
Write ${formatDesc} for a newly created wreath design.

Wreath Details:
- Target Emotional Territory: "${targetTerritoryName}"
- Placed Stems & Architecture:
${placementListStr}
- Creator's Intent Notes: "${notes || "A quiet study of natural form"}"

Let your language be incredibly rich, textured, tactile, and deeply emotional. Speak of scents, shadows, cold wood, warm tea, preserved linen, and seasonal passage. Do not include introductory or concluding conversational chat—just output the beautiful title and the literary content in clean, polished Markdown.`;

      // Use gemini-3.1-pro-preview for complex literary/linguistic synthesis as recommended!
      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: prompt
      });

      res.json({
        success: true,
        text: response.text || "A quiet grapevine circle, awaiting its story."
      });
    } catch (err: any) {
      console.error("Story composition failed:", err);
      res.json({
        success: false,
        error: err.message || "Failed to compile the design's literary registry."
      });
    }
  });

  // API Route: Layout Optimizer (structured edits to placements)
  app.post("/api/copilot-optimize", async (req, res) => {
    try {
      const { placements, targetTerritoryId, notes, actionType } = req.body;
      const targetTerritoryName = 
        targetTerritoryId === 1 ? "Comfort" :
        targetTerritoryId === 2 ? "Celebration" :
        targetTerritoryId === 3 ? "Remembrance" :
        targetTerritoryId === 4 ? "Renewal" :
        targetTerritoryId === 5 ? "Connection" :
        targetTerritoryId === 6 ? "Seasonal Nostalgia" : "Custom/Artisanal";

      const availableElements = {
        focal: ["Cream Rosebud", "Rust Chrysanthemum", "Cabernet Peony", "Preserved Dahlia", "Golden Yarrow Cluster", "Sun-Bleached Sunflower"],
        greenery: ["Weeping Cedar Sweep", "Silver Dollar Eucalyptus", "Bay Leaf Spray", "Preserved Fern Frond", "Olive Branch Sway", "Frosted Lambs Ear"],
        texture: ["Dried Lotus Pod", "Thistle Globule", "Scabiosa Pods", "Cotton Boll Cluster", "Amber Wheat Stems", "Wild Pinecone Cluster"],
        ribbon: ["Raw Edge Linen Tie", "Crushed Moss Velvet", "Tarnished Gold Silk", "Washed Slate Cotton", "Rust Satin Bow"]
      };

      const ai = getAIClient();

      let prompt = "";
      if (actionType === "autofill") {
        prompt = `You are the Master Botanical Designer. The user has placed some elements on their 12-hour grapevine wreath coordinate grid:
${JSON.stringify(placements)}

Their design theme is "${targetTerritoryName}". Their notes are: "${notes || "None"}".
Choose exactly 2 complementary elements from this approved catalog that would beautifully balance and complete their composition, and choose appropriate clock positions (e.g., "1:30", "4:30", "7:00", "10:30") following asymmetry and focal rules (e.g. if top-right is heavy, place a subtle texture at bottom-left).
Approved Catalog to choose from:
${JSON.stringify(availableElements)}

Return a list of the 2 new items to ADD in JSON format. Provide a 1-sentence poetic explanation for why you chose these additions.`;
      } else {
        prompt = `You are the Master Botanical Designer. The user has placed some elements on their 12-hour grapevine wreath coordinate grid:
${JSON.stringify(placements)}

Their design theme is "${targetTerritoryName}". 
We must enforce organic asymmetry. If elements are mirror-aligned (e.g. exactly opposite at 9:00 and 3:00, or 12:00 and 6:00, or identical items placed symmetrically), we need to slightly shift their clock positions to create a beautiful, dynamic, diagonal counter-balance (e.g. moving a 3:00 item to 4:30, or spacing out items).
Review the current placements, adjust their 'clockPosition' attributes if they violate asymmetry, and return the COMPLETE modified list of placements. Provide a 1-sentence explanation of the adjustments made.`;
      }

      const responseSchema = actionType === "autofill"
        ? {
            type: Type.OBJECT,
            properties: {
              itemsToAdd: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    elementType: { type: Type.STRING, enum: ["focal", "greenery", "texture", "ribbon"] },
                    elementName: { type: Type.STRING },
                    clockPosition: { type: Type.STRING, description: "Clock hour e.g. '4:30', '7:00'" }
                  },
                  required: ["elementType", "elementName", "clockPosition"]
                }
              },
              explanation: { type: Type.STRING, description: "Poetic 1-sentence design rationale" }
            },
            required: ["itemsToAdd", "explanation"]
          }
        : {
            type: Type.OBJECT,
            properties: {
              optimizedPlacements: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    elementType: { type: Type.STRING, enum: ["focal", "greenery", "texture", "ribbon"] },
                    elementName: { type: Type.STRING },
                    clockPosition: { type: Type.STRING }
                  },
                  required: ["id", "elementType", "elementName", "clockPosition"]
                }
              },
              explanation: { type: Type.STRING, description: "Poetic 1-sentence design rationale of the repositioning" }
            },
            required: ["optimizedPlacements", "explanation"]
          };

      // Use gemini-3.5-flash for structured design modifications
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: responseSchema
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("Empty optimization response.");
      }

      res.json({
        success: true,
        data: JSON.parse(responseText.trim())
      });

    } catch (err: any) {
      console.error("Layout optimization failed:", err);
      res.json({
        success: false,
        error: err.message || "Failed to optimize layout."
      });
    }
  });

  // API Route: Waitlist Signup
  app.post("/api/waitlist", (req, res) => {
    try {
      const { email, source } = req.body;
      if (!email || typeof email !== "string" || !email.includes("@")) {
        return res.status(400).json({ error: "A valid email address is required" });
      }

      const list = loadWaitlist();
      if (!list.some(item => item.email.toLowerCase() === email.toLowerCase())) {
        list.push({
          email: email.toLowerCase(),
          source: source || "unknown",
          registeredAt: new Date().toISOString()
        });
        saveWaitlist(list);
      }

      res.json({ success: true, message: "Successfully registered to waitlist" });
    } catch (err) {
      console.error("Waitlist registration error:", err);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Vite development middleware vs Static Production bundle
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Moodoor Server] Running on http://localhost:${PORT}`);
  });
}

startServer();

// Temporary public preview only. Serves Moodoor's standalone HTML and fallback visuals.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, "dist", "public");
const fallbackImage = "/home/ubuntu/moodoor_archive/uploads/pasted-1785049244062-0.png";
const port = Number(process.env.PORT || 4173);
const typeFor = (file) => ({
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
}[path.extname(file).toLowerCase()] || "application/octet-stream");

const mark = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" fill="#f5f1e8"/><g fill="none" stroke="#365b4a" stroke-width="5" stroke-linecap="round"><path d="M56 15A28 28 0 1 0 68 40"/><path d="M61 15c4 5 6 10 7 16"/></g><circle cx="59" cy="15" r="4" fill="#c99a39"/></svg>`;

function serveFile(file, response) {
  fs.stat(file, (error, stats) => {
    if (error) {
      response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      response.end("Not found");
      return;
    }
    if (stats.isDirectory()) {
      serveFile(path.join(file, "index.html"), response);
      return;
    }
    response.writeHead(200, { "Content-Type": typeFor(file), "Cache-Control": "no-store" });
    fs.createReadStream(file).pipe(response);
  });
}

http.createServer((request, response) => {
  const pathname = decodeURIComponent(new URL(request.url || "/", `http://${request.headers.host}`).pathname);
  if (pathname === "/manus-storage/moodoor-split-ring-mark_49598a48.png") {
    response.writeHead(200, { "Content-Type": "image/svg+xml", "Cache-Control": "no-store" });
    response.end(mark);
    return;
  }
  if (pathname.startsWith("/manus-storage/")) {
    response.writeHead(200, { "Content-Type": "image/png", "Cache-Control": "no-store" });
    fs.createReadStream(fallbackImage).pipe(response);
    return;
  }
  const requested = pathname === "/" ? "/index.html" : pathname;
  const absolute = path.resolve(root, `.${requested}`);
  if (!absolute.startsWith(root)) {
    response.writeHead(403, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("Forbidden");
    return;
  }
  serveFile(absolute, response);
}).listen(port, "0.0.0.0", () => console.log(`Moodoor preview running on ${port}`));

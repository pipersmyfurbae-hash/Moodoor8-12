# Moodoor design directions

## Approach A — The Botanical Ledger

**Very Brief Intro:** A quiet, editorial study in botanical notation and remembered atmosphere. It treats the wreath as a catalogued composition rather than a decorative object.

**Probability:** 0.07

## Approach B — The Winter Orangery

**Very Brief Intro:** An abundant, sun-warmed conservatory with citrus paper, plant labels, and private garden rituals. The experience feels tactile and celebratory, with colour held in floral material rather than a digital gradient.

**Probability:** 0.04

## Approach C — Nocturne Atelier

**Very Brief Intro:** A dark, low-lit workroom that frames each composition as a jewel-like study. The mood is ceremonial and intimate, with copper details on deep blue-black paper.

**Probability:** 0.09

# Selected direction — The Botanical Ledger

## Design Movement

Moodoor adopts the restraint of **contemporary botanical editorial design**, informed by herbarium specimen sheets, artist’s studio ephemera, and the disciplined notation of a field journal. The visual system communicates that an emotional memory can be translated into a real, considered botanical composition.

## Core Principles

1. **Material before interface.** Paper grain, ruled margins, typed coordinates, and pressed-botanical details make the system feel physically authored.
2. **Emotion with evidence.** Every expressive statement is paired with an exacting design signal, including territory, dominant note, and a measured fit score.
3. **Asymmetry with discipline.** Layouts use offset columns, interrupted rules, and deliberately open negative space instead of generic centered stacks.
4. **Quiet interaction.** Motion is brief and purposeful: elements rise into place, rules draw on, and cards reveal their evidence without spectacle.

## Color Philosophy

The primary canvas is a warm archival paper rather than clinical white, creating a receptive place for memory. Ink black supplies legibility and authority, while **moss ledger green** signals botanical intelligence and interaction. A restrained marigold thread is used only for marks of selection, measurement, and active states. Image areas can hold the chromatic fullness of living materials, leaving the interface itself calm.

## Layout Paradigm

The site follows a **ledger spread** rather than a centered grid. Each major section is conceived as a pair of facing pages: a narrow metadata column and a wider image or narrative field. Long horizontal rules, overset labels, and occasional vertical text establish a continuous editorial cadence. On small screens, the metadata fields become inline marginalia that follows the content.

## Signature Elements

The first motif is the **sentiment ring**, a thin, imperfect circular annotation that maps an emotional memory to a compositional orbit. The second is the **ledger rule**, a short moss-green line that lengthens on hover and anchors navigation, cards, and section captions. The third is a **specimen token**, a small outlined dot-and-coordinate lock-up used to label emotional territory, design role, and collection notes.

## Interaction Philosophy

The interface responds like an attentive studio assistant. Memory prompts open a short three-stage interpretation sequence, selected wreath cards disclose a compact evidence panel, and navigation moves through the site with direct, comprehensible feedback. Buttons are verbs rather than generic account prompts; the system invites visitors to “Trace a memory” or “Read the blueprint.”

## Animation

The motion language uses 260–700 ms ease-out transitions. Section labels and artwork rise by a few pixels as they enter; rules animate from left to right; the sentiment ring completes one modest clockwise draw. Nothing loops continuously except the small active-position marker while a memory is being interpreted. Reduced-motion settings remove transforms and retain only opacity changes.

## Typography System

Headlines use **Cormorant Garamond** in medium and italic cuts, allowing titles to feel literary without becoming ornamental. Body copy uses **Manrope** for firm, readable technical prose, while coordinates and small category labels use **IBM Plex Mono**. Headlines are broadly tracked at small sizes and compact at display scale; uppercase is reserved for metadata, never for paragraphs.

## Brand Essence

**Moodoor is a memory-matching botanical house for people who want a wreath with a point of view and a blueprint behind it.** Its personality is **considered, intimate, and exacting**.

## Brand Voice

Headlines read like a thoughtful note in the margin; calls to action are confident but never urgent; microcopy names the next meaningful action. Example headline: “A memory is enough to begin.” Example action line: “Trace the feeling; we’ll find its form.” The brand avoids generic invitations such as “Welcome” or “Get started.”

## Wordmark & Logo

The mark is a split-ring specimen seal: two imperfect circular arcs meet at an offset point, with a small seed-like dot marking the joining coordinate. The wordmark sets “Moodoor” in a tailored serif with a subtle cut through the double-o, echoing the open orbit of the seal. The logo appears as a clear, medium-scale mark in the header and browser icon.

## Signature Brand Color

**Moss Ledger — `#365B4A`.** A tempered green with enough density to carry the brand alone on paper, textile, and screen.

## Implementation commitment

The core Moodoor page will center the memory-to-wreath ritual, the curated signature wreaths, and the evidence behind the match. The required foundational pages will explain wreath fundamentals, design principles, and the blueprint system using the same ledger structure and precise editorial vocabulary.

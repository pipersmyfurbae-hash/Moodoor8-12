CREATE TABLE `moodoor_collections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(96) NOT NULL,
	`name` varchar(160) NOT NULL,
	`season` varchar(120) NOT NULL,
	`atmosphere` varchar(160) NOT NULL,
	`status` enum('draft','review','published') NOT NULL DEFAULT 'draft',
	`intent` text NOT NULL,
	`palette` json NOT NULL,
	`payload` json NOT NULL,
	`createdBy` int,
	`published` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `moodoor_collections_id` PRIMARY KEY(`id`),
	CONSTRAINT `moodoor_collections_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `moodoor_memories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`memory` text NOT NULL,
	`vector` json NOT NULL,
	`explanation` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `moodoor_memories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `moodoor_studio_renders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`collectionId` int NOT NULL,
	`productKey` varchar(128) NOT NULL,
	`renderType` varchar(80) NOT NULL,
	`prompt` text NOT NULL,
	`imageUrl` text,
	`status` enum('queued','ready','failed') NOT NULL DEFAULT 'queued',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `moodoor_studio_renders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `moodoor_waitlist` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`source` varchar(80) NOT NULL DEFAULT 'moodoor',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `moodoor_waitlist_id` PRIMARY KEY(`id`),
	CONSTRAINT `moodoor_waitlist_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);

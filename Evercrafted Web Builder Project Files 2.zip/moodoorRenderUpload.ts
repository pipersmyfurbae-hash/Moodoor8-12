import express, { type Express } from "express";
import { createContext } from "./_core/context";
import { storagePut } from "./storage";

const acceptedMimeTypes = new Set(["image/png", "image/jpeg", "image/webp"]);
const maxRenderBytes = 7_000_000;
const maxChunkBytes = 24_000;
const pendingUploads = new Map<string, { userId: number; mimeType: string; fileName: string; totalChunks: number; chunks: Buffer[]; expiresAt: number }>();

function safeRenderName(fileName: string) {
  return fileName.replace(/[^a-zA-Z0-9_-]/g, "-").slice(0, 80) || "wreath-render";
}

function extensionForImage(mimeType: string) {
  return mimeType === "image/png" ? "png" : mimeType === "image/webp" ? "webp" : "jpg";
}

export function registerMoodoorRenderUpload(app: Express) {
  app.post("/api/moodoor/render-upload/chunk", async (req, res) => {
    const ctx = await createContext({ req, res, info: {} as any });
    if (!ctx.user || ctx.user.role !== "admin") return res.status(403).json({ error: "Administrator access is required." });

    const mimeType = String(req.body?.mimeType || "").toLowerCase();
    if (!acceptedMimeTypes.has(mimeType)) return res.status(400).json({ error: "Upload a PNG, JPEG, or WebP wreath render." });
    const encodedChunk = typeof req.body?.data === "string" ? req.body.data : "";
    if (!/^[A-Za-z0-9+/]+={0,2}$/.test(encodedChunk)) return res.status(400).json({ error: "Render upload data is invalid." });
    const chunkBytes = Buffer.from(encodedChunk, "base64");
    if (chunkBytes.length === 0) return res.status(400).json({ error: "A render image is required." });
    if (chunkBytes.length > maxChunkBytes) return res.status(413).json({ error: "Render upload chunk is too large." });

    const fileName = String(req.body?.fileName || "wreath-render").slice(0, 160);
    const uploadId = String(req.body?.uploadId || "");
    const chunkIndex = Number(req.body?.chunkIndex);
    const totalChunks = Number(req.body?.totalChunks);
    if (!/^[a-zA-Z0-9_-]{12,96}$/.test(uploadId) || !Number.isInteger(chunkIndex) || !Number.isInteger(totalChunks) || chunkIndex < 0 || totalChunks < 1 || totalChunks > 400 || chunkIndex >= totalChunks) {
      return res.status(400).json({ error: "Render upload metadata is invalid." });
    }

    pendingUploads.forEach((upload, id) => { if (upload.expiresAt < Date.now()) pendingUploads.delete(id); });
    let upload = pendingUploads.get(uploadId);
    if (!upload) {
      if (chunkIndex !== 0) return res.status(409).json({ error: "Start a new render upload from its first chunk." });
      upload = { userId: ctx.user.id, mimeType, fileName, totalChunks, chunks: [], expiresAt: Date.now() + 10 * 60_000 };
      pendingUploads.set(uploadId, upload);
    }
    if (upload.userId !== ctx.user.id || upload.mimeType !== mimeType || upload.fileName !== fileName || upload.totalChunks !== totalChunks || upload.chunks.length !== chunkIndex) {
      pendingUploads.delete(uploadId);
      return res.status(409).json({ error: "Render upload sequence is invalid. Please select the image again." });
    }

    upload.chunks.push(chunkBytes);
    if (upload.chunks.length < upload.totalChunks) return res.status(202).json({ complete: false, receivedChunks: upload.chunks.length });

    const imageBytes = Buffer.concat(upload.chunks);
    pendingUploads.delete(uploadId);
    if (imageBytes.length > maxRenderBytes) return res.status(413).json({ error: "Use a render under 7 MB for visual analysis." });
    try {
      const stored = await storagePut(
        `moodoor/admin/${ctx.user.id}/reference-renders/${safeRenderName(fileName)}.${extensionForImage(mimeType)}`,
        imageBytes,
        mimeType,
      );
      return res.status(201).json({ complete: true, sourceImageUrl: stored.url });
    } catch {
      return res.status(503).json({ error: "Managed image storage is temporarily unavailable. Please retry the render upload shortly." });
    }
  });
}

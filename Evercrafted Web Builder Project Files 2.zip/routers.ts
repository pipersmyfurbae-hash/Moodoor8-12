import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { generateImage } from "./_core/imageGeneration";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { ENV } from "./_core/env";
import { hashPassword, verifyPassword } from "./localAuth";
import { createMoodoorCollection, registerMoodoorWaitlist, saveMoodoorMemory, updateMoodoorCollectionStatus, listMoodoorCollections } from "./db";
import { analyzeWreathRender, buildStudioPayload, calculateSimilarity, critiqueComposition, EvsVector, interpretMemory } from "./moodoor";
import { storageGetSignedUrl } from "./storage";

const vectorSchema = z.object({
  warmth: z.number().min(0).max(1), energy: z.number().min(0).max(1), nostalgia: z.number().min(0).max(1), valence: z.number().min(0).max(1), intimacy: z.number().min(0).max(1), restraint: z.number().min(0).max(1), seasonal: z.number().min(0).max(1),
});

const sampleWreathVectors: Array<{ id: string; vector: EvsVector }> = [
  { id: "BP-EC-0417", vector: { warmth: .82, energy: .35, nostalgia: .91, valence: .58, intimacy: .78, restraint: .64, seasonal: .95 } },
  { id: "BP-EC-0422", vector: { warmth: .88, energy: .42, nostalgia: .87, valence: .65, intimacy: .72, restraint: .52, seasonal: .92 } },
  { id: "BP-EC-0431", vector: { warmth: .76, energy: .22, nostalgia: .94, valence: .48, intimacy: .86, restraint: .83, seasonal: .88 } },
  { id: "BP-EC-0447", vector: { warmth: .85, energy: .28, nostalgia: .66, valence: .72, intimacy: .74, restraint: .76, seasonal: .36 } },
  { id: "BP-EC-0468", vector: { warmth: .68, energy: .84, nostalgia: .34, valence: .92, intimacy: .61, restraint: .22, seasonal: .44 } },
  { id: "BP-EC-0484", vector: { warmth: .72, energy: .18, nostalgia: .65, valence: .80, intimacy: .72, restraint: .62, seasonal: .72 } },
];

const slugify = (value: string) => value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 84);

export function moodoorRenderStorageKey(sourceImageUrl: string, userId: number) {
  const prefix = `/manus-storage/moodoor/admin/${userId}/reference-renders/`;
  if (!sourceImageUrl.startsWith(prefix)) throw new Error("The selected render is not an owned Moodoor reference image.");
  return sourceImageUrl.slice("/manus-storage/".length);
}

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    signUp: publicProcedure.input(z.object({ email: z.string().trim().email().max(320), password: z.string().min(10).max(256), name: z.string().trim().min(2).max(120) })).mutation(async ({ input, ctx }) => {
      const email = input.email.toLowerCase();
      const existing = await import("./db").then((db) => db.getUserByEmail(email));
      if (existing) throw new TRPCError({ code: "CONFLICT", message: "An account already exists for this email. Sign in instead." });
      const user = await import("./db").then((db) => db.createPasswordUser({ email, name: input.name, passwordHash: "" }));
      // The previous call reserves the unique local account. Replace the empty credential hash before issuing a session.
      const passwordHash = await hashPassword(input.password);
      await import("./db").then((db) => db.upsertUser({ openId: user.openId, passwordHash, lastSignedIn: new Date() }));
      const token = await (await import("./_core/sdk")).sdk.createSessionToken(user.openId, { name: user.name ?? input.name });
      ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: 31_536_000_000 });
      return { id: user.id, name: user.name, email: user.email, role: user.role };
    }),
    passwordLogin: publicProcedure.input(z.object({ email: z.string().trim().email().max(320), password: z.string().min(1).max(256) })).mutation(async ({ input, ctx }) => {
      const user = await import("./db").then((db) => db.getUserByEmail(input.email.toLowerCase()));
      if (!user || !await verifyPassword(input.password, user.passwordHash)) throw new TRPCError({ code: "UNAUTHORIZED", message: "Email or password is incorrect." });
      await import("./db").then((db) => db.upsertUser({ openId: user.openId, lastSignedIn: new Date() }));
      const token = await (await import("./_core/sdk")).sdk.createSessionToken(user.openId, { name: user.name ?? input.email });
      ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: 31_536_000_000 });
      return { id: user.id, name: user.name, email: user.email, role: user.role };
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  moodoor: router({
    ownerBootstrap: publicProcedure.query(() => ({ configured: Boolean(ENV.moodoorInitialAdminEmail) })),
    match: publicProcedure.input(z.object({ memory: z.string().trim().min(4).max(2400) })).mutation(async ({ input, ctx }) => {
      const interpreted = await interpretMemory(input.memory);
      const matches = sampleWreathVectors.map((wreath) => ({ id: wreath.id, score: calculateSimilarity(interpreted.vector, wreath.vector), explanation: interpreted.explanation })).sort((first, second) => second.score - first.score).slice(0, 3);
      void saveMoodoorMemory({ userId: ctx.user?.id ?? null, memory: input.memory, vector: interpreted.vector, explanation: interpreted.explanation });
      return { interpretedVector: interpreted.vector, explanation: interpreted.explanation, matches, isFallback: interpreted.isFallback };
    }),
    critique: publicProcedure.input(z.object({ territory: z.string().min(1).max(80), notes: z.string().max(1800).default(""), placements: z.array(z.object({ elementName: z.string().optional(), elementType: z.string().optional(), clockPosition: z.string().optional() })).max(40).default([]) })).mutation(({ input }) => critiqueComposition(input)),
    waitlist: publicProcedure.input(z.object({ email: z.string().email(), source: z.string().max(80).default("moodoor") })).mutation(({ input }) => registerMoodoorWaitlist(input.email.toLowerCase(), input.source)),
    canvas: router({
      generate: publicProcedure.input(z.object({ prompt: z.string().min(12).max(3200), sourceImageUrl: z.string().url().optional() })).mutation(async ({ input }) => {
        const generated = await generateImage({ prompt: input.prompt, ...(input.sourceImageUrl ? { originalImages: [{ url: input.sourceImageUrl, mimeType: "image/png" }] } : {}) });
        return { imageUrl: generated.url };
      }),
    }),
  }),
  admin: router({
    collections: router({
      list: adminProcedure.query(() => listMoodoorCollections()),
      create: adminProcedure.input(z.object({ name: z.string().min(3).max(160), season: z.string().min(2).max(120), atmosphere: z.string().min(2).max(160), intent: z.string().min(12).max(4000), palette: z.array(z.string().min(2).max(64)).min(1).max(8), sourceImageUrl: z.string().startsWith("/manus-storage/").optional(), visualNotes: z.array(z.string().min(2).max(280)).max(10).optional(), renderPrompt: z.string().min(12).max(4000).optional() })).mutation(async ({ input, ctx }) => {
        const payload = buildStudioPayload(input);
        const slug = `${slugify(input.name)}-${Date.now().toString(36)}`;
        return createMoodoorCollection({ ...input, slug, payload, createdBy: ctx.user.id });
      }),
      setStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["draft", "review", "published"]) })).mutation(async ({ input }) => {
        const updated = await updateMoodoorCollectionStatus(input.id, input.status);
        if (!updated) throw new TRPCError({ code: "NOT_FOUND", message: "Collection not found" });
        return updated;
      }),
    }),
    studio: router({
      validateVector: adminProcedure.input(vectorSchema).query(({ input }) => ({ valid: true, magnitude: Math.round(Math.sqrt(Object.values(input).reduce((sum, value) => sum + value * value, 0)) * 100) / 100 })),
      analyzeRender: adminProcedure.input(z.object({ sourceImageUrl: z.string().startsWith("/manus-storage/").max(768), fileName: z.string().min(1).max(160) })).mutation(async ({ input, ctx }) => {
        let key: string;
        try { key = moodoorRenderStorageKey(input.sourceImageUrl, ctx.user.id); }
        catch (error) { throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Invalid render source." }); }
        const signedImageUrl = await storageGetSignedUrl(key);
        return analyzeWreathRender({ imageUrl: signedImageUrl, fileName: input.fileName, storedUrl: input.sourceImageUrl });
      }),
    }),
  }),
});

export type AppRouter = typeof appRouter;

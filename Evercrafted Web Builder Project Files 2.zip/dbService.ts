import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  deleteDoc, 
  doc, 
  serverTimestamp,
  getDoc
} from "firebase/firestore";
import { db } from "./firebase";
import { PlacementItem, WreathCritique } from "../types";

export interface SavedWreathDesign {
  id: string;
  userId: string;
  placements: PlacementItem[];
  targetTerritoryId: number;
  notes: string;
  critique: WreathCritique;
  createdAt: any;
}

export interface SavedCanvasImage {
  id: string;
  userId: string;
  url: string;
  prompt: string;
  aspectRatio: string;
  imageSize: string;
  mode: "create" | "edit";
  createdAt: any;
}

// --- WREATH DESIGNS ---

export async function saveWreathToFirestore(
  userId: string, 
  placements: PlacementItem[], 
  targetTerritoryId: number, 
  notes: string, 
  critique: WreathCritique
): Promise<string> {
  try {
    const colRef = collection(db, "wreath_designs");
    const docRef = await addDoc(colRef, {
      userId,
      placements,
      targetTerritoryId,
      notes,
      critique,
      createdAt: serverTimestamp()
    });
    return docRef.id;
  } catch (err) {
    console.error("Failed to save wreath to Firestore:", err);
    throw err;
  }
}

export async function getWreathsFromFirestore(userId: string): Promise<SavedWreathDesign[]> {
  try {
    const colRef = collection(db, "wreath_designs");
    const q = query(
      colRef, 
      where("userId", "==", userId), 
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    const results: SavedWreathDesign[] = [];
    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      results.push({
        id: docSnap.id,
        userId: data.userId,
        placements: data.placements,
        targetTerritoryId: data.targetTerritoryId,
        notes: data.notes,
        critique: data.critique,
        createdAt: data.createdAt ? data.createdAt.toDate() : new Date()
      });
    });
    return results;
  } catch (err) {
    console.error("Failed to fetch wreaths from Firestore:", err);
    return [];
  }
}

export async function deleteWreathFromFirestore(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, "wreath_designs", id));
  } catch (err) {
    console.error("Failed to delete wreath from Firestore:", err);
    throw err;
  }
}

// --- CANVAS IMAGES ---

export async function saveCanvasToFirestore(
  userId: string,
  url: string,
  prompt: string,
  aspectRatio: string,
  imageSize: string,
  mode: "create" | "edit"
): Promise<string> {
  try {
    const colRef = collection(db, "canvas_images");
    const docRef = await addDoc(colRef, {
      userId,
      url,
      prompt,
      aspectRatio,
      imageSize,
      mode,
      createdAt: serverTimestamp()
    });
    return docRef.id;
  } catch (err) {
    console.error("Failed to save canvas to Firestore:", err);
    throw err;
  }
}

export async function getCanvasFromFirestore(userId: string): Promise<SavedCanvasImage[]> {
  try {
    const colRef = collection(db, "canvas_images");
    const q = query(
      colRef,
      where("userId", "==", userId),
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    const results: SavedCanvasImage[] = [];
    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      results.push({
        id: docSnap.id,
        userId: data.userId,
        url: data.url,
        prompt: data.prompt,
        aspectRatio: data.aspectRatio,
        imageSize: data.imageSize,
        mode: data.mode,
        createdAt: data.createdAt ? data.createdAt.toDate() : new Date()
      });
    });
    return results;
  } catch (err) {
    console.error("Failed to fetch canvas history from Firestore:", err);
    return [];
  }
}

export async function deleteCanvasFromFirestore(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, "canvas_images", id));
  } catch (err) {
    console.error("Failed to delete canvas from Firestore:", err);
    throw err;
  }
}

// --- MEMORY ENTRIES ---

export interface SavedMemoryEntry {
  id: string;
  userId: string;
  memory: string;
  interpretedVector: any;
  explanation: string;
  createdAt: any;
}

export async function saveMemoryToFirestore(
  userId: string,
  memory: string,
  interpretedVector: any,
  explanation: string
): Promise<string> {
  try {
    const colRef = collection(db, "memory_entries");
    const docRef = await addDoc(colRef, {
      userId,
      memory,
      interpretedVector,
      explanation,
      createdAt: serverTimestamp()
    });
    return docRef.id;
  } catch (err) {
    console.error("Failed to save memory to Firestore:", err);
    throw err;
  }
}

export async function getMemoriesFromFirestore(userId: string): Promise<SavedMemoryEntry[]> {
  try {
    const colRef = collection(db, "memory_entries");
    const q = query(
      colRef,
      where("userId", "==", userId),
      orderBy("createdAt", "desc")
    );
    const querySnapshot = await getDocs(q);
    const results: SavedMemoryEntry[] = [];
    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      results.push({
        id: docSnap.id,
        userId: data.userId,
        memory: data.memory,
        interpretedVector: data.interpretedVector,
        explanation: data.explanation,
        createdAt: data.createdAt ? data.createdAt.toDate() : new Date()
      });
    });
    return results;
  } catch (err) {
    console.error("Failed to fetch memories from Firestore:", err);
    return [];
  }
}

export async function deleteMemoryFromFirestore(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, "memory_entries", id));
  } catch (err) {
    console.error("Failed to delete memory from Firestore:", err);
    throw err;
  }
}

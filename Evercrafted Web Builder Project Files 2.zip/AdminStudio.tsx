import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Check, ChevronLeft, ClipboardCopy, ImagePlus, LoaderCircle, Plus, Sparkles, WandSparkles } from "lucide-react";
import { useMemo, useState } from "react";
import { useLocation } from "wouter";

const statusLabel = { draft: "Draft", review: "In review", published: "Published" } as const;
type Status = keyof typeof statusLabel;

function StudioContent() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const collections = trpc.admin.collections.list.useQuery();
  const createCollection = trpc.admin.collections.create.useMutation({ onSuccess: () => utils.admin.collections.list.invalidate() });
  const setStatus = trpc.admin.collections.setStatus.useMutation({ onSuccess: () => utils.admin.collections.list.invalidate() });
  const analyzeRender = trpc.admin.studio.analyzeRender.useMutation();
  const [entryMode, setEntryMode] = useState<"intent" | "render">("intent");
  const [name, setName] = useState("");
  const [season, setSeason] = useState("Late autumn to deep winter");
  const [atmosphere, setAtmosphere] = useState("Nordic calm");
  const [palette, setPalette] = useState("Ivory mist, sage smoke, slate berry, warm bark");
  const [intent, setIntent] = useState("");
  const [sourceImageUrl, setSourceImageUrl] = useState<string | undefined>();
  const [visualNotes, setVisualNotes] = useState<string[]>([]);
  const [renderPrompt, setRenderPrompt] = useState<string | undefined>();
  const [imagePreview, setImagePreview] = useState<string | undefined>();
  const [imageError, setImageError] = useState<string | null>(null);
  const [isUploadingRender, setIsUploadingRender] = useState(false);
  const [activeId, setActiveId] = useState<number | null>(null);
  const active = useMemo(() => collections.data?.find((collection) => collection.id === activeId) ?? collections.data?.[0], [collections.data, activeId]);

  const create = () => {
    createCollection.mutate({ name, season, atmosphere, intent, palette: palette.split(",").map((entry) => entry.trim()).filter(Boolean), ...(sourceImageUrl ? { sourceImageUrl, visualNotes, renderPrompt } : {}) }, { onSuccess: (record) => { setActiveId(record.id); setName(""); setIntent(""); setSourceImageUrl(undefined); setImagePreview(undefined); setVisualNotes([]); setRenderPrompt(undefined); } });
  };
  const selectRender = async (file?: File) => {
    if (!file) return;
    if (!/image\/(png|jpeg|webp)/.test(file.type)) { setImageError("Upload a PNG, JPEG, or WebP render."); return; }
    if (file.size > 7_000_000) { setImageError("Use a render under 7 MB for visual analysis."); return; }
    setImagePreview(URL.createObjectURL(file)); setImageError(null);
    setIsUploadingRender(true);
    try {
      const chunkSize = 24_000;
      const totalChunks = Math.ceil(file.size / chunkSize);
      const uploadId = crypto.randomUUID().replace(/-/g, "");
      let sourceImageUrl: string | undefined;
      for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex += 1) {
        const data = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(String(reader.result || "").split(",")[1] || "");
          reader.onerror = () => reject(new Error("The render chunk could not be read."));
          reader.readAsDataURL(file.slice(chunkIndex * chunkSize, Math.min(file.size, (chunkIndex + 1) * chunkSize)));
        });
        const uploadResponse = await fetch("/api/moodoor/render-upload/chunk", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ fileName: file.name, mimeType: file.type, uploadId, chunkIndex, totalChunks, data }),
          credentials: "include",
        });
        const upload = await uploadResponse.json().catch(() => ({})) as { sourceImageUrl?: string; error?: string };
        if (!uploadResponse.ok) throw new Error(upload.error || "The render upload could not be completed.");
        sourceImageUrl = upload.sourceImageUrl ?? sourceImageUrl;
      }
      if (!sourceImageUrl) throw new Error("The render upload did not return a stored reference.");
      const draft = await analyzeRender.mutateAsync({ sourceImageUrl, fileName: file.name });
      setName(draft.name); setSeason(draft.season); setAtmosphere(draft.atmosphere); setIntent(draft.intent); setPalette(draft.palette.join(", ")); setVisualNotes(draft.visualNotes); setRenderPrompt(draft.renderPrompt); setSourceImageUrl(draft.sourceImageUrl);
    } catch (error) { setImageError(error instanceof Error ? error.message : "The render could not be analyzed."); }
    finally { setIsUploadingRender(false); }
  };
  const copyPrompts = async () => {
    const payload = active?.payload as { products?: Array<{ name: string; prompt: string }> } | undefined;
    const text = payload?.products?.map((product) => `${product.name}\n${product.prompt}`).join("\n\n") ?? "";
    if (text) await navigator.clipboard.writeText(text);
  };

  if (collections.isLoading) return <div className="grid min-h-[60vh] place-items-center"><LoaderCircle className="h-7 w-7 animate-spin text-[#4a7a52]" /></div>;
  if (collections.error) return <section className="mx-auto max-w-xl space-y-5 py-20 text-center"><p className="font-mono text-xs uppercase tracking-[.18em] text-[#4a7a52]">Moodoor operations</p><h1 className="font-serif text-5xl">Administrator access required.</h1><p className="text-muted-foreground">The Collection Studio is secured behind the managed owner role. Sign in with the project owner account to create, review, and publish collection records.</p><Button onClick={() => setLocation("/")} variant="outline"><ChevronLeft /> Return to Moodoor</Button></section>;

  return <div className="min-h-screen bg-[#f5f2eb] p-3 md:p-7"><div className="mx-auto max-w-7xl space-y-6"><header className="flex flex-col justify-between gap-5 border-b border-[#d9d2c7] pb-6 md:flex-row md:items-end"><div><p className="font-mono text-[10px] font-semibold uppercase tracking-[.18em] text-[#4a7a52]">Evercrafted / internal operations</p><h1 className="mt-2 font-serif text-4xl tracking-tight text-[#2c2820] md:text-5xl">Collection Studio</h1><p className="mt-2 max-w-xl text-sm leading-6 text-[#655f57]">The restored internal workspace for translating a sightline brief into a layered Moodoor collection, product prompts, and review state.</p></div><Button variant="outline" className="border-[#b6cbb9] bg-white text-[#31563e]" onClick={() => setLocation("/")}><ChevronLeft /> Storefront</Button></header>

  <div className="grid gap-6 lg:grid-cols-[360px_minmax(0,1fr)]"><aside className="space-y-5 rounded-2xl border border-[#ded7cb] bg-white p-5 shadow-sm"><div className="flex items-center justify-between"><h2 className="font-serif text-2xl">New collection</h2><WandSparkles className="h-4 w-4 text-[#4a7a52]" /></div><div className="grid grid-cols-2 rounded-lg bg-[#f4f0e8] p-1"><button onClick={() => setEntryMode("intent")} className={`rounded-md px-2 py-2 text-[11px] font-medium ${entryMode === "intent" ? "bg-white text-[#31563e] shadow-sm" : "text-[#786f63]"}`}>Intent brief</button><button onClick={() => setEntryMode("render")} className={`rounded-md px-2 py-2 text-[11px] font-medium ${entryMode === "render" ? "bg-white text-[#31563e] shadow-sm" : "text-[#786f63]"}`}>Wreath render</button></div>{entryMode === "render" && <div className="rounded-xl border border-dashed border-[#aebfaa] bg-[#f8faf6] p-3"><label className="flex cursor-pointer flex-col items-center gap-2 rounded-lg px-2 py-3 text-center"><ImagePlus className="h-5 w-5 text-[#4a7a52]" /><span className="text-xs font-medium text-[#3e4b40]">Upload a finished wreath render</span><span className="text-[10px] leading-4 text-[#7c8078]">PNG, JPEG, or WebP · under 7 MB</span><Input type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" onChange={(event) => void selectRender(event.target.files?.[0])} /></label>{imagePreview && <img src={imagePreview} alt="Selected wreath render" className="mt-2 h-28 w-full rounded-lg object-cover" />}{(isUploadingRender || analyzeRender.isPending) && <p className="mt-3 flex items-center gap-2 text-xs text-[#4a7a52]"><LoaderCircle className="h-3.5 w-3.5 animate-spin" /> Pulling structure, palette, and form notes…</p>}{imageError && <p className="mt-3 text-xs leading-5 text-red-700">{imageError}</p>}{sourceImageUrl && <p className="mt-3 text-[10px] leading-4 text-[#4a7a52]">Render analyzed and stored. Review the editable brief below.</p>}</div>}<div className="space-y-3"><Input placeholder="Collection name" value={name} onChange={(event) => setName(event.target.value)} className="border-[#d9d2c7] bg-[#fbfaf7]" /><Input value={season} onChange={(event) => setSeason(event.target.value)} className="border-[#d9d2c7] bg-[#fbfaf7]" /><Input value={atmosphere} onChange={(event) => setAtmosphere(event.target.value)} className="border-[#d9d2c7] bg-[#fbfaf7]" /><Input value={palette} onChange={(event) => setPalette(event.target.value)} className="border-[#d9d2c7] bg-[#fbfaf7]" /><Textarea placeholder="Describe the home, season, sightline, materials, and emotional register..." value={intent} onChange={(event) => setIntent(event.target.value)} className="min-h-36 border-[#d9d2c7] bg-[#fbfaf7]" /></div>{visualNotes.length > 0 && <div className="rounded-lg border border-[#dce6d8] bg-[#f6faf3] p-3"><p className="font-mono text-[9px] uppercase tracking-[.13em] text-[#4a7a52]">Extracted visual notes</p><ul className="mt-2 space-y-1 text-[11px] leading-4 text-[#5d655e]">{visualNotes.slice(0, 4).map((note) => <li key={note}>• {note}</li>)}</ul></div>}<Button className="w-full bg-[#3f6949] hover:bg-[#31563e]" disabled={createCollection.isPending || isUploadingRender || analyzeRender.isPending || name.trim().length < 3 || intent.trim().length < 12} onClick={create}>{createCollection.isPending ? <LoaderCircle className="animate-spin" /> : <Plus />} Build collection draft</Button><p className="text-[11px] leading-5 text-[#847d73]">Start with an editable intent, or let a finished wreath render populate the same studio brief. Published collections remain a separate deliberate action.</p></aside>

  <section className="min-w-0 space-y-5"><div className="flex gap-2 overflow-x-auto pb-1">{collections.data?.map((collection) => <button key={collection.id} onClick={() => setActiveId(collection.id)} className={`shrink-0 rounded-full border px-4 py-2 text-xs transition ${active?.id === collection.id ? "border-[#4a7a52] bg-[#eaf2ea] text-[#31563e]" : "border-[#d9d2c7] bg-white text-[#6b655d]"}`}>{collection.name}</button>)}</div>{!active ? <div className="grid min-h-[420px] place-items-center rounded-2xl border border-dashed border-[#cfc6b8] bg-[#faf8f3] p-10 text-center"><div><Sparkles className="mx-auto mb-4 h-6 w-6 text-[#4a7a52]" /><h2 className="font-serif text-3xl">Start with a collection brief.</h2><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#70695f]">The source Collection Studio begins here: define a setting and a feeling, then turn it into a precise visual system rather than a generic product list.</p></div></div> : <CollectionInspector collection={active} pending={setStatus.isPending} onStatus={(status) => setStatus.mutate({ id: active.id, status })} onCopy={copyPrompts} />}</section></div></div></div>;
}

function CollectionInspector({ collection, pending, onStatus, onCopy }: { collection: any; pending: boolean; onStatus: (status: Status) => void; onCopy: () => void }) {
  const payload = collection.payload as { sightlineStory?: string; products?: Array<{ id: string; name: string; role: string; layer: number; scale: string; formula: string; price: string; prompt: string }> };
  const products = payload?.products ?? [];
  return <article className="overflow-hidden rounded-2xl border border-[#ded7cb] bg-white shadow-sm"><div className="border-b border-[#e5ded2] bg-[#f7f4ed] p-6 md:p-8"><div className="flex flex-col justify-between gap-5 md:flex-row"><div><div className="flex flex-wrap items-center gap-2"><span className="rounded-full bg-[#e7f0e7] px-2.5 py-1 font-mono text-[10px] uppercase tracking-wide text-[#356143]">{statusLabel[collection.status as Status]}</span><span className="font-mono text-[10px] uppercase tracking-wide text-[#8a8276]">{collection.season}</span></div><h2 className="mt-4 font-serif text-4xl text-[#2c2820]">{collection.name}</h2><p className="mt-2 text-sm text-[#696157]">{collection.atmosphere} · {(collection.palette as string[]).join(" · ")}</p></div><div className="flex flex-wrap gap-2"><Button variant="outline" size="sm" onClick={onCopy}><ClipboardCopy /> Copy prompts</Button>{collection.status !== "review" && <Button variant="outline" size="sm" disabled={pending} onClick={() => onStatus("review")}>Send to review</Button>}{collection.status !== "published" && <Button size="sm" className="bg-[#3f6949] hover:bg-[#31563e]" disabled={pending} onClick={() => onStatus("published")}><Check /> Publish</Button>}</div></div><p className="mt-6 max-w-3xl border-l-2 border-[#91ad94] pl-4 font-serif text-lg italic leading-7 text-[#4f514a]">{payload?.sightlineStory || collection.intent}</p></div><div className="grid gap-px bg-[#e5ded2] md:grid-cols-2">{products.map((product) => <div key={product.id} className="bg-white p-5"><div className="flex items-start justify-between gap-3"><div><p className="font-mono text-[10px] uppercase tracking-[.14em] text-[#4a7a52]">Layer {product.layer} / {product.role}</p><h3 className="mt-2 font-serif text-2xl text-[#2c2820]">{product.name}</h3><p className="mt-1 text-xs text-[#716a60]">{product.scale} · {product.formula} · {product.price}</p></div><span className="rounded-full border border-[#d9d2c7] px-2 py-1 font-mono text-[10px] text-[#756d63]">{product.id.split("-")[0].toUpperCase()}</span></div><p className="mt-4 line-clamp-4 text-xs leading-5 text-[#6d665c]">{product.prompt}</p></div>)}</div></article>;
}

export default function AdminStudio() { return <DashboardLayout><StudioContent /></DashboardLayout>; }

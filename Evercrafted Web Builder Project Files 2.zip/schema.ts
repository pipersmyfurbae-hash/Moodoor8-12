import { boolean, int, json, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const moodoorMemories = mysqlTable("moodoor_memories", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  memory: text("memory").notNull(),
  vector: json("vector").$type<Record<string, number>>().notNull(),
  explanation: text("explanation").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const moodoorCollections = mysqlTable("moodoor_collections", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 96 }).notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  season: varchar("season", { length: 120 }).notNull(),
  atmosphere: varchar("atmosphere", { length: 160 }).notNull(),
  status: mysqlEnum("status", ["draft", "review", "published"]).default("draft").notNull(),
  intent: text("intent").notNull(),
  palette: json("palette").$type<string[]>().notNull(),
  payload: json("payload").$type<Record<string, unknown>>().notNull(),
  createdBy: int("createdBy"),
  published: boolean("published").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("moodoor_collections_slug_unique").on(table.slug)]);

export const moodoorStudioRenders = mysqlTable("moodoor_studio_renders", {
  id: int("id").autoincrement().primaryKey(),
  collectionId: int("collectionId").notNull(),
  productKey: varchar("productKey", { length: 128 }).notNull(),
  renderType: varchar("renderType", { length: 80 }).notNull(),
  prompt: text("prompt").notNull(),
  imageUrl: text("imageUrl"),
  status: mysqlEnum("status", ["queued", "ready", "failed"]).default("queued").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const moodoorWaitlist = mysqlTable("moodoor_waitlist", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull(),
  source: varchar("source", { length: 80 }).default("moodoor").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [uniqueIndex("moodoor_waitlist_email_unique").on(table.email)]);

export type MoodoorMemory = typeof moodoorMemories.$inferSelect;
export type MoodoorCollection = typeof moodoorCollections.$inferSelect;
export type MoodoorStudioRender = typeof moodoorStudioRenders.$inferSelect;
